# Mapa del código v14 + v2.0 Fase 1

Este mapa explica dónde se implementó cada parte y por qué existe. Las líneas pueden cambiar cuando se añadan funciones; usa el nombre de función como referencia principal.

## Pantallas y experiencia de la persona usuaria

| Archivo | Partes clave | Qué hace | Por qué se decidió así |
|---|---|---|---|
| `app/page.tsx` | `Home` | Entrada mínima a la app. | Mantiene una sola pantalla principal y facilita la instalación como PWA. |
| `app/layout.tsx` | `metadata`, `viewport` | Título, iconos, manifiesto y aspecto móvil. | Permite que el teléfono reconozca la app instalada con nombre, icono y color. |
| `app/finance-notebook.tsx` | Tipos, estados y `FinanceNotebook` | Pantalla principal: inicio, apuntes, pagos, objetivos, reportes, ajustes y el selector de libretas. | Todo se muestra desde un estado que llega de la capa local; evita cálculos distintos entre pantallas. |
| `app/finance-notebook.tsx` | `totals` | Separa disponible, reservado, objetivos y total. | Corrige la confusión original de sumar ahorros como si fueran ingresos. |
| `app/finance-notebook.tsx` | `applySnapshot` | Convierte los datos almacenados en el formato que necesita la pantalla. | Hay un solo punto de entrada después de cada cambio; reduce errores de interfaz. |
| `app/finance-notebook.tsx` | `createNotebook`, `chooseNotebook`, `saveNotebookName`, `removeNotebook` | Crea, cambia, renombra y elimina libretas. | Cada acción usa la misma capa de seguridad que los respaldos. |
| `app/finance-notebook.tsx` | `submitFeedback` | Envía calificación y comentario anónimo. | No pide identidad ni comparte el contenido financiero. |
| `app/finance-notebook.tsx` | `paymentReminderSchedule`, `savePushSubscription`, `saveReminderSchedule` | Genera avisos 5, 3 y 1 días antes. | Se mandan fechas e identificadores aleatorios, no el proveedor ni el monto. |
| `app/onboarding.tsx` | Tutorial y flujo inicial | Explica las funciones, permite elegir uso personal o varias libretas y configura saldos/preferencias. | Evita empezar con una pantalla financiera complicada y previene mezclar dinero de distintos usos. |
| `app/globals.css` | Secciones `.notebook-*`, `.goal-*`, `.payment-*`, `.notebook-comparison` | Estilos adaptados a móvil para la libreta, pagos, metas y comparación. | Se prioriza legibilidad en teléfonos pequeños sin perder el estilo de libreta. |

## Datos locales: el núcleo de la v14

| Archivo | Partes clave | Qué hace | Por qué se decidió así |
|---|---|---|---|
| `lib/local-finance.ts` | Tipos `LocalPocket`, `LocalTransaction`, `LocalCard`, `LocalGoal` | Define la forma segura de cada dato financiero. | Evita guardar objetos improvisados y facilita futuras migraciones. |
| `lib/local-finance.ts` | `LocalNotebookCollection` | Mantiene la lista de libretas y la activa. | Hace que cada libreta tenga datos realmente separados. |
| `lib/local-finance.ts` | `newId`, `defaultNotebook`, `createBlankNotebook` | Crea identificadores y una libreta segura de inicio. | Evita depender de datos de muestra o de un servidor. |
| `lib/local-finance.ts` | `normalizeNotebook` | Migra formatos antiguos al actual. | Las actualizaciones no deben borrar las libretas de usuarios beta. |
| `lib/local-finance.ts` | `openDatabase`, `readState`, `finishTransaction`, `mutateState` | Abre IndexedDB y guarda los cambios de forma atómica. | Si un paso falla, no debe quedar medio saldo cambiado. |
| `lib/local-finance.ts` | `setupLocalNotebook`, `createLocalNotebook`, `switchLocalNotebook`, `renameLocalNotebook`, `deleteLocalNotebook` | Configura una o varias libretas y las gestiona localmente. | La primera usa los saldos de inicio; las demás nacen vacías para no duplicar dinero. |
| `lib/local-finance.ts` | `addLocalTransaction`, `updateLocalTransaction`, `deleteLocalTransaction` | Registra y corrige movimientos, revirtiendo antes el efecto anterior. | Editar $500 a $200 debe devolver $300 al saldo, no crear otra corrección artificial. |
| `lib/local-finance.ts` | `addLocalGoalContribution`, `withdrawFromLocalGoal` | Mueve dinero entre apartado y objetivo. | Evita que aportar o retirar se cuente como ingreso o gasto. |
| `lib/local-finance.ts` | `backupFileFromState`, `createLocalBackupFile`, `importLocalBackup` | Crea y restaura respaldos v1 y v2. | La restauración valida límites y campos antes de reemplazar datos. |

## Servidor, privacidad y beta

| Archivo | Partes clave | Qué hace | Por qué se decidió así |
|---|---|---|---|
| `db/schema.ts` | Tablas `betaInstallations`, `betaEvents`, `betaFeedback` | Guarda diagnóstico de beta y comentarios anónimos. | Separa completamente la observación de beta de los datos de dinero. |
| `db/schema.ts` | Tablas `betaPushSubscriptions`, `betaPaymentReminders` | Guarda solo lo necesario para avisos push. | El servidor puede avisar sin guardar una agenda financiera completa. |
| `app/api/beta/feedback/route.ts` | `POST` | Valida longitud, calificación e instalación antes de guardar el comentario. | Evita datos malformados y protege la base de spam básico. |
| `app/api/beta/telemetry/route.ts` | `POST` y `allowedEvents` | Recibe únicamente eventos permitidos de personas que aceptaron métricas. | La lista blanca impide que la app mande accidentalmente datos sensibles. |
| `app/api/push-subscriptions/route.ts` | `POST`, `DELETE` | Vincula o desactiva el navegador para avisos. | La suscripción es del dispositivo, no de una cuenta financiera. |
| `app/api/push-reminders/route.ts` | `PUT` | Actualiza los avisos calculados en el teléfono. | El servidor conserva fechas e IDs, no nombre del pago ni monto. |
| `app/api/push-config/route.ts` | `GET` | Entrega únicamente la llave pública necesaria para activar avisos. | Las claves privadas no salen del servidor. |
| `lib/web-push.ts` | `sendReminderPush`, `dispatchDueReminders` | Firma y envía avisos; reintenta o desactiva suscripciones vencidas. | Mantiene los avisos confiables y sin detalles privados. |

## Piezas preparadas para la futura cuenta

| Archivo | Situación en v14 | Uso previsto en v2.0 |
|---|---|---|
| `app/chatgpt-auth.ts` | Obtiene identidad en entornos de ChatGPT; no resuelve por sí sola el acceso público de una app instalada. | Referencia para un flujo de identidad compatible, si aplica. |
| `lib/request-user.ts` | Protege rutas antiguas de perfil y datos remotos. | Será reemplazada o unificada con el método de inicio de sesión que se confirme para usuarios públicos. |
| `db/schema.ts` — tablas `profiles`, `pockets`, `transactions`, `cards`, `reminders` | Son una primera estructura remota y no son la fuente que usa la UI v14. | Se revisarán y migrarán para que cada fila tenga dueño, libreta y reglas de acceso reales. |
| `app/api/profile`, `finance`, `pockets`, `transactions`, `cards`, `onboarding`, `export` | Son rutas de la primera versión remota. | No deben conectarse de golpe a la UI local: primero se prueba la migración de una libreta de ejemplo. |

## Calidad y entrega

| Archivo | Qué verifica |
|---|---|
| `tests/rendered-html.test.mjs` | Que la compilación entregue HTML correcto y que sigan presentes las funciones clave de las fases 2 a 5 y del tutorial v2.0. |
| `README.md` | Instrucciones técnicas del proyecto. |
| `ESTADO-DEL-PROYECTO.md` | Historial de decisiones y pruebas realizadas por fase. |
| `.openai/hosting.json` | Indica que el proyecto tiene alojamiento y servicios de datos configurados. No contiene contraseñas. |

## Lectura recomendada por función

1. **¿Cómo calcula el dinero?** `lib/local-finance.ts` → `updateLocalTransaction`, `addLocalTransaction`, `updateLocalPocket`.
2. **¿Cómo separa varias libretas?** `lib/local-finance.ts` → `LocalNotebookCollection`, `syncActiveNotebook`, `switchLocalNotebook`.
3. **¿Cómo se ven en pantalla?** `app/finance-notebook.tsx` → `totals`, `applySnapshot`, sección `Mis libretas`.
4. **¿Cómo llegan comentarios?** `app/finance-notebook.tsx` → `submitFeedback`; después `app/api/beta/feedback/route.ts`.
5. **¿Cómo se guarda un respaldo?** `lib/local-finance.ts` → `backupFileFromState`, `createLocalBackupFile`, `importLocalBackup`.
