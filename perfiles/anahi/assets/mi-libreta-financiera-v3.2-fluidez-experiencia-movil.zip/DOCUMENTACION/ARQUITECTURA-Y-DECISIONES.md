# Arquitectura y decisiones de Mi Libreta Financiera v14

## Resumen en palabras simples

Mi Libreta Financiera es una aplicación web instalable (PWA) con apariencia de libreta. Está diseñada para que una persona pueda registrar su dinero sin necesitar conocimientos financieros.

La v14 funciona primero en el teléfono: así no solicita datos personales ni información bancaria para apuntar un gasto. Esto hace que la beta sea sencilla y privada, pero también significa que una libreta no se sincroniza todavía de forma automática entre dos teléfonos. Esa es la razón técnica de que la primera fase de v2.0 sea perfiles y vinculación real de datos.

## Dónde vive cada dato

| Tipo de dato | Dónde vive hoy | Por qué |
|---|---|---|
| Movimientos, apartados, pagos, objetivos y varias libretas | En el teléfono, mediante IndexedDB | Privacidad, uso sin cuenta y funcionamiento rápido. |
| Foto y tema de cada libreta | En el teléfono | Son preferencias, no requieren nube. |
| Respaldo manual | Archivo JSON que el usuario guarda | Permite recuperar información antes de reinstalar o cambiar de teléfono. |
| Comentarios de beta | Base de datos remota | Para que el propietario pueda recibir opiniones anónimas. |
| Métricas | Base de datos remota, solo si la persona acepta | Conocer uso y fallos sin recoger montos, notas ni nombres. |
| Avisos de pago | Base de datos remota con identificador de instalación | Poder recordar pagos sin subir el contenido financiero de la libreta. |

## Regla de cálculo más importante

La aplicación separa el dinero en tres cantidades:

- **Disponible:** suma únicamente los apartados marcados como `available`. Es el dinero que puede gastarse sin romper un ahorro u objetivo.
- **Separado:** suma los apartados marcados como `reserved`.
- **Objetivos:** suma lo guardado dentro de metas.

El total real registrado es la suma de las tres. Una transferencia no es un ingreso: resta un apartado y suma otro por la misma cantidad. Esta regla evita el error que mostraba más dinero disponible del que realmente existía.

## Decisiones de diseño y su motivo

### Centavos en vez de decimales

El almacenamiento interno usa valores como `amountCents` o `balanceCents`. Por ejemplo, $12.50 se guarda como `1250`. Así se evitan errores comunes de los decimales de JavaScript al hacer operaciones financieras.

### Una sola fuente local de verdad

`lib/local-finance.ts` concentra todas las operaciones que cambian dinero. La pantalla nunca cambia un saldo por su cuenta: pide a esta capa crear, editar o eliminar el movimiento y recibe una copia actualizada. El resultado es que el cálculo y el respaldo trabajan con la misma lógica.

### Normalización y migraciones

Al abrir la aplicación, `normalizeNotebook` revisa datos guardados por versiones anteriores. Añade campos que no existían, convierte tarjetas antiguas a la agenda de pagos y crea la primera libreta para instalaciones que aún no tenían varias. Esto protege a las personas que ya llevaban semanas apuntando dinero.

### Eliminaciones con protección

No se puede borrar un apartado que tiene dinero o movimientos vinculados. No se puede borrar la última libreta. Y un objetivo con dinero debe vaciarse mediante un retiro antes de borrarse. Son reglas para evitar una pérdida silenciosa de datos.

### Comentarios y métricas separados de los datos financieros

El identificador de beta es un UUID aleatorio del dispositivo, no nombre, correo ni cuenta bancaria. El servidor de comentarios no recibe la libreta, sus montos, las notas, las fotografías ni los nombres de tarjetas. Las métricas son opcionales y solo indican acciones generales, como abrir la app o guardar un apunte.

### Recordatorios discretos

Para proteger la información, los avisos push dicen solamente que existe un pago próximo. Los detalles, como proveedor o monto, permanecen en el teléfono.

## Estructura de la aplicación

```mermaid
flowchart TD
  U[Persona usuaria] --> UI[FinanceNotebook]
  UI --> L[local-finance.ts]
  L --> IDB[IndexedDB del teléfono]
  UI --> B[API de beta]
  B --> D1[D1: comentarios, métricas y avisos]
  UI --> R[Respaldo JSON]
```

La flecha hacia D1 no contiene los movimientos financieros: esa separación es intencional.

## Qué funciona en la v14

- Ingresos, gastos y transferencias con edición, corrección y eliminación.
- Dinero disponible separado de ahorro, apartados y objetivos.
- Agenda de pagos con categorías, prioridad, estado y recordatorios 5/3/1 días antes.
- Objetivos de corto, mediano y largo plazo con aportaciones y retiros protegidos.
- Hasta 12 libretas locales, totalmente separadas, con comparador.
- Respaldo y restauración de todas las libretas.
- Comentarios anónimos y métricas voluntarias.

## Limitación actual que v2.0 resolverá

Existe una estructura anterior de perfiles y datos remotos en `db/schema.ts` y rutas como `app/api/profile`, pero la experiencia v14 actualmente usa `local-finance.ts` como fuente principal. Por eso no sería correcto decir que ya hay una cuenta enlazada: una cuenta real debe identificar a la persona de forma segura, autorizar cada petición en el servidor y migrar sus libretas locales sin duplicarlas ni perderlas.

La fase de perfiles debe unir ambos mundos con estas garantías:

1. La persona decide cuándo crear o vincular su perfil.
2. Puede conservar una libreta solo local si así lo prefiere.
3. La migración muestra qué libretas se subirán antes de confirmar.
4. Todos los registros tendrán un propietario verificado en el servidor.
5. Ninguna cuenta podrá leer los registros de otra.
6. El respaldo local seguirá existiendo incluso con sincronización.
