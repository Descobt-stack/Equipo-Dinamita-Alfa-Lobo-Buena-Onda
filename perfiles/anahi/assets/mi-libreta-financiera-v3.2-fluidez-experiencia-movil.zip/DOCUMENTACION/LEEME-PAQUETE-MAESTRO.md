# Mi Libreta Financiera — paquete maestro v14

Este paquete es el punto de restauración de la **versión 14**, cerrada antes de iniciar la versión 2.0.

La aplicación de esta versión permite llevar ingresos, gastos, transferencias, apartados, agenda de pagos, objetivos y hasta 12 libretas independientes en un mismo teléfono. También permite comparar sus saldos sin mezclar la información.

## Qué encontrarás aquí

- `app/`: pantallas de la aplicación y rutas que reciben únicamente datos de beta, recordatorios o la futura capa de cuenta.
- `lib/local-finance.ts`: la pieza más importante de la v14; guarda cada libreta dentro del teléfono, protege los cálculos y crea respaldos.
- `db/schema.ts`: estructura de la base de datos remota usada para comentarios anónimos, métricas consentidas y avisos push. Incluye estructuras preparadas para una futura cuenta, pero **no es aún la fuente de verdad de las libretas**.
- `DOCUMENTACION/ARQUITECTURA-Y-DECISIONES.md`: explicación de cómo funciona todo y por qué se tomaron las decisiones principales.
- `DOCUMENTACION/MAPA-DEL-CODIGO.md`: guía por archivo, responsabilidad y secciones clave.
- `DOCUMENTACION/PLAN-V2.0-PROPUESTO.md`: plan provisional de la nueva versión; se actualizará al recibir las funciones que los evaluadores sí pagarían.
- `ESTADO-DEL-PROYECTO.md`: historial de las cinco fases ya cerradas.

## Cómo leerlo sin saber programación

1. Empieza por `ARQUITECTURA-Y-DECISIONES.md`.
2. Revisa la fase que te interese dentro de `ESTADO-DEL-PROYECTO.md`.
3. Si quieres saber dónde se hizo algo, búscalo en `MAPA-DEL-CODIGO.md`.
4. Después abre el archivo indicado. Los comentarios en español marcan decisiones, seguridad, cálculos y migraciones; no se añadieron comentarios inútiles a cada etiqueta visual para que el código siga legible.

## Regla de seguridad importante

En v14, los movimientos financieros reales viven en el almacenamiento del teléfono (IndexedDB). La nube solo recibe comentarios anónimos, métricas voluntarias y datos técnicos mínimos para recordatorios. Por ello, una "cuenta" o "perfil" que vincule teléfonos debe construirse como una fase propia: no se debe simular con un nombre guardado localmente.

## Antes de hacer cambios

- Conserva este ZIP sin modificar: es la base de recuperación de v14.
- Para cambiar la app, trabaja en una copia y prueba con datos de ejemplo.
- No reemplaces el respaldo de un usuario sin que él conserve antes su propia copia JSON.
- Las nuevas funciones se agruparán en v2.0 por valor, seguridad y dependencia técnica, no solo por el orden en que fueron sugeridas.
