# Mi Libreta Financiera v2.0 — plan provisional

> Estado: propuesta inicial. Se reorganizará cuando lleguen los puntos de los evaluadores y las funciones por las que sí estarían dispuestos a pagar.

## Punto de partida cerrado

La v14 es la base final de la primera etapa. Ya incluye varias libretas y comparación local. No se reabrirán las cinco fases anteriores salvo que aparezca un error real.

## Fase 0 — Cierre y respaldo de v14

**Objetivo:** poder retomar el proyecto aunque se cambie de chat o teléfono.

- Paquete maestro de código y documentación en español.
- Historial de decisiones, reglas de cálculo y mapa de archivos.
- Pruebas de la base actual antes de tocar funciones nuevas.
- Registro de riesgos técnicos conocidos.

**Resultado esperado:** un ZIP recuperable de v14, sin publicar cambios de comportamiento.

## Fase 1 — Perfiles, cuentas y vinculación segura

**Objetivo:** que una persona pueda crear o vincular un perfil real y, si quiere, conservar sus libretas entre teléfonos.

- Pantalla clara: continuar solo en este teléfono o vincular/crear perfil.
- Identidad verificada; no se usará solo un nombre local como si fuera una cuenta.
- Migración voluntaria: mostrar primero qué libretas locales se vincularán y pedir confirmación.
- Cada libreta, movimiento, apartado, pago y objetivo tendrá dueño y libreta en el servidor.
- Sincronización inicial y resolución prudente de conflictos; nunca sobrescribir datos silenciosamente.
- Copia local y respaldo JSON siguen disponibles.
- Cerrar sesión, desvincular teléfono y explicación de privacidad.

**Dependencia:** debemos confirmar el método de inicio de sesión válido para una app pública. Si la plataforma actual no permite un inicio de sesión externo seguro, se mantendrá la base local, se preparará la migración y se integrará un proveedor de identidad adecuado; no se publicará un perfil falso o inseguro.

## Fase 2 — Panel privado del propietario y beta controlada

**Objetivo:** que puedas leer comentarios y seguir el comportamiento de la beta sin ver datos financieros personales.

- Buzón privado: fecha, calificación, pantalla y mensaje anónimo.
- Métricas agregadas y consentidas: instalaciones, aperturas, uso de funciones y errores.
- Estado de evaluadores y acceso de beta, si se define una lista privada de correos.
- Sin mostrar saldos, movimientos, notas, bancos ni fotografías de usuarios.

## Fase 3 — Comprensión del dinero y análisis útil

**Objetivo:** explicar gastos sin hablar como una aplicación bancaria complicada.

- Porcentaje de ingresos usado por categoría y periodo.
- Comparación con meses anteriores cuando ya haya datos suficientes.
- Alertas comprensibles: pagos cercanos, gasto alto o saldo disponible bajo.
- Mantener siempre separadas las transferencias del dinero que entra o sale de verdad.

## Fase 4 — Reportes y exportaciones

**Objetivo:** entregar una vista mensual clara que sirva para revisar o compartir.

- Reporte mensual simple desde una libreta individual.
- Exportación a PDF y, si aporta valor, Excel/CSV.
- Elegir mes y libreta antes de generar el archivo.
- Comparador exportable de varias libretas solo después de validar que no confunda los totales.

## Fase 5 — Guía inicial, accesibilidad y confianza

**Objetivo:** que alguien sin experiencia en finanzas pueda entender la app desde el primer día.

- Tutorial opcional y reutilizable, no obligatorio cada vez que se abra la app.
- Explicación de Disponible, Separado, Objetivos y Pagos.
- Mejora de textos, tamaño táctil, contraste y funcionamiento en pantallas pequeñas.
- Revisión de errores, rendimiento y restauración de datos.

## Fase 6 — Funciones de pago y preparación para distribución

**Objetivo:** decidir qué vale la pena cobrar según uso real, no por suposición.

- Separar funciones básicas gratuitas de funciones premium que los evaluadores consideren valiosas.
- Propuesta de precios después de conocer uso, retención y comentarios.
- Preparar requisitos de beta de Android y, después, iPhone.
- No activar cobros reales hasta que el flujo de cuenta, privacidad y restauración funcione de forma estable.

## Criterio para ordenar los nuevos puntos

Cada idea que llegue se anotará con cinco datos:

1. Qué problema concreto resuelve.
2. Para quién sirve.
3. Si necesita cuenta o nube.
4. Riesgo de afectar cálculos, privacidad o respaldos.
5. Si es básica, premium, o necesita validarse primero con beta.

Luego se coloca en la fase que corresponda. Si una tarea depende de algo que la plataforma actual no permite, se intentará una alternativa segura; si aun así no es viable, se salta sin bloquear las demás y se documenta la razón exacta.
