# Control del paquete maestro

## Identificación

- Base funcional: Mi Libreta Financiera v14 — Fase 5: varias libretas y comparador local.
- Preparado como inicio de v2.0: 9 de agosto de 2026.
- Objetivo: restaurar, estudiar y continuar el proyecto sin cambiar el comportamiento publicado.

## Validación realizada al preparar este paquete

- Compilación de producción: aprobada.
- Validación del artefacto de la aplicación: aprobada.
- Pruebas automatizadas: 5 aprobadas, 0 fallidas.
- Comprobaciones incluidas: resumen disponible/separado/total, comentarios, agenda de pagos, objetivos con retiro protegido, varias libretas y respaldo completo.

## Qué se modificó en esta copia

- Se añadieron documentos en `DOCUMENTACION/`.
- Se añadieron comentarios explicativos en español a los módulos de negocio, privacidad, almacenamiento, rutas y pruebas.
- No se modificó la lógica financiera, la interfaz ni los datos de usuarios.

## Qué no contiene

- Credenciales, claves privadas ni datos de los evaluadores.
- Datos financieros de personas usuarias.
- `node_modules`, resultado de compilación ni carpetas internas de control de versiones; se omiten para que el ZIP sea portátil y ligero.

## Para restaurar esta base

1. Extrae el ZIP en una carpeta nueva.
2. Conserva las carpetas `app`, `lib`, `db`, `public`, `scripts`, `tests` y `.openai`.
3. Instala las dependencias definidas por `package-lock.json`.
4. Ejecuta las pruebas antes de hacer cambios.
5. Si se inicia la v2.0, registra la nueva fase en `DOCUMENTACION/PLAN-V2.0-PROPUESTO.md` y actualiza `ESTADO-DEL-PROYECTO.md` al cerrarla.
