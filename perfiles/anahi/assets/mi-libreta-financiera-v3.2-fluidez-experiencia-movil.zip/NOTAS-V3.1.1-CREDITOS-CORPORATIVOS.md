# Mi Libreta Financiera v3.1.1 — Créditos corporativos

Esta actualización modifica únicamente el pie de créditos que aparece al final
de todas las pantallas de la aplicación.

## Créditos mostrados

- Mi Libreta Financiera · Corporativo Freelancers LAJ
- Dirección creativa: Anahi Patiño
- Dirección de Marketing: Luis Rosas
- Desarrollador: Josue Villarruel
- Versión beta cerrada · © 2026 · Todos los derechos reservados

No se modificaron las libretas, movimientos, saldos, pagos, objetivos,
respaldos, configuraciones ni funciones de seguridad.
