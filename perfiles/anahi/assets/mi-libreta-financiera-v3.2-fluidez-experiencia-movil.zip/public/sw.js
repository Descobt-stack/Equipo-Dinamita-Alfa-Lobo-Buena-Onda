self.addEventListener("install", (event) => {
  // Nueva versión de caché: fuerza a que los teléfonos reemplacen recursos
  // guardados antes de corregir la vista de instalación y su icono.
  event.waitUntil(caches.open("mi-libreta-shell-v8").then((cache) => cache.addAll([
    "/",
    "/manifest.webmanifest",
    "/icon-192.png",
    "/icon-512.png",
    "/favicon.svg"
  ])).then(() => self.skipWaiting()));
});
self.addEventListener("activate", (event) => event.waitUntil(Promise.all([
  caches.keys().then((keys) => Promise.all(keys.filter((key) => key.startsWith("mi-libreta-shell-") && key !== "mi-libreta-shell-v8").map((key) => caches.delete(key)))),
  self.clients.claim()
])));
self.addEventListener("fetch", (event) => {
  if (event.request.method !== "GET") return;
  const requestUrl = new URL(event.request.url);
  if (requestUrl.origin !== self.location.origin || requestUrl.pathname.startsWith("/api/")) return;
  if (event.request.mode === "navigate") {
    event.respondWith(fetch(event.request).then((response) => {
      const copy = response.clone();
      event.waitUntil(caches.open("mi-libreta-shell-v8").then((cache) => cache.put("/", copy)));
      return response;
    }).catch(() => caches.match("/")));
    return;
  }
  event.respondWith(caches.match(event.request).then((cached) => cached || fetch(event.request).then((response) => {
    if (response.ok) {
      const copy = response.clone();
      event.waitUntil(caches.open("mi-libreta-shell-v8").then((cache) => cache.put(event.request, copy)));
    }
    return response;
  })));
});
self.addEventListener("push", (event) => {
  let payload = {};
  try { payload = event.data ? event.data.json() : {}; } catch { payload = {}; }
  event.waitUntil(self.registration.showNotification(payload.title || "Recordatorio de Mi Libreta", {
    body: payload.body || "Tienes un pago próximo. Abre tu libreta para revisar los detalles.",
    icon: "/icon-192.png",
    badge: "/icon-192.png",
    tag: payload.tag || "payment-reminder",
    renotify: true,
    timestamp: Date.now(),
    data: { url: payload.url || "/" }
  }));
});
self.addEventListener("notificationclick", (event) => {
  event.notification.close();
  event.waitUntil(self.clients.matchAll({ type: "window", includeUncontrolled: true }).then((clients) => {
    const existing = clients.find((client) => "focus" in client);
    return existing ? existing.focus() : self.clients.openWindow(event.notification.data?.url || "/");
  }));
});
