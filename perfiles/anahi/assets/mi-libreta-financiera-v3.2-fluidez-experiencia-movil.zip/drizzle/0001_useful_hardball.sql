CREATE TABLE `beta_events` (
	`id` text PRIMARY KEY NOT NULL,
	`install_id` text NOT NULL,
	`event_name` text NOT NULL,
	`duration_ms` integer,
	`screen` text,
	`created_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL
);
--> statement-breakpoint
CREATE INDEX `beta_events_install_date_idx` ON `beta_events` (`install_id`,`created_at`);--> statement-breakpoint
CREATE TABLE `beta_feedback` (
	`id` text PRIMARY KEY NOT NULL,
	`install_id` text NOT NULL,
	`rating` integer NOT NULL,
	`message` text DEFAULT '' NOT NULL,
	`screen` text DEFAULT 'general' NOT NULL,
	`created_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL
);
--> statement-breakpoint
CREATE INDEX `beta_feedback_install_date_idx` ON `beta_feedback` (`install_id`,`created_at`);--> statement-breakpoint
CREATE TABLE `beta_installations` (
	`install_id` text PRIMARY KEY NOT NULL,
	`platform` text DEFAULT 'unknown' NOT NULL,
	`app_version` text DEFAULT 'beta-1' NOT NULL,
	`first_seen_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL,
	`last_seen_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL
);
