CREATE TABLE `cards` (
	`id` text PRIMARY KEY NOT NULL,
	`user_email` text NOT NULL,
	`alias` text NOT NULL,
	`amount_due_cents` integer DEFAULT 0 NOT NULL,
	`due_date` text,
	`status` text DEFAULT 'current' NOT NULL,
	`color` text DEFAULT 'purple' NOT NULL,
	`created_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL,
	`updated_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL
);
--> statement-breakpoint
CREATE INDEX `cards_user_idx` ON `cards` (`user_email`);--> statement-breakpoint
CREATE TABLE `pockets` (
	`id` text PRIMARY KEY NOT NULL,
	`user_email` text NOT NULL,
	`name` text NOT NULL,
	`type` text DEFAULT 'custom' NOT NULL,
	`color` text DEFAULT 'violet' NOT NULL,
	`icon` text DEFAULT '✦' NOT NULL,
	`balance_cents` integer DEFAULT 0 NOT NULL,
	`archived` integer DEFAULT false NOT NULL,
	`created_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL
);
--> statement-breakpoint
CREATE INDEX `pockets_user_idx` ON `pockets` (`user_email`);--> statement-breakpoint
CREATE TABLE `profiles` (
	`email` text PRIMARY KEY NOT NULL,
	`display_name` text NOT NULL,
	`notebook_title` text DEFAULT 'Mi libreta personal' NOT NULL,
	`income_frequency` text DEFAULT 'quincenal' NOT NULL,
	`start_mode` text DEFAULT 'today' NOT NULL,
	`start_date` text NOT NULL,
	`theme` text DEFAULT 'purple' NOT NULL,
	`profile_photo_key` text,
	`onboarding_completed` integer DEFAULT false NOT NULL,
	`created_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL,
	`updated_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL
);
--> statement-breakpoint
CREATE TABLE `push_subscriptions` (
	`id` text PRIMARY KEY NOT NULL,
	`user_email` text NOT NULL,
	`endpoint` text NOT NULL,
	`p256dh` text NOT NULL,
	`auth` text NOT NULL,
	`user_agent` text DEFAULT '' NOT NULL,
	`active` integer DEFAULT true NOT NULL,
	`created_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL
);
--> statement-breakpoint
CREATE INDEX `push_user_idx` ON `push_subscriptions` (`user_email`);--> statement-breakpoint
CREATE TABLE `reminders` (
	`id` text PRIMARY KEY NOT NULL,
	`user_email` text NOT NULL,
	`card_id` text,
	`title` text NOT NULL,
	`due_at` text NOT NULL,
	`remind_days_before` integer DEFAULT 3 NOT NULL,
	`status` text DEFAULT 'pending' NOT NULL,
	`created_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL
);
--> statement-breakpoint
CREATE INDEX `reminders_user_due_idx` ON `reminders` (`user_email`,`due_at`);--> statement-breakpoint
CREATE TABLE `transactions` (
	`id` text PRIMARY KEY NOT NULL,
	`user_email` text NOT NULL,
	`kind` text NOT NULL,
	`amount_cents` integer NOT NULL,
	`source_pocket_id` text,
	`target_pocket_id` text,
	`purpose` text NOT NULL,
	`note` text DEFAULT '' NOT NULL,
	`occurred_at` text NOT NULL,
	`source` text DEFAULT 'manual' NOT NULL,
	`status` text DEFAULT 'active' NOT NULL,
	`change_reason` text,
	`created_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL,
	`updated_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL
);
--> statement-breakpoint
CREATE INDEX `transactions_user_date_idx` ON `transactions` (`user_email`,`occurred_at`);--> statement-breakpoint
CREATE INDEX `transactions_source_pocket_idx` ON `transactions` (`source_pocket_id`);