CREATE TABLE `beta_payment_reminders` (
	`id` text PRIMARY KEY NOT NULL,
	`install_id` text NOT NULL,
	`remind_at` text NOT NULL,
	`status` text DEFAULT 'pending' NOT NULL,
	`last_attempt_at` text,
	`sent_at` text,
	`created_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL,
	`updated_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL
);
--> statement-breakpoint
CREATE INDEX `beta_payment_reminders_due_idx` ON `beta_payment_reminders` (`status`,`remind_at`);--> statement-breakpoint
CREATE INDEX `beta_payment_reminders_install_idx` ON `beta_payment_reminders` (`install_id`);--> statement-breakpoint
CREATE TABLE `beta_push_subscriptions` (
	`id` text PRIMARY KEY NOT NULL,
	`install_id` text NOT NULL,
	`endpoint` text NOT NULL,
	`p256dh` text NOT NULL,
	`auth` text NOT NULL,
	`timezone` text DEFAULT 'America/Mexico_City' NOT NULL,
	`active` integer DEFAULT true NOT NULL,
	`created_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL,
	`updated_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `beta_push_endpoint_uidx` ON `beta_push_subscriptions` (`endpoint`);--> statement-breakpoint
CREATE INDEX `beta_push_install_idx` ON `beta_push_subscriptions` (`install_id`);