/** Cloudflare Worker entry point for the vinext-starter template. */
import { handleImageOptimization, DEFAULT_DEVICE_SIZES, DEFAULT_IMAGE_SIZES } from "vinext/server/image-optimization";
import handler from "vinext/server/app-router-entry";
import { setFinanceRuntimeEnv } from "../lib/runtime-env";
import { dispatchDueReminders } from "../lib/web-push";

interface Env {
  ASSETS: Fetcher;
  DB: D1Database;
  BUCKET: R2Bucket;
  VAPID_SUBJECT?: string;
  VAPID_SERVER_PUBLIC_KEY?: string;
  VAPID_SERVER_PRIVATE_KEY?: string;
  REMINDER_CRON_SECRET?: string;
  IMAGES: {
    input(stream: ReadableStream): {
      transform(options: Record<string, unknown>): {
        output(options: { format: string; quality: number }): Promise<{ response(): Response }>;
      };
    };
  };
}

interface ExecutionContext {
  waitUntil(promise: Promise<unknown>): void;
  passThroughOnException(): void;
}

interface ScheduledController {
  scheduledTime: number;
  cron: string;
}

function equalSecret(left: string, right: string) {
  if (!left || left.length !== right.length) return false;
  let mismatch = 0;
  for (let index = 0; index < left.length; index += 1) mismatch |= left.charCodeAt(index) ^ right.charCodeAt(index);
  return mismatch === 0;
}

let lastOpportunisticDispatch = 0;

// Image security config. SVG sources with .svg extension auto-skip the
// optimization endpoint on the client side (served directly, no proxy).
// To route SVGs through the optimizer (with security headers), set
// dangerouslyAllowSVG: true in next.config.js and uncomment below:
// const imageConfig: ImageConfig = { dangerouslyAllowSVG: true };

const worker = {
  async fetch(request: Request, env: Env, ctx: ExecutionContext): Promise<Response> {
    setFinanceRuntimeEnv(env);
    const url = new URL(request.url);

    if (url.pathname === "/_tasks/payment-reminders" && request.method === "POST") {
      if (!env.REMINDER_CRON_SECRET || !equalSecret(request.headers.get("x-reminder-secret") ?? "", env.REMINDER_CRON_SECRET)) {
        return Response.json({ error: "No autorizado." }, { status: 401 });
      }
      return Response.json(await dispatchDueReminders(env));
    }

    if (url.pathname === "/" && Date.now() - lastOpportunisticDispatch > 15 * 60_000) {
      lastOpportunisticDispatch = Date.now();
      ctx.waitUntil(dispatchDueReminders(env).catch(() => undefined));
    }

    if (url.pathname === "/_vinext/image") {
      const allowedWidths = [...DEFAULT_DEVICE_SIZES, ...DEFAULT_IMAGE_SIZES];
      return handleImageOptimization(request, {
        fetchAsset: (path) => env.ASSETS.fetch(new Request(new URL(path, request.url))),
        transformImage: async (body, { width, format, quality }) => {
          const result = await env.IMAGES.input(body).transform(width > 0 ? { width } : {}).output({ format, quality });
          return result.response();
        },
      }, allowedWidths);
    }

    return handler.fetch(request, env, ctx);
  },

  async scheduled(_controller: ScheduledController, env: Env, ctx: ExecutionContext): Promise<void> {
    setFinanceRuntimeEnv(env);
    ctx.waitUntil(dispatchDueReminders(env).catch(() => undefined));
  },
};

export default worker;
