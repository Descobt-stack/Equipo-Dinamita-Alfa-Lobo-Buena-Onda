# Mi Libreta Financiera v3.2 — Fluidez y experiencia móvil

Esta versión mejora la comodidad de uso sin modificar datos financieros.

## Cambios

- Navegación entre secciones con una transición breve y discreta.
- Cada nueva sección inicia desde arriba para evitar llegar a media pantalla.
- Respuesta táctil más inmediata en botones y un indicador visible al enfocarlos.
- Las hojas y formularios usan la altura visible real del teléfono cuando el
  teclado está abierto, para no ocultar campos o botones.
- Al tocar un campo, la app lo centra de forma suave para mantenerlo a la vista.
- Los avisos breves respetan la zona segura inferior del teléfono y ahora se
  anuncian correctamente a lectores de pantalla.
- Se respetan los ajustes del sistema de personas que prefieren menos animación.

## Datos protegidos

No se modificaron libretas, movimientos, pagos, objetivos, reportes, respaldos
ni preferencias de seguridad.
