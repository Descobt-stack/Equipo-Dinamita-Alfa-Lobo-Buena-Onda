"use client";

/* eslint-disable @next/next/no-img-element -- Los iconos de instalación se
 * solicitan directamente para evitar el optimizador que mostró una imagen rota
 * en algunos teléfonos. */

// Pantalla principal de la beta v14. Se ejecuta en el navegador porque la
// libreta financiera real permanece en IndexedDB del teléfono, no en el HTML.
import { Component, ChangeEvent, FormEvent, useEffect, useMemo, useState, type CSSProperties, type ReactNode } from "react";
import Image from "next/image";
import Onboarding from "./onboarding";
import type { MonthlyReportExport } from "@/lib/monthly-report-export";
import {
  addLocalGoal,
  addLocalGoalContribution,
  archiveLocalNotebook,
  addLocalCard,
  addLocalPocket,
  addLocalTransaction,
  createLocalNotebook,
  createLocalBackupFile,
  deleteLocalNotebook,
  deleteLocalPocket,
  deleteLocalGoal,
  deleteLocalCard,
  deleteLocalTransaction,
  getLocalSafetyCopyStatus,
  getPersistentStorageStatus,
  importLocalBackup,
  loadLocalNotebook,
  loadLocalNotebookComparison,
  resetLocalNotebook,
  requestPersistentStorage,
  restoreLocalSafetyCopy,
  restoreLocalNotebook,
  renameLocalNotebook,
  saveLocalBackup,
  setAnalyticsConsent,
  setLocalPhoto,
  switchLocalNotebook,
  setLocalCardStatus,
  updateLocalCard,
  updateLocalGoal,
  updateLocalPocket,
  updateLocalProfile,
  updateLocalTransaction,
  type LocalNotebookSnapshot,
  type LocalNotebookInfo,
  type LocalNotebookSummary,
  type LocalNotebookMonthComparison,
  type LocalTransaction,
  type LocalSafetyCopyStatus,
  type LocalGoalTerm,
  type LocalPaymentCategory,
  type LocalPaymentPriority,
  type LocalPaymentRecurrence,
  type LocalPocketRole,
  withdrawFromLocalGoal,
} from "@/lib/local-finance";

// Estos tipos describen el formato de vista. La capa local usa centavos;
// aquí los montos se convierten a pesos únicamente para mostrarse a la persona.
type Tab = "inicio" | "movimientos" | "tarjetas" | "objetivos" | "reportes" | "ajustes";
type MovementKind = "ingreso" | "gasto" | "transferencia";

type Pocket = {
  id: string;
  name: string;
  balance: number;
  icon: string;
  tone: "violet" | "rose" | "blue" | "green";
  role: LocalPocketRole;
};

type Movement = {
  id: string;
  kind: MovementKind;
  amount: number;
  purpose: string;
  note: string;
  pocket: string;
  date: string;
  time: string;
  occurredAt: string;
  sourcePocketId: string;
  targetPocketId: string | null;
};

type StoredCard = {
  id: string;
  alias: string;
  category: LocalPaymentCategory;
  provider: string;
  amount: number;
  dueDate: string | null;
  reminderDays: number[];
  priority: LocalPaymentPriority;
  recurrence: LocalPaymentRecurrence;
  status: "current" | "paid";
  color: string;
};

type Goal = {
  id: string;
  name: string;
  purpose: string;
  term: LocalGoalTerm;
  target: number;
  saved: number;
  targetDate: string;
  icon: string;
  color: Pocket["tone"];
  status: "active" | "completed";
};

type GoalMovement = {
  id: string;
  goalId: string;
  pocketId: string;
  kind: "contribution" | "withdrawal";
  amount: number;
  note: string;
  occurredAt: string;
};

type GoalTransferMode = "contribution" | "withdrawal";

type PaymentFilter = "todas" | LocalPaymentCategory;
type PaymentSort = "prioridad" | "fecha" | "monto";

type ProfileState = {
  displayName: string;
  notebookTitle: string;
  incomeFrequency: string;
  startDate: string;
  theme: string;
  hasPhoto: boolean;
  photoDataUrl: string | null;
};

type InstallPromptEvent = Event & {
  prompt(): Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed"; platform: string }>;
};

type PushState = "idle" | "enabling" | "active" | "error" | "unsupported";
type TutorialTopicId = "inicio" | "apuntes" | "agregar" | "pagos" | "objetivos" | "reportes" | "libretas" | "ajustes";
type TutorialRun = { topicIndex: number; singleTopic: boolean; askForFeedback: boolean };

// El tutorial es una preferencia de la instalación, no información financiera.
// Se guarda por separado para que pueda aparecer una vez también a quienes ya
// tenían datos antes de esta versión, sin tocar su libreta ni sus saldos.
const TUTORIAL_STATUS_KEY = "libreta-v2-tutorial-status";
// Esta decisión no es financiera: solo evita repetir la bienvenida de
// instalación cada vez que la persona abre el mismo navegador.
const INSTALL_ENTRY_STATUS_KEY = "libreta-v2-install-entry-status";
const LAST_BACKUP_AT_KEY = "libreta-v3-last-backup-at";

// Datos de ejemplo para el primer render. Se reemplazan al cargar la libreta
// real; nunca se guardan sobre los datos de una persona.
const initialPockets: Pocket[] = [
  { id: "daily", name: "Gastos diarios", balance: 2350, icon: "☕", tone: "rose", role: "available" },
  { id: "home", name: "Ahorro casa", balance: 6200, icon: "⌂", tone: "violet", role: "reserved" },
  { id: "emergency", name: "Emergencias", balance: 4800, icon: "✦", tone: "blue", role: "reserved" },
  { id: "fun", name: "Gustos", balance: 1200, icon: "☺", tone: "green", role: "reserved" },
];

const initialMovements: Movement[] = [
  { id: "m1", kind: "gasto", amount: 850, purpose: "Pago de despensa", note: "Compra semanal", pocket: "Gastos diarios", date: "4 ago 2026", time: "18:42", occurredAt: "2026-08-04T18:42:00.000Z", sourcePocketId: "daily", targetPocketId: null },
  { id: "m2", kind: "ingreso", amount: 6000, purpose: "Ingreso quincenal", note: "", pocket: "Gastos diarios", date: "4 ago 2026", time: "09:15", occurredAt: "2026-08-04T09:15:00.000Z", sourcePocketId: "daily", targetPocketId: null },
  { id: "m3", kind: "transferencia", amount: 1200, purpose: "Separar ahorro", note: "Meta de agosto", pocket: "Ahorro casa", date: "4 ago 2026", time: "09:20", occurredAt: "2026-08-04T09:20:00.000Z", sourcePocketId: "daily", targetPocketId: "home" },
];

const paymentCategories: Array<{ id: LocalPaymentCategory; label: string; icon: string }> = [
  { id: "tarjeta", label: "Tarjetas", icon: "▰" },
  { id: "luz", label: "Luz", icon: "◉" },
  { id: "internet", label: "Internet", icon: "⌁" },
  { id: "renta", label: "Renta", icon: "⌂" },
  { id: "prestamo", label: "Préstamo", icon: "▥" },
  { id: "entretenimiento", label: "Entretenimiento", icon: "▣" },
  { id: "otro", label: "Otro", icon: "◇" },
];

const priorityRank: Record<LocalPaymentPriority, number> = { relevante: 0, poco_relevante: 1, irrelevante: 2 };
const goalTerms: Array<{ id: LocalGoalTerm; label: string; hint: string }> = [
  { id: "corto", label: "Corto plazo", hint: "Hasta 1 año" },
  { id: "mediano", label: "Mediano plazo", hint: "1 a 3 años" },
  { id: "largo", label: "Largo plazo", hint: "Más de 3 años" },
];
const goalIcons = ["◎", "⌂", "✈", "▣", "★", "♢", "☀", "✦"];
const appOpenedAt = Date.now();

// Cada lección lleva a la pantalla verdadera que explica. Así la persona ve
// dónde está la función, pero el tutorial no abre formularios ni registra nada.
const tutorialTopics: Array<{
  id: TutorialTopicId;
  label: string;
  icon: string;
  tab: Tab;
  title: string;
  description: string;
  tip: string;
}> = [
  { id: "inicio", label: "Inicio", icon: "⌂", tab: "inicio", title: "Inicio: el resumen de tu dinero", description: "Muestra lo importante de un vistazo: Disponible para usar hoy, Apartados que decidiste reservar, Objetivos y el total guardado en esta libreta.", tip: "Disponible no incluye ahorro, apartados ni metas; así sabes cuánto puedes gastar sin desordenarte." },
  { id: "apuntes", label: "Apuntes", icon: "≡", tab: "movimientos", title: "Apuntes: tu historial", description: "Aquí quedan guardados todos tus ingresos, gastos y transferencias con fecha, motivo y apartado. También puedes corregir un dato equivocado.", tip: "Un apunte es el registro de algo que ya pasó; revísalo por mes para entender en qué se fue tu dinero." },
  { id: "agregar", label: "Botón +", icon: "＋", tab: "inicio", title: "Botón +: agrega un movimiento", description: "Este botón abre el cuadro rápido para registrar: Ingreso (dinero que entra), Gasto (dinero que sale) o Transferir (mover dinero entre tus apartados).", tip: "Transferir no es un ingreso ni un gasto: solo cambia el dinero de lugar dentro de la misma libreta." },
  { id: "pagos", label: "Pagos", icon: "▤", tab: "tarjetas", title: "Pagos: fechas que no se te pasan", description: "Guarda servicios, renta, préstamos, tarjetas o suscripciones: cuánto debes pagar, para cuándo y qué tan importante es. Elige si será un pago único o se repetirá cada mes.", tip: "Los pagos son una agenda y no descuentan tu saldo por sí solos: registra el gasto con + cuando realmente pagues." },
  { id: "objetivos", label: "Objetivos", icon: "◎", tab: "objetivos", title: "Objetivos: planea una meta", description: "Crea una meta con cantidad y fecha. Al aportar, apartas dinero real desde una de tus bolsas para saber cuánto llevas.", tip: "Si retiras de una meta, el dinero vuelve al apartado que tú elijas; nunca aparece como ingreso nuevo." },
  { id: "reportes", label: "Reporte", icon: "▥", tab: "reportes", title: "Reporte: entiende tu mes", description: "Compara lo que entró con lo que salió, revisa tu cierre y mira qué porcentaje de tus ingresos representó cada gasto.", tip: "Un porcentaje te dice, por ejemplo, cuántos pesos de cada $100 que entraron se usaron en un gasto." },
  { id: "libretas", label: "Mis libretas", icon: "▤", tab: "ajustes", title: "Mis libretas: separa propósitos", description: "Desde el nombre de arriba o Ajustes puedes crear, cambiar, renombrar, borrar o comparar libretas como Personal, Amor, Casa o Negocio.", tip: "Cada libreta tiene sus propios apuntes, pagos y objetivos: los saldos nunca se mezclan." },
  { id: "ajustes", label: "Ajustes", icon: "⚙", tab: "ajustes", title: "Ajustes: personaliza y protégete", description: "Cambia el nombre y color, administra respaldos y notificaciones, consulta las guías y envía comentarios para mejorar la app.", tip: "Antes de cambiar de teléfono, descarga un respaldo desde aquí para conservar todas tus libretas." },
];

// Todas las cifras visibles usan el formato mexicano de pesos, sin alterar el
// valor interno en centavos que protege los cálculos.
const money = new Intl.NumberFormat("es-MX", {
  style: "currency",
  currency: "MXN",
  minimumFractionDigits: 2,
});

// Estos formateadores se crean una sola vez. Antes se creaban dos nuevos por
// cada apunte cada vez que se abría una libreta, lo que se notaba en teléfonos
// con historiales grandes.
const movementDateFormatter = new Intl.DateTimeFormat("es-MX", { day: "numeric", month: "short", year: "numeric" });
const movementTimeFormatter = new Intl.DateTimeFormat("es-MX", { hour: "2-digit", minute: "2-digit", hour12: false });

function toMovementView(movement: LocalTransaction, pocketNames: Map<string, string>): Movement {
  const date = new Date(movement.occurredAt);
  return {
    id: movement.id,
    kind: movement.kind,
    amount: movement.amountCents / 100,
    purpose: movement.purpose,
    note: movement.note,
    pocket: pocketNames.get(movement.kind === "transferencia" ? movement.targetPocketId ?? "" : movement.sourcePocketId ?? "") ?? "Sin apartado",
    date: movementDateFormatter.format(date).replaceAll(" de ", " "),
    time: movementTimeFormatter.format(date),
    occurredAt: movement.occurredAt,
    sourcePocketId: movement.sourcePocketId ?? "",
    targetPocketId: movement.targetPocketId,
  };
}

type AppErrorBoundaryProps = { children: ReactNode };
type AppErrorBoundaryState = { hasError: boolean };

// Si un fallo visual inesperado llega desde una actualización del navegador o
// una combinación rara de datos, la persona recibe una salida segura en lugar
// de una pantalla blanca. Los datos no se modifican ni se envía información.
class AppErrorBoundary extends Component<AppErrorBoundaryProps, AppErrorBoundaryState> {
  state: AppErrorBoundaryState = { hasError: false };

  static getDerivedStateFromError() {
    return { hasError: true };
  }

  render() {
    if (this.state.hasError) {
      return <main className="loading-page"><div className="load-error unexpected-error"><span>!</span><strong>La libreta necesita recargarse</strong><p>Tus datos siguen guardados en este teléfono. Vuelve a abrirla para continuar.</p><button onClick={() => window.location.reload()}>Recargar mi libreta</button></div></main>;
    }
    return this.props.children;
  }
}

// Utilidades de fecha, notificaciones, calculadora y fotografía. Están fuera
// del componente porque no dependen de la pantalla actual y son fáciles de probar.
function localDateTimeValue(date = new Date()) {
  const offset = date.getTimezoneOffset() * 60_000;
  return new Date(date.getTime() - offset).toISOString().slice(0, 16);
}

function localMonthKey(value: string | Date) {
  const date = value instanceof Date ? value : new Date(value);
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}`;
}

function localDayKey(value: string) {
  const date = new Date(value);
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}

function securityDateLabel(value: string | null) {
  if (!value || Number.isNaN(new Date(value).getTime())) return "Aún no hay una fecha registrada";
  return new Intl.DateTimeFormat("es-MX", { day: "numeric", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit" }).format(new Date(value)).replaceAll(" de ", " ");
}

function notificationPermission(): NotificationPermission | "unsupported" {
  if (typeof window === "undefined" || !("Notification" in window)) return "unsupported";
  return Notification.permission;
}

function base64UrlToUint8Array(value: string) {
  const padding = "=".repeat((4 - value.length % 4) % 4);
  const decoded = atob((value + padding).replaceAll("-", "+").replaceAll("_", "/"));
  return Uint8Array.from(decoded, (character) => character.charCodeAt(0));
}

function isIOSDevice() {
  return typeof navigator !== "undefined" && /iphone|ipad|ipod/i.test(navigator.userAgent);
}

// No todos los navegadores muestran el aviso automático de instalar. WhatsApp,
// Facebook e Instagram suelen abrir enlaces dentro de una mini-ventana que no
// puede instalar PWAs; en ese caso explicamos cómo abrir la liga en Chrome o Safari.
function getInstallPlatform(): "ios" | "embedded" | "android" | "desktop" {
  if (typeof navigator === "undefined") return "desktop";
  const agent = navigator.userAgent;
  if (/;\s*wv\)|FBAN|FBAV|Instagram|TikTok|Line\//i.test(agent)) return "embedded";
  if (/iphone|ipad|ipod/i.test(agent)) return "ios";
  if (/android/i.test(agent)) return "android";
  return "desktop";
}

function isStandaloneApp() {
  return typeof window !== "undefined" && (
    window.matchMedia("(display-mode: standalone)").matches ||
    Boolean((navigator as Navigator & { standalone?: boolean }).standalone)
  );
}

function paymentReminderSchedule(cards: StoredCard[]) {
  const now = Date.now();
  return cards.flatMap((card) => {
    if (!card.dueDate || card.amount <= 0 || card.status === "paid") return [];
    const dueAt = new Date(`${card.dueDate}T09:00:00`);
    if (Number.isNaN(dueAt.getTime()) || dueAt.getTime() < now) return [];
    return card.reminderDays.flatMap((days) => {
      const planned = dueAt.getTime() - days * 86_400_000;
      if (planned < now) return [];
      return [{ id: `${card.id}:${card.dueDate}:${days}`, remindAt: new Date(planned).toISOString() }];
    });
  });
}

async function savePushSubscription(installId: string, subscription: PushSubscription, sendTest: boolean) {
  const response = await fetch("/api/push-subscriptions", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      installId,
      ...subscription.toJSON(),
      timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
      sendTest,
    }),
  });
  if (!response.ok) throw new Error("No pudimos enlazar este teléfono con los recordatorios.");
  return response.json() as Promise<{ ok: true; testSent: boolean | null }>;
}

async function saveReminderSchedule(installId: string, cards: StoredCard[]) {
  const response = await fetch("/api/push-reminders", {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ installId, reminders: paymentReminderSchedule(cards) }),
  });
  if (!response.ok) throw new Error("No pudimos actualizar las fechas de aviso.");
}

function calculateExpression(expression: string): number | null {
  const compact = expression.replace(/\s/g, "");
  if (!compact || !/^\d+(?:\.\d+)?(?:[+\-*/]\d+(?:\.\d+)?)*$/.test(compact)) return null;
  const tokens = compact.match(/\d+(?:\.\d+)?|[+\-*/]/g);
  if (!tokens) return null;
  const values: number[] = [];
  const operators: string[] = [];
  const precedence: Record<string, number> = { "+": 1, "-": 1, "*": 2, "/": 2 };
  const apply = () => {
    const operator = operators.pop();
    const right = values.pop();
    const left = values.pop();
    if (!operator || right === undefined || left === undefined) return false;
    if (operator === "/" && right === 0) return false;
    values.push(operator === "+" ? left + right : operator === "-" ? left - right : operator === "*" ? left * right : left / right);
    return true;
  };
  for (const token of tokens) {
    if (/^\d/.test(token)) values.push(Number(token));
    else {
      while (operators.length && precedence[operators.at(-1)!] >= precedence[token]) if (!apply()) return null;
      operators.push(token);
    }
  }
  while (operators.length) if (!apply()) return null;
  return Number.isFinite(values[0]) ? values[0] : null;
}

async function photoToDataUrl(file: File): Promise<string> {
  if (!file.type.startsWith("image/") || file.size > 8_000_000) throw new Error("Elige una imagen JPG, PNG o WebP menor a 8 MB.");
  const bitmap = await createImageBitmap(file);
  const size = Math.min(512, Math.max(bitmap.width, bitmap.height));
  const scale = Math.min(1, size / Math.max(bitmap.width, bitmap.height));
  const canvas = document.createElement("canvas");
  canvas.width = Math.max(1, Math.round(bitmap.width * scale));
  canvas.height = Math.max(1, Math.round(bitmap.height * scale));
  const context = canvas.getContext("2d");
  if (!context) throw new Error("Este teléfono no pudo procesar la fotografía.");
  context.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
  bitmap.close();
  return canvas.toDataURL("image/webp", 0.82);
}

export default function FinanceNotebook() {
  return <AppErrorBoundary><FinanceNotebookContent /></AppErrorBoundary>;
}

function FinanceNotebookContent() {
  // Estado de carga y datos que representan la libreta activa.
  // Los estados siguientes controlan solo la interfaz: formularios, filtros,
  // modales y mensajes; las mutaciones financieras viven en local-finance.ts.
  const [appState, setAppState] = useState<"loading" | "setup" | "ready" | "error">("loading");
  const [loadError, setLoadError] = useState("");
  const [profile, setProfile] = useState<ProfileState>({ displayName: "", notebookTitle: "Mi libreta", incomeFrequency: "quincenal", startDate: "", theme: "purple", hasPhoto: false, photoDataUrl: null });
  const [cards, setCards] = useState<StoredCard[]>([]);
  const [goals, setGoals] = useState<Goal[]>([]);
  const [goalMovements, setGoalMovements] = useState<GoalMovement[]>([]);
  const [installId, setInstallId] = useState("");
  const [analyticsConsent, setAnalyticsConsentState] = useState(false);
  const [notebooks, setNotebooks] = useState<LocalNotebookInfo[]>([]);
  const [notebookSummaries, setNotebookSummaries] = useState<LocalNotebookSummary[]>([]);
  const [activeNotebookId, setActiveNotebookId] = useState("");
  const [notebookManagerOpen, setNotebookManagerOpen] = useState(false);
  const [notebookComparisonOpen, setNotebookComparisonOpen] = useState(false);
  const [notebookComparison, setNotebookComparison] = useState<LocalNotebookMonthComparison | null>(null);
  const [notebookComparisonMonth, setNotebookComparisonMonth] = useState(localMonthKey(new Date()));
  const [newNotebookName, setNewNotebookName] = useState("");
  const [renamingNotebookId, setRenamingNotebookId] = useState<string | null>(null);
  const [renamedNotebookName, setRenamedNotebookName] = useState("");
  const [deletingNotebook, setDeletingNotebook] = useState<LocalNotebookInfo | null>(null);
  const [deleteNotebookName, setDeleteNotebookName] = useState("");
  const [installPrompt, setInstallPrompt] = useState<InstallPromptEvent | null>(null);
  const [installed, setInstalled] = useState(isStandaloneApp);
  const [installEntryOpen, setInstallEntryOpen] = useState(false);
  const [installHelpOpen, setInstallHelpOpen] = useState(false);
  // La guía también queda disponible después del primer inicio para que una
  // persona pueda recordar una función sin reiniciar ni alterar su libreta.
  const [guideOpen, setGuideOpen] = useState(false);
  const [tutorialPromptOpen, setTutorialPromptOpen] = useState(false);
  const [tutorialRun, setTutorialRun] = useState<TutorialRun | null>(null);
  const [feedbackOpen, setFeedbackOpen] = useState(false);
  const [feedbackContext, setFeedbackContext] = useState<"general" | "tutorial">("general");
  const [feedbackRating, setFeedbackRating] = useState(0);
  const [feedbackMessage, setFeedbackMessage] = useState("");
  const [feedbackSaving, setFeedbackSaving] = useState(false);
  const [feedbackBubbleVisible, setFeedbackBubbleVisible] = useState(true);
  const [cardFormOpen, setCardFormOpen] = useState(false);
  const [editingCardId, setEditingCardId] = useState<string | null>(null);
  const [cardAlias, setCardAlias] = useState("");
  const [cardCategory, setCardCategory] = useState<LocalPaymentCategory>("tarjeta");
  const [cardProvider, setCardProvider] = useState("");
  const [cardAmount, setCardAmount] = useState("");
  const [cardDueDate, setCardDueDate] = useState("");
  const [cardPriority, setCardPriority] = useState<LocalPaymentPriority>("relevante");
  const [cardRecurrence, setCardRecurrence] = useState<LocalPaymentRecurrence>("once");
  const [cardReminderDays, setCardReminderDays] = useState<number[]>([5, 3, 1]);
  const [paymentFilter, setPaymentFilter] = useState<PaymentFilter>("todas");
  const [paymentSort, setPaymentSort] = useState<PaymentSort>("prioridad");
  const [goalFilter, setGoalFilter] = useState<"todos" | LocalGoalTerm>("todos");
  const [goalFormOpen, setGoalFormOpen] = useState(false);
  const [editingGoalId, setEditingGoalId] = useState<string | null>(null);
  const [goalName, setGoalName] = useState("");
  const [goalPurpose, setGoalPurpose] = useState("");
  const [goalTerm, setGoalTerm] = useState<LocalGoalTerm>("mediano");
  const [goalTarget, setGoalTarget] = useState("");
  const [goalTargetDate, setGoalTargetDate] = useState("");
  const [goalIcon, setGoalIcon] = useState("◎");
  const [goalColor, setGoalColor] = useState<Pocket["tone"]>("violet");
  const [goalTransfer, setGoalTransfer] = useState<{ goal: Goal; mode: GoalTransferMode } | null>(null);
  const [goalTransferAmount, setGoalTransferAmount] = useState("");
  const [goalTransferPocketId, setGoalTransferPocketId] = useState("");
  const [goalTransferNote, setGoalTransferNote] = useState("");
  const [goalWithdrawalConfirm, setGoalWithdrawalConfirm] = useState(false);
  const [pocketFormOpen, setPocketFormOpen] = useState(false);
  const [pocketName, setPocketName] = useState("");
  const [pocketIcon, setPocketIcon] = useState("✦");
  const [pocketTone, setPocketTone] = useState<Pocket["tone"]>("violet");
  const [editingPocket, setEditingPocket] = useState<Pocket | null>(null);
  const [editPocketName, setEditPocketName] = useState("");
  const [editPocketIcon, setEditPocketIcon] = useState("");
  const [editPocketTone, setEditPocketTone] = useState<Pocket["tone"]>("violet");
  const [editPocketRole, setEditPocketRole] = useState<LocalPocketRole>("reserved");
  const [editPocketBalance, setEditPocketBalance] = useState("");
  const [editingMovement, setEditingMovement] = useState<Movement | null>(null);
  const [editKind, setEditKind] = useState<MovementKind>("gasto");
  const [editAmount, setEditAmount] = useState("");
  const [editSource, setEditSource] = useState("");
  const [editTarget, setEditTarget] = useState("");
  const [editOccurredAt, setEditOccurredAt] = useState("");
  const [editPurpose, setEditPurpose] = useState("");
  const [editNote, setEditNote] = useState("");
  const [editReason, setEditReason] = useState("");
  const [editError, setEditError] = useState("");
  const [tab, setTab] = useState<Tab>("inicio");
  const [selectedMonth, setSelectedMonth] = useState(localMonthKey(new Date()));
  // Reportes tiene su propio mes: revisar el historial no cambia por accidente
  // el cierre que la persona estaba preparando para exportar.
  const [reportMonth, setReportMonth] = useState(localMonthKey(new Date()));
  const [pockets, setPockets] = useState(initialPockets);
  const [movements, setMovements] = useState(initialMovements);
  const [entryOpen, setEntryOpen] = useState(false);
  const [kind, setKind] = useState<MovementKind>("gasto");
  const [amount, setAmount] = useState("");
  const [source, setSource] = useState("daily");
  const [target, setTarget] = useState("home");
  const [purpose, setPurpose] = useState("");
  const [note, setNote] = useState("");
  const [occurredAt, setOccurredAt] = useState(localDateTimeValue());
  const [formError, setFormError] = useState("");
  const [calculatorOpen, setCalculatorOpen] = useState(false);
  const [expression, setExpression] = useState("");
  const [notificationState, setNotificationState] = useState<NotificationPermission | "unsupported">(notificationPermission);
  const [pushState, setPushState] = useState<PushState>("idle");
  const [lastBackupAt, setLastBackupAt] = useState<string | null>(null);
  const [safetyCopy, setSafetyCopy] = useState<LocalSafetyCopyStatus>({ available: false, createdAt: null, reason: null });
  const [persistentStorage, setPersistentStorage] = useState<"active" | "available" | "unsupported">("unsupported");
  const [securityCenterOpen, setSecurityCenterOpen] = useState(false);
  const [toast, setToast] = useState("");
  // El historial se muestra por partes: una libreta puede conservar miles de
  // apuntes, pero el teléfono solo pinta los primeros al entrar a la pantalla.
  const [movementRenderLimit, setMovementRenderLimit] = useState(80);

  // Al abrir: recupera la libreta del teléfono, registra el Service Worker y
  // restaura la preferencia visual de la burbuja de comentarios.
  useEffect(() => {
    queueMicrotask(() => setFeedbackBubbleVisible(window.localStorage.getItem("libreta-feedback-bubble") !== "hidden"));
    queueMicrotask(() => setLastBackupAt(window.localStorage.getItem(LAST_BACKUP_AT_KEY)));
    void refreshSecurityStatus();
    if ("serviceWorker" in navigator) navigator.serviceWorker.register("/sw.js").catch(() => undefined);
    const captureInstallPrompt = (event: Event) => {
      event.preventDefault();
      setInstallPrompt(event as InstallPromptEvent);
    };
    const markInstalled = () => {
      setInstalled(true);
      setInstallPrompt(null);
      window.localStorage.setItem(INSTALL_ENTRY_STATUS_KEY, "installed");
      setInstallEntryOpen(false);
      setInstallHelpOpen(false);
    };
    window.addEventListener("beforeinstallprompt", captureInstallPrompt);
    window.addEventListener("appinstalled", markInstalled);
    void reloadFinance();
    return () => {
      window.removeEventListener("beforeinstallprompt", captureInstallPrompt);
      window.removeEventListener("appinstalled", markInstalled);
    };
    // This initialization intentionally runs once for the current installation.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Un aviso breve desaparece solo para no bloquear a la persona mientras registra.
  useEffect(() => {
    if (!toast) return;
    const timeout = window.setTimeout(() => setToast(""), 3200);
    return () => window.clearTimeout(timeout);
  }, [toast]);

  // En teléfonos el teclado puede reducir el espacio visible sin cambiar el
  // alto normal de la página. Guardamos esa medida para que las hojas de
  // captura no oculten campos ni botones debajo del teclado.
  useEffect(() => {
    const root = document.documentElement;
    const viewport = window.visualViewport;
    const updateViewportHeight = () => {
      root.style.setProperty("--app-visible-height", `${Math.round(viewport?.height ?? window.innerHeight)}px`);
    };
    const bringFocusedFieldIntoView = (event: FocusEvent) => {
      const target = event.target;
      if (target instanceof HTMLInputElement || target instanceof HTMLSelectElement || target instanceof HTMLTextAreaElement) {
        window.requestAnimationFrame(() => target.scrollIntoView({ block: "center", behavior: "smooth" }));
      }
    };
    updateViewportHeight();
    window.addEventListener("resize", updateViewportHeight);
    viewport?.addEventListener("resize", updateViewportHeight);
    document.addEventListener("focusin", bringFocusedFieldIntoView);
    return () => {
      root.style.removeProperty("--app-visible-height");
      window.removeEventListener("resize", updateViewportHeight);
      viewport?.removeEventListener("resize", updateViewportHeight);
      document.removeEventListener("focusin", bringFocusedFieldIntoView);
    };
  }, []);

  // Cada pestaña comienza arriba para que la persona no llegue a una pantalla
  // nueva a mitad de la información. La transición es breve y se desactiva si
  // el teléfono solicita menos movimiento.
  function goToTab(nextTab: Tab) {
    setTab(nextTab);
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  // Las métricas son estrictamente opcionales y se envían una sola vez por sesión.
  useEffect(() => {
    if (appState !== "ready" || !analyticsConsent || !installId) return;
    void sendTelemetry("app_open", tab);
    // One anonymous open event per loaded session is enough for the beta.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [appState, analyticsConsent, installId]);

  // Si el teléfono ya aceptó avisos, recuperamos su suscripción de forma silenciosa.
  useEffect(() => {
    if (appState !== "ready" || notificationState !== "granted" || !installId || !("serviceWorker" in navigator) || !("PushManager" in window)) return;
    let cancelled = false;
    navigator.serviceWorker.ready.then((registration) => registration.pushManager.getSubscription()).then(async (subscription) => {
      if (cancelled || !subscription) return;
      await savePushSubscription(installId, subscription, false);
      if (!cancelled) setPushState("active");
    }).catch(() => {
      if (!cancelled) setPushState("error");
    });
    return () => { cancelled = true; };
  }, [appState, installId, notificationState]);

  // Sincroniza solo fechas e identificadores de avisos: tarjetas y montos siguen locales.
  useEffect(() => {
    if (appState !== "ready" || pushState !== "active" || !installId) return;
    void saveReminderSchedule(installId, cards)
      .then(() => sendTelemetry("reminder_schedule_sync", "tarjetas"))
      .catch(() => setPushState("error"));
    // The schedule contains only random ids and dates; card details stay local.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [appState, cards, installId, pushState]);

  useEffect(() => {
    if (appState !== "ready" || pushState === "active" || notificationState !== "granted" || !cards.length || !("serviceWorker" in navigator)) return;
    const todayKey = `finance-reminder-${new Date().toISOString().slice(0, 10)}`;
    if (localStorage.getItem(todayKey)) return;
    const upcoming = cards.find((card) => {
      if (!card.dueDate || card.amount <= 0 || card.status === "paid") return false;
      const days = Math.ceil((new Date(`${card.dueDate}T12:00:00`).getTime() - Date.now()) / 86_400_000);
      return days >= 0 && (card.reminderDays.includes(days) || (days === 0 && card.reminderDays.length > 0));
    });
    if (!upcoming) return;
    navigator.serviceWorker.ready.then((registration) => registration.showNotification(`Pago próximo: ${upcoming.alias}`, {
      body: `${money.format(upcoming.amount)} por pagar. Revisa la fecha en tu libreta.`,
      icon: "/favicon.svg",
      tag: `payment-${upcoming.id}`,
    })).then(() => localStorage.setItem(todayKey, "1")).catch(() => undefined);
  }, [appState, cards, notificationState, pushState]);

  // Diagnóstico anónimo de beta. No incluye perfil, montos, nombres de pagos o notas.
  async function sendTelemetry(eventName: string, screen = tab, durationMs?: number) {
    if (!analyticsConsent || !installId) return;
    await fetch("/api/beta/telemetry", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ installId, eventName, screen, durationMs }),
      keepalive: true,
    }).catch(() => undefined);
  }

  async function installApplication() {
    if (installed) return setToast("La aplicación ya está instalada");
    if (!installPrompt) {
      setInstallEntryOpen(false);
      setInstallHelpOpen(true);
      return;
    }
    try {
      await sendTelemetry("install_prompt", "ajustes");
      await installPrompt.prompt();
      const choice = await installPrompt.userChoice;
      if (choice.outcome === "accepted") {
        setInstalled(true);
        setInstallPrompt(null);
        window.localStorage.setItem(INSTALL_ENTRY_STATUS_KEY, "installed");
        setInstallEntryOpen(false);
        await sendTelemetry("installed", "ajustes");
      }
    } catch {
      // Un navegador puede invalidar un aviso de instalación si cambió de
      // contexto. En vez de dejar un botón sin respuesta, mostramos pasos reales.
      setInstallPrompt(null);
      setInstallEntryOpen(false);
      setInstallHelpOpen(true);
    }
  }

  function continueInBrowser() {
    window.localStorage.setItem(INSTALL_ENTRY_STATUS_KEY, "web");
    setInstallEntryOpen(false);
    setToast("Puedes instalarla después desde Ajustes");
  }

  function openInstallChoice() {
    if (installed) return setToast("La aplicación ya está instalada");
    setInstallEntryOpen(true);
  }

  async function changeAnalyticsConsent(consent: boolean) {
    try {
      applySnapshot(await setAnalyticsConsent(consent));
      setToast(consent ? "Métricas anónimas activadas" : "Métricas anónimas desactivadas");
    } catch {
      setToast("No pudimos guardar esta preferencia");
    }
  }

  // El respaldo exporta todas las libretas del teléfono antes de que una persona
  // reinstale, cambie de equipo o realice una operación delicada.
  async function refreshSecurityStatus() {
    try {
      const [copy, storage] = await Promise.all([getLocalSafetyCopyStatus(), getPersistentStorageStatus()]);
      setSafetyCopy(copy);
      setPersistentStorage(storage);
    } catch {
      // La libreta sigue siendo usable aunque un navegador no ofrezca estas
      // protecciones adicionales; el respaldo manual permanece disponible.
    }
  }

  async function downloadBackup() {
    try {
      const result = await saveLocalBackup(await createLocalBackupFile());
      if (result === "cancelled") return;
      const createdAt = new Date().toISOString();
      window.localStorage.setItem(LAST_BACKUP_AT_KEY, createdAt);
      setLastBackupAt(createdAt);
      await sendTelemetry("backup_downloaded", "ajustes");
      setToast(result === "shared"
        ? "Elige Archivos, Drive, OneDrive o iCloud para guardar tu respaldo"
        : "Respaldo descargado en este teléfono");
    } catch (caught) {
      setToast(caught instanceof Error ? caught.message : "No pudimos crear el respaldo");
    }
  }

  async function restoreBackup(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    if (!file) return;
    if (!window.confirm("Restaurar reemplazará las libretas de este teléfono con las del archivo elegido. Antes, la app guardará una copia interna del estado actual. ¿Deseas continuar?")) {
      event.target.value = "";
      return;
    }
    try {
      applySnapshot(await importLocalBackup(file));
      await refreshSecurityStatus();
      await sendTelemetry("backup_restored", "ajustes");
      setToast("Respaldo restaurado. La versión anterior quedó protegida en este teléfono.");
    } catch (caught) {
      setToast(caught instanceof Error ? caught.message : "No pudimos restaurar el respaldo");
    }
    event.target.value = "";
  }

  async function enablePersistentStorage() {
    try {
      const granted = await requestPersistentStorage();
      await refreshSecurityStatus();
      setToast(granted ? "Protección de almacenamiento activada en este teléfono" : "Este navegador no pudo dar almacenamiento permanente. Mantén un respaldo externo.");
    } catch {
      setToast("No pudimos solicitar protección adicional a este navegador");
    }
  }

  async function recoverSafetyCopy() {
    if (!safetyCopy.available) return;
    if (!window.confirm("Volverás al estado anterior a la última restauración, eliminación o reinicio. Los cambios posteriores a esa acción se reemplazarán. ¿Deseas continuar?")) return;
    try {
      applySnapshot(await restoreLocalSafetyCopy());
      await refreshSecurityStatus();
      setSecurityCenterOpen(false);
      setTab("inicio");
      setToast("Recuperamos la copia de seguridad interna");
    } catch (caught) {
      setToast(caught instanceof Error ? caught.message : "No pudimos recuperar la copia interna");
    }
  }

  // El mensaje de beta se manda sin nombre, correo ni contenido de la libreta.
  async function submitFeedback(event: FormEvent) {
    event.preventDefault();
    if (!feedbackRating) return setToast("Elige una calificación del 1 al 5");
    setFeedbackSaving(true);
    try {
      const response = await fetch("/api/beta/feedback", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        // "tutorial" identifica el tipo de opinión; nunca agrega datos de la
        // libreta ni de la persona que hizo el recorrido.
        body: JSON.stringify({ installId, rating: feedbackRating, message: feedbackMessage, screen: feedbackContext === "tutorial" ? "tutorial" : tab }),
      });
      if (!response.ok) throw new Error("No pudimos enviar el comentario.");
      await sendTelemetry("feedback_sent", feedbackContext === "tutorial" ? "tutorial" : tab);
      setFeedbackOpen(false);
      setFeedbackRating(0);
      setFeedbackMessage("");
      setFeedbackContext("general");
      setToast("Gracias. Tu comentario quedó registrado sin datos financieros");
    } catch (caught) {
      setToast(caught instanceof Error ? caught.message : "No pudimos enviar el comentario");
    } finally {
      setFeedbackSaving(false);
    }
  }

  function changeFeedbackBubble(visible: boolean) {
    setFeedbackBubbleVisible(visible);
    window.localStorage.setItem("libreta-feedback-bubble", visible ? "visible" : "hidden");
    if (!visible) setFeedbackOpen(false);
    setToast(visible ? "La burbuja de comentarios está visible" : "Burbuja oculta; puedes mostrarla desde Ajustes");
  }

  function openGeneralFeedback() {
    setFeedbackContext("general");
    setFeedbackRating(0);
    setFeedbackMessage("");
    setFeedbackOpen(true);
  }

  // La invitación aparece solo una vez por teléfono, incluso si el usuario ya
  // había creado datos antes. Omitirla no borra nada y las guías siguen en Ajustes.
  function rememberTutorialChoice(status: "completed" | "skipped") {
    window.localStorage.setItem(TUTORIAL_STATUS_KEY, status);
    setTutorialPromptOpen(false);
  }

  function startTutorial(topicIndex = 0, singleTopic = false, askForFeedback = false) {
    const topic = tutorialTopics[topicIndex];
    if (!topic) return;
    if (askForFeedback) rememberTutorialChoice("completed");
    setGuideOpen(false);
    setTutorialPromptOpen(false);
    setNotebookManagerOpen(false);
    setTab(topic.tab);
    setTutorialRun({ topicIndex, singleTopic, askForFeedback });
  }

  function finishTutorial() {
    const askForFeedback = tutorialRun?.askForFeedback;
    setTutorialRun(null);
    if (!askForFeedback) return;
    setFeedbackContext("tutorial");
    setFeedbackRating(0);
    setFeedbackMessage("");
    setFeedbackOpen(true);
  }

  function moveThroughTutorial(direction: -1 | 1) {
    if (!tutorialRun || tutorialRun.singleTopic) return finishTutorial();
    const nextIndex = tutorialRun.topicIndex + direction;
    if (nextIndex < 0) return;
    if (nextIndex >= tutorialTopics.length) return finishTutorial();
    const nextTopic = tutorialTopics[nextIndex];
    setTab(nextTopic.tab);
    setTutorialRun((current) => current ? { ...current, topicIndex: nextIndex } : current);
  }

  // Estas funciones manejan libretas separadas: al cambiar una, la pantalla recibe
  // otro snapshot completo; no se mezclan saldos ni movimientos entre ellas.
  function closeNotebookManager() {
    setNotebookManagerOpen(false);
    setNotebookComparisonOpen(false);
    setNewNotebookName("");
    setRenamingNotebookId(null);
    setRenamedNotebookName("");
    setDeletingNotebook(null);
    setDeleteNotebookName("");
  }

  // La comparación se calcula únicamente en este teléfono y no modifica los
  // saldos. El mes se pide de forma explícita para que sea claro qué se está
  // contrastando entre libretas.
  async function refreshNotebookComparison(month = notebookComparisonMonth) {
    try {
      const comparison = await loadLocalNotebookComparison(month);
      setNotebookComparison(comparison);
      setNotebookComparisonMonth(comparison.monthKey);
    } catch {
      setToast("No pudimos cargar la comparación de tus libretas");
    }
  }

  function openNotebookManager() {
    setNotebookManagerOpen(true);
    void refreshNotebookComparison();
  }

  async function createNotebook(event: FormEvent) {
    event.preventDefault();
    if (!newNotebookName.trim()) return setToast("Ponle un nombre a la nueva libreta");
    try {
      applySnapshot(await createLocalNotebook(newNotebookName));
      setNewNotebookName("");
      setTab("inicio");
      void refreshNotebookComparison();
      setToast("Nueva libreta creada. Empieza con tu dinero disponible en $0.00");
    } catch (caught) {
      setToast(caught instanceof Error ? caught.message : "No pudimos crear la libreta");
    }
  }

  async function chooseNotebook(id: string) {
    if (id === activeNotebookId) return;
    try {
      applySnapshot(await switchLocalNotebook(id));
      setTab("inicio");
      setSelectedMonth(localMonthKey(new Date()));
      setEntryOpen(false);
      closeNotebookManager();
      setToast("Cambiaste de libreta. Sus datos permanecen separados");
    } catch (caught) {
      setToast(caught instanceof Error ? caught.message : "No pudimos cambiar de libreta");
    }
  }

  function startNotebookRename(notebook: LocalNotebookInfo) {
    setRenamingNotebookId(notebook.id);
    setRenamedNotebookName(notebook.name);
  }

  async function saveNotebookName(event: FormEvent) {
    event.preventDefault();
    if (!renamingNotebookId || !renamedNotebookName.trim()) return setToast("Escribe un nombre para la libreta");
    try {
      applySnapshot(await renameLocalNotebook(renamingNotebookId, renamedNotebookName));
      setRenamingNotebookId(null);
      setRenamedNotebookName("");
      void refreshNotebookComparison();
      setToast("Nombre de libreta actualizado");
    } catch (caught) {
      setToast(caught instanceof Error ? caught.message : "No pudimos cambiar el nombre");
    }
  }

  async function removeNotebook(notebook: LocalNotebookInfo) {
    if (notebooks.length < 2) return setToast("Conserva al menos una libreta en este teléfono");
    if (!notebook.archivedAt && notebooks.filter((item) => !item.archivedAt).length < 2) return setToast("Conserva al menos una libreta activa en este teléfono");
    if (deleteNotebookName.trim() !== notebook.name) return setToast("Escribe el nombre exacto de la libreta para eliminarla");
    try {
      applySnapshot(await deleteLocalNotebook(notebook.id));
      await refreshSecurityStatus();
      setTab("inicio");
      setRenamingNotebookId(null);
      setDeletingNotebook(null);
      setDeleteNotebookName("");
      void refreshNotebookComparison();
      setToast("Libreta eliminada de este teléfono");
    } catch (caught) {
      setToast(caught instanceof Error ? caught.message : "No pudimos eliminar la libreta");
    }
  }

  async function archiveNotebook(notebook: LocalNotebookInfo) {
    try {
      applySnapshot(await archiveLocalNotebook(notebook.id));
      setRenamingNotebookId(null);
      void refreshNotebookComparison();
      setToast(`“${notebook.name}” quedó archivada. Puedes recuperarla cuando quieras.`);
    } catch (caught) {
      setToast(caught instanceof Error ? caught.message : "No pudimos archivar la libreta");
    }
  }

  async function restoreNotebook(notebook: LocalNotebookInfo) {
    try {
      applySnapshot(await restoreLocalNotebook(notebook.id));
      void refreshNotebookComparison();
      setToast(`“${notebook.name}” volvió a quedar disponible.`);
    } catch (caught) {
      setToast(caught instanceof Error ? caught.message : "No pudimos recuperar la libreta");
    }
  }

  function startMovement(nextKind: MovementKind, preferredSource?: string) {
    const availablePocket = pockets.find((pocket) => pocket.role === "available") ?? pockets[0];
    const nextSource = preferredSource ?? availablePocket?.id ?? pockets[0]?.id ?? "";
    const nextTarget = pockets.find((pocket) => pocket.id !== nextSource)?.id ?? nextSource;
    setKind(nextKind);
    setSource(nextSource);
    setTarget(nextTarget);
    setFormError("");
    setEntryOpen(true);
  }

  // Regla financiera central: disponible no incluye dinero reservado ni objetivos.
  // Las transferencias tampoco aparecen como entradas o salidas reales de dinero.
  const totals = useMemo(() => {
    const now = new Date();
    const currentYear = now.getFullYear();
    const currentMonth = now.getMonth();
    const todayKey = localDayKey(now.toISOString());
    let income = 0;
    let expense = 0;
    let todayIncome = 0;
    let todayExpense = 0;
    let largestExpense: Movement | undefined;
    for (const item of movements) {
      const date = new Date(item.occurredAt);
      if (date.getFullYear() !== currentYear || date.getMonth() !== currentMonth) continue;
      if (item.kind === "ingreso") {
        income += item.amount;
        if (localDayKey(item.occurredAt) === todayKey) todayIncome += item.amount;
      } else if (item.kind === "gasto") {
        expense += item.amount;
        if (localDayKey(item.occurredAt) === todayKey) todayExpense += item.amount;
        if (!largestExpense || item.amount > largestExpense.amount) largestExpense = item;
      }
    }
    let available = 0;
    let reserved = 0;
    for (const pocket of pockets) {
      if (pocket.role === "available") available += pocket.balance;
      else reserved += pocket.balance;
    }
    const goalSaved = goals.reduce((sum, goal) => sum + goal.saved, 0);
    return { income, expense, net: income - expense, todayIncome, todayExpense, todayNet: todayIncome - todayExpense, largestExpense, available, reserved, goalSaved, totalTracked: available + reserved + goalSaved };
  }, [goals, movements, pockets]);

  const paymentSummary = useMemo(() => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    let pending = 0;
    let total = 0;
    let overdue = 0;
    for (const card of cards) {
      if (card.status !== "current") continue;
      pending += 1;
      total += card.amount;
      if (card.dueDate && new Date(`${card.dueDate}T00:00:00`) < today) overdue += 1;
    }
    return { pending, total, overdue };
  }, [cards]);

  const visiblePayments = useMemo(() => {
    const filtered = paymentFilter === "todas" ? [...cards] : cards.filter((card) => card.category === paymentFilter);
    const dueTime = (card: StoredCard) => card.dueDate ? new Date(`${card.dueDate}T12:00:00`).getTime() : Number.MAX_SAFE_INTEGER;
    return filtered.sort((left, right) => {
      if (left.status !== right.status) return left.status === "paid" ? 1 : -1;
      if (paymentSort === "monto") return right.amount - left.amount;
      if (paymentSort === "fecha") return dueTime(left) - dueTime(right);
      return priorityRank[left.priority] - priorityRank[right.priority] || dueTime(left) - dueTime(right);
    });
  }, [cards, paymentFilter, paymentSort]);

  const visibleGoals = useMemo(() => {
    const filtered = goalFilter === "todos" ? [...goals] : goals.filter((goal) => goal.term === goalFilter);
    return filtered.sort((left, right) => {
      if (left.status !== right.status) return left.status === "completed" ? 1 : -1;
      return new Date(`${left.targetDate}T12:00:00`).getTime() - new Date(`${right.targetDate}T12:00:00`).getTime();
    });
  }, [goalFilter, goals]);

  const goalSummary = useMemo(() => ({
    active: goals.filter((goal) => goal.status === "active").length,
    completed: goals.filter((goal) => goal.status === "completed").length,
    saved: goals.reduce((sum, goal) => sum + goal.saved, 0),
    target: goals.reduce((sum, goal) => sum + goal.target, 0),
  }), [goals]);

  const activeNotebook = notebooks.find((notebook) => notebook.id === activeNotebookId);

  const monthOptions = useMemo(() => Array.from(new Set([localMonthKey(new Date()), ...movements.map((item) => localMonthKey(item.occurredAt))])).sort().reverse().slice(0, 12), [movements]);

  const reportMovements = useMemo(() => movements.filter((item) => localMonthKey(item.occurredAt) === reportMonth), [movements, reportMonth]);
  const reportTotals = useMemo(() => {
    const income = reportMovements.filter((item) => item.kind === "ingreso").reduce((sum, item) => sum + item.amount, 0);
    const expense = reportMovements.filter((item) => item.kind === "gasto").reduce((sum, item) => sum + item.amount, 0);
    return { income, expense, net: income - expense, movementCount: reportMovements.length };
  }, [reportMovements]);

  // Compara cada gasto con TODO lo que entró en el mes elegido. La pregunta que
  // responde es: "de cada $100 que ingresé, ¿cuánto usé aquí?". Agrupar por
  // motivo evita repetir la misma compra varias veces y hace la gráfica legible.
  const spendingByIncome = useMemo(() => {
    const income = reportTotals.income;
    const expenses = reportMovements.filter((item) => item.kind === "gasto");
    const grouped = new Map<string, number>();
    for (const expense of expenses) {
      const name = expense.purpose || "Gasto sin nombre";
      grouped.set(name, (grouped.get(name) ?? 0) + expense.amount);
    }
    const allItems = Array.from(grouped, ([name, amount]) => ({ name, amount, percent: income > 0 ? (amount / income) * 100 : 0 })).sort((left, right) => right.amount - left.amount);
    const items = allItems.slice(0, 5);
    const otherAmount = allItems.slice(5).reduce((sum, item) => sum + item.amount, 0);
    if (otherAmount > 0) items.push({ name: "Otros gastos", amount: otherAmount, percent: income > 0 ? (otherAmount / income) * 100 : 0 });
    return { income, expense: expenses.reduce((sum, item) => sum + item.amount, 0), items };
  }, [reportMovements, reportTotals.income]);

  const monthlyReportExport = useMemo<MonthlyReportExport>(() => {
    const pocketNames = new Map(pockets.map((pocket) => [pocket.id, pocket.name]));
    const monthDate = new Date(`${reportMonth}-15T12:00:00`);
    const formatDate = (value: string) => new Intl.DateTimeFormat("es-MX", { day: "2-digit", month: "short", year: "numeric" }).format(new Date(value)).replaceAll(" de ", " ");
    return {
      notebookName: activeNotebook?.name ?? profile.notebookTitle ?? "Mi libreta",
      monthKey: reportMonth,
      monthLabel: new Intl.DateTimeFormat("es-MX", { month: "long", year: "numeric" }).format(monthDate),
      generatedAt: new Intl.DateTimeFormat("es-MX", { day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit" }).format(new Date()).replaceAll(" de ", " "),
      income: reportTotals.income,
      expense: reportTotals.expense,
      net: reportTotals.net,
      available: totals.available,
      reserved: totals.reserved,
      goalSaved: totals.goalSaved,
      spending: spendingByIncome.items,
      movements: [...reportMovements].sort((left, right) => right.occurredAt.localeCompare(left.occurredAt)).map((item) => ({
        date: formatDate(item.occurredAt),
        kind: item.kind === "ingreso" ? "Ingreso" : item.kind === "gasto" ? "Gasto" : "Transferencia",
        purpose: item.purpose || "Sin concepto",
        note: item.note || "",
        pocket: item.kind === "transferencia" ? `${pocketNames.get(item.sourcePocketId) ?? "Origen"} -> ${pocketNames.get(item.targetPocketId ?? "") ?? "Destino"}` : pocketNames.get(item.sourcePocketId) ?? item.pocket,
        amount: item.amount,
      })),
      payments: cards.filter((card) => card.dueDate?.slice(0, 7) === reportMonth).map((card) => ({
        name: card.alias,
        provider: card.provider || "No indicado",
        dueDate: card.dueDate ? new Intl.DateTimeFormat("es-MX", { day: "2-digit", month: "short", year: "numeric" }).format(new Date(`${card.dueDate}T12:00:00`)).replaceAll(" de ", " ") : "Sin fecha",
        amount: card.amount,
        recurrence: card.recurrence === "monthly" ? "Cada mes" : "Una sola vez",
        status: card.status === "paid" ? "Pagado" : "Pendiente",
      })),
    };
  }, [activeNotebook?.name, cards, pockets, profile.notebookTitle, reportMonth, reportMovements, reportTotals, spendingByIncome.items, totals.available, totals.goalSaved, totals.reserved]);

  async function exportMonthlyReport(format: "excel" | "pdf") {
    try {
      // Excel y PDF solo se cargan cuando se solicitan. Así la libreta abre
      // más rápido para quien únicamente registra o consulta movimientos.
      const { downloadMonthlyExcel, downloadMonthlyPdf } = await import("@/lib/monthly-report-export");
      if (format === "excel") downloadMonthlyExcel(monthlyReportExport);
      else downloadMonthlyPdf(monthlyReportExport);
      setToast(format === "excel" ? "Tu Excel mensual está listo" : "Tu PDF mensual está listo");
    } catch {
      setToast("No pudimos preparar el archivo. Intenta de nuevo.");
    }
  }

  const movementGroups = useMemo(() => {
    const groups = new Map<string, Movement[]>();
    for (const movement of movements.filter((item) => localMonthKey(item.occurredAt) === selectedMonth)) {
      const key = localDayKey(movement.occurredAt);
      groups.set(key, [...(groups.get(key) ?? []), movement]);
    }
    return Array.from(groups.entries()).sort(([left], [right]) => right.localeCompare(left));
  }, [movements, selectedMonth]);

  const visibleMovementGroups = useMemo(() => {
    let remaining = movementRenderLimit;
    const groups: Array<[string, Movement[]]> = [];
    for (const [day, dayMovements] of movementGroups) {
      if (remaining <= 0) break;
      const visible = dayMovements.slice(0, remaining);
      groups.push([day, visible]);
      remaining -= visible.length;
    }
    return groups;
  }, [movementGroups, movementRenderLimit]);

  const renderedMovementCount = useMemo(
    () => visibleMovementGroups.reduce((total, [, dayMovements]) => total + dayMovements.length, 0),
    [visibleMovementGroups],
  );
  const selectedMonthMovementCount = useMemo(
    () => movementGroups.reduce((total, [, dayMovements]) => total + dayMovements.length, 0),
    [movementGroups],
  );

  // Convierte el snapshot seguro de IndexedDB al formato visual. Todas las acciones
  // locales vuelven por aquí para que portada, reportes y formularios coincidan.
  function applySnapshot(snapshot: LocalNotebookSnapshot) {
    setNotebooks(snapshot.notebooks);
    setNotebookSummaries(snapshot.notebookSummaries);
    setActiveNotebookId(snapshot.notebookId);
    const pocketNames = new Map(snapshot.pockets.map((pocket) => [pocket.id, pocket.name]));
    setInstallId(snapshot.installId);
    setAnalyticsConsentState(snapshot.analyticsConsent);
    setPockets(snapshot.pockets.map((pocket) => ({
      id: pocket.id,
      name: pocket.name,
      balance: pocket.balanceCents / 100,
      icon: pocket.icon,
      tone: pocket.color,
      role: pocket.role,
    })));
    if (snapshot.pockets[0]) setSource(snapshot.pockets[0].id);
    if (snapshot.pockets[1]) setTarget(snapshot.pockets[1].id);
    else if (snapshot.pockets[0]) setTarget(snapshot.pockets[0].id);
    setMovements(snapshot.transactions.map((movement) => toMovementView(movement, pocketNames)));
    setCards(snapshot.cards.map((card) => ({
      id: card.id,
      alias: card.alias,
      category: card.category,
      provider: card.provider,
      amount: card.amountDueCents / 100,
      dueDate: card.dueDate,
      reminderDays: card.remindDaysBefore,
      priority: card.priority,
      recurrence: card.recurrence,
      status: card.status,
      color: card.color,
    })));
    setGoals(snapshot.goals.map((goal) => ({
      id: goal.id,
      name: goal.name,
      purpose: goal.purpose,
      term: goal.term,
      target: goal.targetCents / 100,
      saved: goal.savedCents / 100,
      targetDate: goal.targetDate,
      icon: goal.icon,
      color: goal.color,
      status: goal.status,
    })));
    setGoalMovements(snapshot.goalMovements.map((movement) => ({
      id: movement.id,
      goalId: movement.goalId,
      pocketId: movement.pocketId,
      kind: movement.kind,
      amount: movement.amountCents / 100,
      note: movement.note,
      occurredAt: movement.occurredAt,
    })));
    setProfile({
      displayName: snapshot.profile.displayName,
      notebookTitle: snapshot.profile.notebookTitle,
      incomeFrequency: snapshot.profile.incomeFrequency,
      startDate: snapshot.profile.startDate,
      theme: snapshot.profile.theme,
      hasPhoto: Boolean(snapshot.profile.photoDataUrl),
      photoDataUrl: snapshot.profile.photoDataUrl,
    });
  }

  async function reloadFinance() {
    try {
      const snapshot = await loadLocalNotebook();
      if (!snapshot.setupCompleted) {
        setInstallId(snapshot.installId);
        setAppState("setup");
        setInstallEntryOpen(!isStandaloneApp() && window.localStorage.getItem(INSTALL_ENTRY_STATUS_KEY) === null);
        return;
      }
      applySnapshot(snapshot);
      setAppState("ready");
      setLoadError("");
      // V15 solo mostraba la guía durante una configuración nueva. Esta
      // revisión pregunta una vez también a las personas que ya tienen datos.
      setTutorialPromptOpen(window.localStorage.getItem(TUTORIAL_STATUS_KEY) === null);
      setInstallEntryOpen(!isStandaloneApp() && window.localStorage.getItem(INSTALL_ENTRY_STATUS_KEY) === null);
    } catch (caught) {
      setLoadError(caught instanceof Error ? caught.message : "No se pudo abrir la libreta local.");
      setAppState("error");
    }
  }

  // Restablece formularios después de guardar o cancelar, sin tocar datos financieros.
  function resetEntry() {
    setAmount("");
    setPurpose("");
    setNote("");
    setOccurredAt(localDateTimeValue());
    setFormError("");
    setExpression("");
    setCalculatorOpen(false);
  }

  async function saveMovement(event: FormEvent) {
    event.preventDefault();
    const form = new FormData(event.currentTarget as HTMLFormElement);
    const movementKind = String(form.get("kind") || kind) as MovementKind;
    const sourceId = String(form.get("source") || source);
    const targetId = String(form.get("target") || target);
    const movementPurpose = String(form.get("purpose") || "").trim();
    const movementNote = String(form.get("note") || "").trim();
    const movementDate = String(form.get("occurredAt") || occurredAt);
    const numericAmount = Number(form.get("amount") || 0);
    if (!numericAmount || numericAmount <= 0) return setFormError("Escribe una cantidad mayor a cero.");
    if (!movementPurpose) return setFormError("Es obligatorio indicar para qué es el movimiento.");
    if (movementKind === "transferencia" && sourceId === targetId) return setFormError("Elige apartados diferentes para la transferencia.");
    const originPocket = pockets.find((pocket) => pocket.id === sourceId);
    if ((movementKind === "gasto" || movementKind === "transferencia") && originPocket && originPocket.balance < numericAmount) {
      return setFormError("Ese apartado no tiene saldo suficiente.");
    }

    try {
      const snapshot = await addLocalTransaction({
        kind: movementKind,
        amount: numericAmount,
        sourcePocketId: sourceId,
        targetPocketId: movementKind === "transferencia" ? targetId : null,
        purpose: movementPurpose,
        note: movementNote,
        occurredAt: new Date(movementDate).toISOString(),
      });
      applySnapshot(snapshot);
      setEntryOpen(false);
      resetEntry();
      setToast("Movimiento guardado en tu libreta");
      await sendTelemetry("movement_saved", "movimientos");
    } catch (caught) {
      setFormError(caught instanceof Error ? caught.message : "No pudimos guardar el movimiento.");
    }
  }

  async function updateProfile(changes: { notebookTitle?: string; theme?: string; incomeFrequency?: string }) {
    try {
      applySnapshot(await updateLocalProfile(changes));
      setToast("Personalización guardada en este teléfono");
    } catch (caught) {
      setToast(caught instanceof Error ? caught.message : "No pudimos guardar el cambio");
    }
  }

  async function uploadPhoto(event: ChangeEvent<HTMLInputElement>) {
    const photo = event.target.files?.[0];
    if (!photo) return;
    try {
      const dataUrl = await photoToDataUrl(photo);
      applySnapshot(await setLocalPhoto(dataUrl));
      setToast("Foto personal guardada solo en este teléfono");
    } catch (caught) {
      setToast(caught instanceof Error ? caught.message : "No pudimos guardar la foto");
    }
    event.target.value = "";
  }

  // Formularios de agenda: editar reutiliza el mismo formulario de alta para evitar
  // que una tarjeta antigua pierda información al corregirse.
  function resetPaymentForm() {
    setEditingCardId(null);
    setCardAlias("");
    setCardCategory("tarjeta");
    setCardProvider("");
    setCardAmount("");
    setCardDueDate("");
    setCardPriority("relevante");
    setCardRecurrence("once");
    setCardReminderDays([5, 3, 1]);
  }

  function openNewPayment() {
    resetPaymentForm();
    setCardFormOpen(true);
  }

  function openPaymentEditor(card: StoredCard) {
    setEditingCardId(card.id);
    setCardAlias(card.alias);
    setCardCategory(card.category);
    setCardProvider(card.provider);
    setCardAmount(String(card.amount));
    setCardDueDate(card.dueDate ?? "");
    setCardPriority(card.priority);
    setCardRecurrence(card.recurrence);
    setCardReminderDays(card.reminderDays);
    setCardFormOpen(true);
  }

  function toggleReminderDay(day: number) {
    setCardReminderDays((current) => current.includes(day) ? current.filter((item) => item !== day) : [...current, day].sort((a, b) => b - a));
  }

  async function saveCard(event: FormEvent) {
    event.preventDefault();
    const wasEditing = Boolean(editingCardId);
    const input = {
      alias: cardAlias,
      category: cardCategory,
      provider: cardProvider,
      amountDue: Number(cardAmount),
      dueDate: cardDueDate || null,
      remindDaysBefore: cardReminderDays,
      priority: cardPriority,
      recurrence: cardRecurrence,
    };
    try {
      const snapshot = editingCardId ? await updateLocalCard(editingCardId, input) : await addLocalCard(input);
      applySnapshot(snapshot);
      setCardFormOpen(false);
      resetPaymentForm();
      setToast(wasEditing ? "Pago actualizado y recordatorios reprogramados" : "Pago agregado a tu agenda");
      await sendTelemetry("card_saved", "tarjetas");
    } catch (caught) {
      setToast(caught instanceof Error ? caught.message : "No pudimos guardar el pago");
    }
  }

  async function changePaymentStatus(card: StoredCard) {
    try {
      const nextStatus = card.status === "paid" ? "current" : "paid";
      applySnapshot(await setLocalCardStatus(card.id, nextStatus));
      setToast(nextStatus === "paid"
        ? card.recurrence === "monthly" ? "Pago registrado; movimos la fecha al próximo mes" : "Pago marcado como realizado"
        : "Pago marcado nuevamente como pendiente");
    } catch (caught) {
      setToast(caught instanceof Error ? caught.message : "No pudimos actualizar el pago");
    }
  }

  async function removePayment(card: StoredCard) {
    if (!window.confirm(`¿Eliminar “${card.alias}” de la agenda?`)) return;
    try {
      applySnapshot(await deleteLocalCard(card.id));
      setToast("Pago eliminado de la agenda");
    } catch (caught) {
      setToast(caught instanceof Error ? caught.message : "No pudimos eliminar el pago");
    }
  }

  // Formularios de metas y su transferencia. El retiro pide una confirmación extra
  // porque devuelve dinero reservado a un apartado disponible o de ahorro.
  function resetGoalForm() {
    setEditingGoalId(null);
    setGoalName("");
    setGoalPurpose("");
    setGoalTerm("mediano");
    setGoalTarget("");
    const suggestedDate = new Date();
    suggestedDate.setMonth(suggestedDate.getMonth() + 6);
    setGoalTargetDate(suggestedDate.toISOString().slice(0, 10));
    setGoalIcon("◎");
    setGoalColor("violet");
  }

  function openNewGoal() {
    resetGoalForm();
    setGoalFormOpen(true);
  }

  function openGoalEditor(goal: Goal) {
    setEditingGoalId(goal.id);
    setGoalName(goal.name);
    setGoalPurpose(goal.purpose);
    setGoalTerm(goal.term);
    setGoalTarget(String(goal.target));
    setGoalTargetDate(goal.targetDate);
    setGoalIcon(goal.icon);
    setGoalColor(goal.color);
    setGoalFormOpen(true);
  }

  async function saveGoal(event: FormEvent) {
    event.preventDefault();
    const wasEditing = Boolean(editingGoalId);
    const input = { name: goalName, purpose: goalPurpose, term: goalTerm, target: Number(goalTarget), targetDate: goalTargetDate, icon: goalIcon, color: goalColor };
    try {
      applySnapshot(editingGoalId ? await updateLocalGoal(editingGoalId, input) : await addLocalGoal(input));
      setGoalFormOpen(false);
      resetGoalForm();
      setToast(wasEditing ? "Objetivo actualizado" : "Tu nuevo objetivo está listo");
      await sendTelemetry(wasEditing ? "goal_updated" : "goal_created", "objetivos");
    } catch (caught) {
      setToast(caught instanceof Error ? caught.message : "No pudimos guardar el objetivo");
    }
  }

  async function removeGoal(goal: Goal) {
    if (!window.confirm(`¿Eliminar el objetivo “${goal.name}”?`)) return;
    try {
      applySnapshot(await deleteLocalGoal(goal.id));
      setGoalFormOpen(false);
      resetGoalForm();
      setToast("Objetivo eliminado");
    } catch (caught) {
      setToast(caught instanceof Error ? caught.message : "No pudimos eliminar el objetivo");
    }
  }

  function openGoalTransfer(goal: Goal, mode: GoalTransferMode) {
    const preferredPocket = pockets.find((pocket) => pocket.role === "available") ?? pockets[0];
    setGoalTransfer({ goal, mode });
    setGoalTransferAmount("");
    setGoalTransferPocketId(preferredPocket?.id ?? "");
    setGoalTransferNote("");
    setGoalWithdrawalConfirm(false);
  }

  function closeGoalTransfer() {
    setGoalTransfer(null);
    setGoalTransferAmount("");
    setGoalTransferNote("");
    setGoalWithdrawalConfirm(false);
  }

  async function submitGoalTransfer(event: FormEvent) {
    event.preventDefault();
    if (!goalTransfer) return;
    const numericAmount = Number(goalTransferAmount);
    if (!Number.isFinite(numericAmount) || numericAmount <= 0) return setToast("Escribe una cantidad mayor a cero");
    if (!goalTransferPocketId) return setToast("Elige un apartado para mover el dinero");
    if (goalTransfer.mode === "withdrawal" && numericAmount > goalTransfer.goal.saved) return setToast("Tu objetivo no tiene esa cantidad disponible");
    if (goalTransfer.mode === "withdrawal" && !goalWithdrawalConfirm) {
      setGoalWithdrawalConfirm(true);
      return;
    }
    try {
      const input = { goalId: goalTransfer.goal.id, pocketId: goalTransferPocketId, amount: numericAmount, note: goalTransferNote };
      applySnapshot(goalTransfer.mode === "contribution" ? await addLocalGoalContribution(input) : await withdrawFromLocalGoal(input));
      setToast(goalTransfer.mode === "contribution" ? "Aportación guardada. Estás más cerca de tu meta" : "Dinero devuelto al apartado seleccionado");
      await sendTelemetry(goalTransfer.mode === "contribution" ? "goal_contribution" : "goal_withdrawal", "objetivos");
      closeGoalTransfer();
    } catch (caught) {
      setGoalWithdrawalConfirm(false);
      setToast(caught instanceof Error ? caught.message : "No pudimos mover el dinero");
    }
  }

  async function savePocket(event: FormEvent) {
    event.preventDefault();
    const form = new FormData(event.currentTarget as HTMLFormElement);
    const name = String(form.get("name") || "").trim();
    const icon = String(form.get("icon") || "✦").trim();
    const color = String(form.get("color") || "violet");
    if (!name) return setToast("Ponle un nombre al apartado");
    try {
      applySnapshot(await addLocalPocket({ name, icon, color: color as Pocket["tone"] }));
      setPocketName(""); setPocketIcon("✦"); setPocketTone("violet"); setPocketFormOpen(false);
      setToast("Nuevo apartado listo para recibir dinero");
    } catch (caught) {
      setToast(caught instanceof Error ? caught.message : "No pudimos crear el apartado");
    }
  }

  function openCorrection(movement: Movement) {
    setEditingMovement(movement);
    setEditKind(movement.kind);
    setEditAmount(String(movement.amount));
    setEditSource(movement.sourcePocketId);
    setEditTarget(movement.targetPocketId ?? pockets.find((pocket) => pocket.id !== movement.sourcePocketId)?.id ?? movement.sourcePocketId);
    setEditOccurredAt(localDateTimeValue(new Date(movement.occurredAt)));
    setEditPurpose(movement.purpose);
    setEditNote(movement.note);
    setEditReason("");
    setEditError("");
  }

  async function saveCorrection(event: FormEvent) {
    event.preventDefault();
    if (!editingMovement) return;
    const numericAmount = Number(editAmount);
    if (!numericAmount || numericAmount <= 0) return setEditError("Escribe una cantidad mayor a cero.");
    if (!editPurpose.trim()) return setEditError("Indica para qué fue el movimiento.");
    if (!editReason.trim()) return setEditError("Explica por qué haces la corrección.");
    if (editKind === "transferencia" && editSource === editTarget) return setEditError("Elige apartados diferentes para la transferencia.");
    try {
      applySnapshot(await updateLocalTransaction({
        id: editingMovement.id,
        kind: editKind,
        amount: numericAmount,
        sourcePocketId: editSource,
        targetPocketId: editKind === "transferencia" ? editTarget : null,
        purpose: editPurpose,
        note: editNote,
        occurredAt: new Date(editOccurredAt).toISOString(),
        changeReason: editReason,
      }));
      setEditingMovement(null);
      setToast("Movimiento actualizado y saldos recalculados");
    } catch (caught) {
      setEditError(caught instanceof Error ? caught.message : "No pudimos guardar la corrección");
    }
  }

  async function removeMovement() {
    if (!editingMovement) return;
    if (!window.confirm(`¿Eliminar “${editingMovement.purpose}”? El saldo relacionado se recalculará.`)) return;
    try {
      applySnapshot(await deleteLocalTransaction(editingMovement.id));
      setEditingMovement(null);
      setToast("Movimiento eliminado y saldos recalculados");
    } catch (caught) {
      setEditError(caught instanceof Error ? caught.message : "No pudimos eliminar el movimiento");
    }
  }

  function openPocketEditor(pocket: Pocket) {
    setEditingPocket(pocket);
    setEditPocketName(pocket.name);
    setEditPocketIcon(pocket.icon);
    setEditPocketTone(pocket.tone);
    setEditPocketRole(pocket.role);
    setEditPocketBalance(String(pocket.balance));
  }

  async function savePocketChanges(event: FormEvent) {
    event.preventDefault();
    if (!editingPocket) return;
    try {
      applySnapshot(await updateLocalPocket({
        id: editingPocket.id,
        name: editPocketName,
        icon: editPocketIcon,
        color: editPocketTone,
        role: editPocketRole,
        balance: Number(editPocketBalance),
      }));
      setEditingPocket(null);
      setToast("Apartado actualizado");
    } catch (caught) {
      setToast(caught instanceof Error ? caught.message : "No pudimos actualizar el apartado");
    }
  }

  async function removePocket() {
    if (!editingPocket) return;
    if (!window.confirm(`¿Eliminar el apartado “${editingPocket.name}”? Solo puede eliminarse si está vacío y sin movimientos.`)) return;
    try {
      applySnapshot(await deleteLocalPocket(editingPocket.id));
      setEditingPocket(null);
      setToast("Apartado eliminado");
    } catch (caught) {
      setToast(caught instanceof Error ? caught.message : "No pudimos eliminar el apartado");
    }
  }

  async function resetNotebook() {
    if (!window.confirm("¿Borrar todos los movimientos, apartados, pagos, objetivos y ajustes de esta libreta? Descarga antes un respaldo si deseas conservarlos.")) return;
    if (!window.confirm("Esta acción no se puede deshacer. ¿Confirmas que deseas empezar de cero?")) return;
    try {
      applySnapshot(await resetLocalNotebook());
      await refreshSecurityStatus();
      setAppState("setup");
      setTab("inicio");
      setToast("");
    } catch (caught) {
      setToast(caught instanceof Error ? caught.message : "No pudimos restablecer la libreta");
    }
  }

  function useCalculator() {
    const result = calculateExpression(expression);
    if (result === null) return setFormError("Revisa la operación de la calculadora.");
    setAmount(result.toFixed(2));
    setCalculatorOpen(false);
    setFormError("");
  }

  async function enableNotifications() {
    if (isIOSDevice() && !installed) {
      setInstallHelpOpen(true);
      setToast("En iPhone, primero agrega la libreta a tu pantalla de inicio");
      return;
    }
    if (!("Notification" in window) || !("serviceWorker" in navigator) || !("PushManager" in window)) {
      setNotificationState("unsupported");
      setPushState("unsupported");
      return;
    }
    setPushState("enabling");
    try {
      const permission = await Notification.requestPermission();
      setNotificationState(permission);
      if (permission !== "granted") {
        setPushState(permission === "denied" ? "error" : "idle");
        return;
      }
      const configResponse = await fetch("/api/push-config");
      if (!configResponse.ok) throw new Error("Los recordatorios remotos todavía no están disponibles.");
      const config = await configResponse.json() as { publicKey: string };
      const registration = await navigator.serviceWorker.ready;
      const subscription = await registration.pushManager.getSubscription() ?? await registration.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: base64UrlToUint8Array(config.publicKey),
      });
      const result = await savePushSubscription(installId, subscription, true);
      await saveReminderSchedule(installId, cards);
      setPushState("active");
      await sendTelemetry("notification_test", "tarjetas");
      await sendTelemetry("push_subscribed", "tarjetas");
      setToast(result.testSent ? "Listo: enviamos un aviso de prueba" : "Recordatorios activados en este teléfono");
    } catch (caught) {
      setPushState("error");
      setToast(caught instanceof Error ? caught.message : "No pudimos activar los recordatorios");
    }
  }

  const pageTitle: Record<Tab, string> = {
    inicio: profile.notebookTitle || "Mi libreta",
    movimientos: "Mis apuntes",
    tarjetas: "Agenda de pagos",
    objetivos: "Mis objetivos",
    reportes: "Cierre del mes",
    ajustes: "Mi espacio",
  };
  const customThemeStyle = profile.theme.startsWith("#") ? ({
    "--purple": profile.theme,
    "--purple-deep": `color-mix(in srgb, ${profile.theme} 72%, black)`,
    "--purple-soft": `color-mix(in srgb, ${profile.theme} 14%, white)`,
  } as CSSProperties) : undefined;
  const installPlatform = getInstallPlatform();
  // Antes faltaba esta asignación: Pagos intentaba leer "isIOS" sin existir y
  // React detenía la pantalla completa. De aquí en adelante el tutorial puede
  // llevar a Pagos con seguridad, tanto en Android como en iPhone.
  const isIOS = isIOSDevice();
  const notificationsReady = notificationState === "granted" && pushState === "active";

  if (appState === "loading") {
    return <main className="loading-page"><div><span>$</span><strong>Abriendo tu libreta…</strong><i /></div></main>;
  }

  if (appState === "setup") {
    return <><Onboarding displayName={profile.displayName} onComplete={reloadFinance} />{installEntryOpen && <InstallChoiceSheet onInstall={() => void installApplication()} onUseWeb={continueInBrowser} />}</>;
  }

  if (appState === "error") {
    return <main className="loading-page"><div className="load-error"><span>!</span><strong>No pudimos abrir tu libreta</strong><p>{loadError}</p><button onClick={() => { setAppState("loading"); void reloadFinance(); }}>Intentar otra vez</button></div></main>;
  }

  return (
    <main className={`app-background theme-${profile.theme}`} style={customThemeStyle}>
      <div className="notebook-shell">
        <header className="app-header">
          <div>
            <p className="eyebrow">Libreta de finanzas</p>
            <h1>{pageTitle[tab]}</h1>
            <button className="notebook-switcher" type="button" onClick={() => setNotebookManagerOpen(true)} aria-label="Cambiar o administrar libretas">
              <span>▤</span>{activeNotebook?.name ?? profile.notebookTitle}<i>⌄</i>
            </button>
          </div>
          <div className="header-actions">
            {feedbackBubbleVisible && <button className="round-button feedback-bubble" aria-label="Enviar comentario anónimo" onClick={openGeneralFeedback}><span>📩</span></button>}
            <button className="round-button" aria-label="Abrir ajustes" onClick={() => goToTab("ajustes")}>
              <span className="gear-symbol">⚙</span>
            </button>
          </div>
        </header>

        <section className="page-content" aria-live="polite" key={tab}>
          {tab === "inicio" && (
            <div className="screen-stack">
              {!installed && <article className="install-card"><span className="install-app-icon">▣</span><div><strong>Instala tu libreta</strong><p>Ábrela desde tu pantalla principal como una aplicación normal.</p></div><button onClick={openInstallChoice}>Ver opciones</button></article>}
              <article className="balance-paper">
                <div className="balance-heading"><span>Disponible para gastar</span><small>Actualizado hoy</small></div>
                <strong>{money.format(totals.available)}</strong>
                <p className="balance-help">No incluye apartados ni objetivos · Separado: {money.format(totals.reserved + totals.goalSaved)}</p>
                <div className="month-summary">
                  <span><i className="income-dot" />Entró <b>{money.format(totals.income)}</b></span>
                  <span><i className="expense-dot" />Salió <b>{money.format(totals.expense)}</b></span>
                </div>
              </article>

              <div className="money-map" aria-label="Resumen de tu dinero">
                <article><span>Disponible</span><strong>{money.format(totals.available)}</strong><small>Para usar</small></article>
                <article><span>Apartados</span><strong>{money.format(totals.reserved)}</strong><small>Ahorro separado</small></article>
                <article><span>Objetivos</span><strong>{money.format(totals.goalSaved)}</strong><small>Para tus metas</small></article>
                <article><span>Total</span><strong>{money.format(totals.totalTracked)}</strong><small>En tu libreta</small></article>
              </div>

              <div className="quick-entry-actions" aria-label="Acciones rápidas">
                <button onClick={() => startMovement("ingreso")}><span>＋</span><strong>Ingreso</strong></button>
                <button onClick={() => startMovement("gasto")}><span>−</span><strong>Gasto</strong></button>
                <button onClick={() => startMovement("transferencia")}><span>↔</span><strong>Transferir</strong></button>
              </div>

              <button className="goal-home-banner" type="button" onClick={() => goToTab("objetivos")}>
                <span>◎</span><div><strong>{goals.length ? `${goals.length} ${goals.length === 1 ? "objetivo" : "objetivos"}` : "Crea tu primer objetivo"}</strong><p>{goals.length ? `${money.format(totals.goalSaved)} guardados para tus metas` : "Ponle fecha y sigue tu progreso paso a paso"}</p></div><i>›</i>
              </button>

              <div className="section-heading">
                <div><span className="handwritten">Mis apartados</span><p>Cada peso tiene su lugar</p></div>
                <button onClick={() => setPocketFormOpen(true)}>＋ Apartado</button>
              </div>
              <div className="pocket-grid">
                {pockets.map((pocket) => (
                  <article className="pocket-card-wrap" key={pocket.id}>
                    <button className={`pocket-card ${pocket.tone}`} onClick={() => startMovement("gasto", pocket.id)}>
                      <span className="pocket-icon">{pocket.icon}</span>
                      <span>{pocket.name}</span>
                      <strong>{money.format(pocket.balance)}</strong>
                      <small>{pocket.role === "available" ? "Dinero disponible" : "Dinero apartado"}</small>
                    </button>
                    <button className="pocket-edit" onClick={() => openPocketEditor(pocket)} aria-label={`Editar ${pocket.name}`}>✎ Editar</button>
                  </article>
                ))}
              </div>

              <div className="section-heading compact">
                <div><span className="handwritten">Últimos movimientos</span><p>Lo más reciente en tu libreta</p></div>
                <button onClick={() => goToTab("movimientos")}>Ver todos</button>
              </div>
              <MovementList movements={movements.slice(0, 3)} />
            </div>
          )}

          {tab === "movimientos" && (
            <div className="screen-stack">
              <div className="month-tabs">{monthOptions.map((month) => { const date = new Date(`${month}-15T12:00:00`); return <button key={month} className={selectedMonth === month ? "active" : ""} onClick={() => { setSelectedMonth(month); setMovementRenderLimit(80); }}>{new Intl.DateTimeFormat("es-MX", { month: "long", year: month.slice(0,4) === String(new Date().getFullYear()) ? undefined : "numeric" }).format(date)}</button>; })}</div>
              {movementGroups.length ? <>
                {visibleMovementGroups.map(([day, dayMovements]) => { const date = new Date(`${day}T12:00:00`); return <div className="lined-sheet" key={day}>
                <div className="sheet-date"><span>{date.getDate()}</span><div><b>{new Intl.DateTimeFormat("es-MX", { month: "long" }).format(date)}</b><small>{dayMovements.length} {dayMovements.length === 1 ? "movimiento" : "movimientos"}</small></div></div>
                <MovementList movements={dayMovements} detailed onEdit={openCorrection} />
                </div>; })}
                {renderedMovementCount < selectedMonthMovementCount && <button className="movement-load-more" type="button" onClick={() => setMovementRenderLimit((limit) => limit + 80)}>Mostrar 80 apuntes más</button>}
              </> : <div className="empty-paper"><span>≡</span><strong>No hay apuntes en este mes</strong><p>Puedes registrar movimientos actuales o pasar datos de tu cuaderno.</p></div>}
              <button className="primary-wide" onClick={() => setEntryOpen(true)}>＋ Anotar movimiento</button>
            </div>
          )}

          {tab === "tarjetas" && (
            <div className="screen-stack">
              <div className="permission-card">
                <div className="permission-icon">♢</div>
                <div><strong>Que no se te pase un pago</strong><p>Te avisamos con tiempo, incluso con la libreta cerrada.</p></div>
                {notificationsReady ? <span className="permission-ok">Activadas</span> : <button type="button" disabled={pushState === "enabling"} onClick={enableNotifications}>{pushState === "enabling" ? "Activando…" : "Activar"}</button>}
              </div>
              {isIOS && !installed && !notificationsReady && <p className="inline-warning">En iPhone, instálala en la pantalla de inicio antes de activar los avisos.</p>}
              {notificationState === "unsupported" && <p className="inline-warning">Este navegador no admite notificaciones. Los avisos seguirán apareciendo dentro de la libreta.</p>}
              {notificationState === "denied" && <p className="inline-warning">Las notificaciones están bloqueadas. Puedes activarlas desde los ajustes del navegador.</p>}
              {pushState === "error" && notificationState === "granted" && <p className="inline-warning">El permiso existe, pero falta terminar la conexión. Toca Activar para intentarlo de nuevo.</p>}

              <div className="agenda-summary" aria-label="Resumen de pagos">
                <article><strong>{paymentSummary.pending}</strong><span>Pendientes</span></article>
                <article><strong>{money.format(paymentSummary.total)}</strong><span>Por pagar</span></article>
                <article className={paymentSummary.overdue ? "alert" : ""}><strong>{paymentSummary.overdue}</strong><span>Vencidos</span></article>
              </div>

              <div className="section-heading agenda-heading"><div><span className="handwritten">Agenda de pagos</span><p>Organiza, prioriza y no olvides ningún pago.</p></div><button onClick={cardFormOpen ? () => { setCardFormOpen(false); resetPaymentForm(); } : openNewPayment}>{cardFormOpen ? "Cancelar" : "＋ Agregar pago"}</button></div>
              {cardFormOpen && <form className="payment-form" onSubmit={saveCard}>
                <div className="payment-form-title"><strong>{editingCardId ? "Editar pago" : "Nuevo pago"}</strong><span>{editingCardId ? "Actualiza lo necesario" : "Solo los datos que necesitas recordar"}</span></div>
                <fieldset className="payment-category-choice"><legend>¿Qué tipo de pago es? *</legend><div>{paymentCategories.map((category) => <button type="button" key={category.id} className={cardCategory === category.id ? "active" : ""} onClick={() => setCardCategory(category.id)}><span>{category.icon}</span>{category.label}</button>)}</div></fieldset>
                <label><span>Nombre del pago *</span><input value={cardAlias} onChange={(event) => setCardAlias(event.target.value)} placeholder="Ej. Tarjeta de crédito NU" maxLength={70} /></label>
                <label><span>{cardCategory === "tarjeta" ? "Banco o institución" : "Proveedor o empresa"}</span><input value={cardProvider} onChange={(event) => setCardProvider(event.target.value)} placeholder={cardCategory === "tarjeta" ? "Ej. NU, BBVA, Banamex" : "Ej. CFE, Totalplay, Netflix"} maxLength={70} /></label>
                <div className="form-two"><label><span>Cantidad por pagar *</span><input inputMode="decimal" value={cardAmount} onChange={(event) => setCardAmount(event.target.value.replace(/[^0-9.]/g, ""))} placeholder="$ 0.00" /></label><label><span>Fecha límite *</span><input type="date" value={cardDueDate} onChange={(event) => setCardDueDate(event.target.value)} /></label></div>
                <fieldset className="payment-recurrence"><legend>¿Cada cuándo se repite?</legend><div><button type="button" className={cardRecurrence === "once" ? "active" : ""} onClick={() => setCardRecurrence("once")} aria-pressed={cardRecurrence === "once"}><strong>Solo este mes</strong><small>Pago único; al marcarlo pagado se cierra.</small></button><button type="button" className={cardRecurrence === "monthly" ? "active" : ""} onClick={() => setCardRecurrence("monthly")} aria-pressed={cardRecurrence === "monthly"}><strong>Todos los meses</strong><small>Suscripción o servicio; al pagarlo avanza a la siguiente fecha.</small></button></div></fieldset>
                <fieldset className="reminder-choice"><legend>¿Cuándo quieres recordatorios?</legend><div>{[5, 3, 1].map((day) => <button type="button" key={day} className={cardReminderDays.includes(day) ? "active" : ""} onClick={() => toggleReminderDay(day)} aria-pressed={cardReminderDays.includes(day)}>{cardReminderDays.includes(day) ? "✓ " : ""}{day} {day === 1 ? "día" : "días"} antes</button>)}</div></fieldset>
                <label><span>Importancia *</span><select value={cardPriority} onChange={(event) => setCardPriority(event.target.value as LocalPaymentPriority)}><option value="relevante">Relevante</option><option value="poco_relevante">Poco relevante</option><option value="irrelevante">Irrelevante</option></select></label>
                <p className="payment-privacy">Nunca pediremos número de tarjeta, CVV ni NIP.</p>
                <div className="payment-form-actions"><button type="button" onClick={() => { setCardFormOpen(false); resetPaymentForm(); }}>Cancelar</button><button type="submit">{editingCardId ? "Guardar cambios" : "Guardar pago"}</button></div>
              </form>}

              <div className="payment-toolbar">
                <div className="payment-filters" aria-label="Filtrar pagos"><button className={paymentFilter === "todas" ? "active" : ""} onClick={() => setPaymentFilter("todas")}>▦ Todas</button>{paymentCategories.map((category) => <button key={category.id} className={paymentFilter === category.id ? "active" : ""} onClick={() => setPaymentFilter(category.id)}>{category.icon} {category.label}</button>)}</div>
                <label>Ordenar por <select value={paymentSort} onChange={(event) => setPaymentSort(event.target.value as PaymentSort)}><option value="prioridad">Importancia</option><option value="fecha">Fecha límite</option><option value="monto">Cantidad</option></select></label>
              </div>

              <div className="agenda-list">
                {visiblePayments.length ? visiblePayments.map((card) => <PaymentCard key={card.id} card={card} onEdit={openPaymentEditor} onStatus={changePaymentStatus} onDelete={removePayment} />) : cards.length ? <div className="empty-paper"><span>⌕</span><strong>No hay pagos en esta categoría</strong><p>Prueba el filtro “Todas” para ver la agenda completa.</p></div> : <div className="empty-paper"><span>▤</span><strong>Tu agenda está vacía</strong><p>Agrega tarjetas, servicios, renta, préstamos o suscripciones.</p></div>}
              </div>
              <div className="privacy-strip"><span>▣</span><p><strong>Tu seguridad primero</strong>Nunca te pediremos número de tarjeta, CVV ni NIP.</p></div>
            </div>
          )}

          {tab === "objetivos" && (
            <div className="screen-stack">
              <article className="goals-cover">
                <div><span className="eyebrow">Tu avance total</span><strong>{money.format(goalSummary.saved)}</strong><p>de {money.format(goalSummary.target)} para todos tus objetivos</p></div>
                <span className="goals-cover-mark">◎</span>
                <div className="goals-total-progress"><i><b style={{ width: `${goalSummary.target ? Math.min(100, (goalSummary.saved / goalSummary.target) * 100) : 0}%` }} /></i><small>{goalSummary.target ? Math.round((goalSummary.saved / goalSummary.target) * 100) : 0}% completado</small></div>
                <div className="goals-cover-counts"><span><b>{goalSummary.active}</b> En camino</span><span><b>{goalSummary.completed}</b> Cumplidos</span></div>
              </article>

              <div className="section-heading agenda-heading"><div><span className="handwritten">Mis objetivos</span><p>Un paso pequeño también cuenta.</p></div><button onClick={openNewGoal}>＋ Nuevo objetivo</button></div>
              <div className="goal-filters" aria-label="Filtrar objetivos"><button className={goalFilter === "todos" ? "active" : ""} onClick={() => setGoalFilter("todos")}>Todos</button>{goalTerms.map((term) => <button key={term.id} className={goalFilter === term.id ? "active" : ""} onClick={() => setGoalFilter(term.id)}>{term.label}</button>)}</div>

              <div className="goal-list">
                {visibleGoals.length ? visibleGoals.map((goal) => <GoalCard key={goal.id} goal={goal} movementCount={goalMovements.filter((movement) => movement.goalId === goal.id).length} onContribute={(selected) => openGoalTransfer(selected, "contribution")} onWithdraw={(selected) => openGoalTransfer(selected, "withdrawal")} onEdit={openGoalEditor} />) : goals.length ? <div className="empty-paper"><span>⌕</span><strong>No hay objetivos de este plazo</strong><p>Prueba el filtro “Todos” o crea una meta nueva.</p></div> : <div className="empty-paper goal-empty"><span>◎</span><strong>¿Qué sueño quieres convertir en plan?</strong><p>Crea un objetivo, define cuánto necesitas y aporta desde cualquiera de tus apartados.</p><button type="button" onClick={openNewGoal}>Crear mi primer objetivo</button></div>}
              </div>

              <div className="goal-privacy"><span>✓</span><p><strong>Tu dinero no se duplica</strong>Cada aportación sale del apartado que elijas y queda reservado en el objetivo. Al retirar, vuelve al apartado seleccionado.</p></div>
            </div>
          )}

          {tab === "reportes" && (
            <div className="screen-stack">
              <div className="report-month-picker" aria-label="Elegir mes para el reporte">
                <div><strong>Elige el mes</strong><small>El resumen y los archivos usarán este periodo.</small></div>
                <select value={reportMonth} onChange={(event) => setReportMonth(event.target.value)}>
                  {monthOptions.map((month) => <option key={month} value={month}>{new Intl.DateTimeFormat("es-MX", { month: "long", year: "numeric" }).format(new Date(`${month}-15T12:00:00`))}</option>)}
                </select>
              </div>
              <article className="report-cover">
                <span className="report-month">{monthlyReportExport.monthLabel.toUpperCase()}</span>
                <h2>Tu cierre del mes</h2>
                <strong className={reportTotals.net >= 0 ? "good" : "bad"}>{money.format(reportTotals.net)}</strong>
                <p>{reportTotals.movementCount ? (reportTotals.net >= 0 ? "Ingresaste más de lo que gastaste." : "Gastaste más de lo que ingresaste.") : "Aún no hay movimientos en este mes."}</p>
                <div className="report-bars">
                  <div><span>Ingresos</span><i><b style={{ width: reportTotals.income ? "86%" : "0%" }} /></i><strong>{money.format(reportTotals.income)}</strong></div>
                  <div><span>Gastos</span><i><b style={{ width: `${Math.min(100, reportTotals.income ? (reportTotals.expense / reportTotals.income) * 86 : 0)}%` }} /></i><strong>{money.format(reportTotals.expense)}</strong></div>
                </div>
              </article>
              <article className="spending-analysis" aria-label="Porcentaje de gastos sobre tus ingresos">
                <div className="spending-analysis-heading"><span>◔</span><div><strong>¿En qué se fue tu ingreso?</strong><p>De cada $100 que entraron en el mes elegido.</p></div></div>
                {spendingByIncome.income > 0 && spendingByIncome.items.length ? <>
                  <div className="income-explainer"><b>{money.format(spendingByIncome.income)}</b><span>ingresos registrados · {money.format(spendingByIncome.expense)} en gastos</span></div>
                  <div className="spending-bars">{spendingByIncome.items.map((item, index) => <div key={item.name}><div><strong>{item.name}</strong><span>{money.format(item.amount)} · {item.percent.toFixed(1)}%</span></div><i><b className={`spending-color-${index + 1}`} style={{ width: `${Math.min(100, item.percent)}%` }} /></i></div>)}</div>
                  <p className="spending-analysis-note">El porcentaje se calcula sobre tus ingresos, no sobre tus gastos. Si pasa de 100%, ese gasto fue mayor que lo que ingresaste en el mes.</p>
                </> : <div className="analysis-empty"><span>◔</span><p>{spendingByIncome.expense ? "Registra al menos un ingreso en este periodo para comparar estos gastos." : "Cuando registres ingresos y gastos, aquí verás qué parte de tu dinero se fue en cada cosa."}</p></div>}
              </article>
              <div className="report-grid"><article><span>⌂</span><small>Disponible ahora</small><strong>{money.format(totals.available)}</strong><p>No cuenta apartados ni objetivos</p></article><article><span>◎</span><small>Guardado en objetivos</small><strong>{money.format(totals.goalSaved)}</strong><p>{goalSummary.completed} cumplidos · {goalSummary.active} en camino</p></article><article><span>↗</span><small>Mayor gasto del mes</small><strong>{reportMovements.filter((item) => item.kind === "gasto").sort((left, right) => right.amount - left.amount)[0]?.purpose ?? "Sin gastos"}</strong><p>{money.format(reportMovements.filter((item) => item.kind === "gasto").sort((left, right) => right.amount - left.amount)[0]?.amount ?? 0)}</p></article><article><span>▤</span><small>Movimientos del mes</small><strong>{reportTotals.movementCount}</strong><p>Ingresos, gastos y transferencias</p></article></div>
              <article className="monthly-export-card"><div><span>⇩</span><div><strong>Guarda tu cierre mensual</strong><p>Incluye resumen, porcentajes, movimientos y pagos de esta libreta. Se crea en tu teléfono.</p></div></div><div className="monthly-export-actions"><button type="button" onClick={() => void exportMonthlyReport("excel")}>Excel (.xlsx)</button><button type="button" onClick={() => void exportMonthlyReport("pdf")}>PDF</button></div></article>
              <button className="secondary-wide" onClick={downloadBackup}>Descargar respaldo completo de todas mis libretas</button>
            </div>
          )}

          {tab === "ajustes" && (
            <div className="screen-stack">
              <div className="profile-paper"><label className="profile-photo">{profile.photoDataUrl ? <Image src={profile.photoDataUrl} alt="Foto personal" width={72} height={72} unoptimized /> : <span>{profile.displayName ? profile.displayName.split(/\s+/).map((part) => part[0]).join("").slice(0, 2).toUpperCase() : "YO"}</span>}<input type="file" accept="image/jpeg,image/png,image/webp" onChange={uploadPhoto} /><small>Cambiar</small></label><div><strong>{profile.notebookTitle}</strong><p>Beta local · Tus finanzas no se suben</p></div></div>
              <div className="customize-paper"><label><span>Título de mi libreta</span><input value={profile.notebookTitle} onChange={(event) => setProfile((current) => ({ ...current, notebookTitle: event.target.value }))} onBlur={() => void updateProfile({ notebookTitle: profile.notebookTitle })} maxLength={60} /></label><label><span>Frecuencia de ingreso</span><select value={profile.incomeFrequency} onChange={(event) => void updateProfile({ incomeFrequency: event.target.value })}><option value="semanal">Semanal</option><option value="quincenal">Quincenal</option><option value="mensual">Mensual</option><option value="variable">Sin fecha fija</option></select></label><fieldset className="theme-field"><legend>Color de mi libreta</legend><div>{["purple","blue","green","rose","orange"].map((color) => <button type="button" key={color} className={`${color} ${profile.theme === color ? "selected" : ""}`} onClick={() => void updateProfile({ theme: color })} aria-label={`Usar color ${color}`} />)}<label className="custom-color" title="Elegir otro color"><input type="color" value={profile.theme.startsWith("#") ? profile.theme : "#6d42c1"} onChange={(event) => void updateProfile({ theme: event.target.value })} /><span>＋</span></label></div></fieldset></div>
              <SettingsRow icon="▤" title="Mis libretas" value={`${notebooks.length || 1} ${notebooks.length === 1 ? "libreta en este teléfono" : "libretas en este teléfono"}`} onClick={openNotebookManager} />
              <SettingsRow icon="?" title="Guías y tutoriales" value="Elige una función o repite el recorrido completo" onClick={() => setGuideOpen(true)} />
              <SettingsRow icon="♢" title="Recordatorios" value={notificationsReady ? "Activos aun con la app cerrada" : "Por activar"} onClick={enableNotifications} />
              <SettingsRow icon="▣" title={installed ? "Aplicación instalada" : "Instalar en este teléfono"} value={installed ? "Lista en tu pantalla principal" : "Ver opciones y pasos para tu teléfono"} onClick={openInstallChoice} />
              <SettingsRow icon="▰" title="Protección de datos" value={safetyCopy.available ? "Copia interna lista para recuperar" : persistentStorage === "active" ? "Almacenamiento protegido en este teléfono" : "Revisa respaldo y protección local"} onClick={() => setSecurityCenterOpen(true)} />
              <SettingsRow icon="☁" title="Respaldo local" value="Guardar copia en OneDrive, Drive o iCloud" onClick={downloadBackup} />
              <label className="settings-row import-settings"><span>↶</span><div><strong>Restaurar respaldo</strong><p>Importar una copia anterior en este teléfono</p></div><i>›</i><input type="file" accept="application/json,.json" onChange={restoreBackup} /></label>
              <SettingsRow icon="⌫" title="Empezar de cero" value="Borrar esta libreta después de dos confirmaciones" onClick={resetNotebook} />
              <button className="consent-card" type="button" onClick={() => void changeAnalyticsConsent(!analyticsConsent)} aria-pressed={analyticsConsent}><span className={analyticsConsent ? "on" : ""}><i /></span><div><strong>Ayudar a mejorar la beta</strong><p>Comparte fallos, tiempos de carga y funciones usadas. Nunca cantidades, saldos, notas, fotos ni nombres de pagos u objetivos.</p></div></button>
              <SettingsRow icon="📩" title="Enviar comentario anónimo" value="Lo leerá el propietario para mejorar la aplicación" onClick={openGeneralFeedback} />
              <SettingsRow icon={feedbackBubbleVisible ? "◉" : "○"} title="Burbuja de comentarios" value={feedbackBubbleVisible ? "Visible junto al botón de Ajustes" : "Oculta; toca aquí para mostrarla"} onClick={() => changeFeedbackBubble(!feedbackBubbleVisible)} />
              <div className="privacy-strip"><span>✓</span><p><strong>Permisos mínimos</strong>Solo notificaciones y la fotografía que tú elijas. Sin contactos, ubicación, micrófono ni acceso bancario.</p></div>
            </div>
          )}

          <ProductCredit />
        </section>

        <nav className="bottom-nav" aria-label="Navegación principal">
          <NavButton label="Inicio" symbol="⌂" active={tab === "inicio"} onClick={() => goToTab("inicio")} />
          <NavButton label="Apuntes" symbol="≡" active={tab === "movimientos"} onClick={() => goToTab("movimientos")} />
          <NavButton label="Pagos" symbol="▤" active={tab === "tarjetas"} onClick={() => goToTab("tarjetas")} />
          <button className="add-button" aria-label="Anotar movimiento" onClick={() => setEntryOpen(true)}>＋</button>
          <NavButton label="Objetivos" symbol="◎" active={tab === "objetivos"} onClick={() => goToTab("objetivos")} />
          <NavButton label="Reporte" symbol="▥" active={tab === "reportes"} onClick={() => goToTab("reportes")} />
          <NavButton label="Ajustes" symbol="⚙" active={tab === "ajustes"} onClick={() => goToTab("ajustes")} />
        </nav>
      </div>

      {notebookManagerOpen && <div className="modal-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) closeNotebookManager(); }}><section className="entry-sheet notebook-manager-sheet" role="dialog" aria-modal="true" aria-labelledby="notebook-manager-title"><div className="grabber" /><div className="entry-heading"><div><p className="eyebrow">Tus espacios separados</p><h2 id="notebook-manager-title">Mis libretas</h2></div><button onClick={closeNotebookManager} aria-label="Cerrar">×</button></div>
        <p className="notebook-manager-help">Cada libreta tiene separados sus apartados, apuntes, pagos, objetivos y reportes.</p>
        {notebookSummaries.length > 1 && <section className="notebook-comparison" aria-label="Comparación de mis libretas"><button className="notebook-comparison-toggle" type="button" onClick={() => { setNotebookComparisonOpen((current) => !current); void refreshNotebookComparison(); }} aria-expanded={notebookComparisonOpen}><span>▥</span><div><strong>Comparación por periodo</strong><small>Compara ingresos, gastos y resultado sin mezclarlos</small></div><i>{notebookComparisonOpen ? "⌃" : "⌄"}</i></button>{notebookComparisonOpen && <><div className="notebook-comparison-period"><strong>Elige el mes a comparar</strong><div>{(notebookComparison?.availableMonths ?? []).map((month) => <button key={month} type="button" className={notebookComparisonMonth === month ? "active" : ""} onClick={() => void refreshNotebookComparison(month)}>{new Intl.DateTimeFormat("es-MX", { month: "short", year: "numeric" }).format(new Date(`${month}-15T12:00:00`)).replace(".", "")}</button>)}</div></div><p className="notebook-comparison-note">Cada tarjeta pertenece a una libreta. Aquí solo comparamos resultados; no se suman ni se transfieren montos.</p><div className="notebook-comparison-scroll">{(notebookComparison?.notebooks ?? notebookSummaries).map((notebook) => <article className={`notebook-summary-card ${notebook.id === activeNotebookId ? "active" : ""}`} key={notebook.id}><div><strong>{notebook.name}</strong>{notebook.id === activeNotebookId && <small>En uso</small>}</div>{"incomeCents" in notebook ? <dl><div><dt>Ingresos del mes</dt><dd>{money.format(notebook.incomeCents / 100)}</dd></div><div><dt>Gastos del mes</dt><dd>{money.format(notebook.expenseCents / 100)}</dd></div><div><dt>Resultado del mes</dt><dd className={notebook.netCents >= 0 ? "positive" : "negative"}>{notebook.netCents >= 0 ? "+" : "−"}{money.format(Math.abs(notebook.netCents) / 100)}</dd></div><div><dt>Disponible hoy</dt><dd>{money.format(notebook.availableCents / 100)}</dd></div><div><dt>Dinero apartado</dt><dd>{money.format(notebook.reservedCents / 100)}</dd></div><div><dt>En objetivos</dt><dd>{money.format(notebook.goalSavedCents / 100)}</dd></div></dl> : <dl><div><dt>Disponible</dt><dd>{money.format(notebook.availableCents / 100)}</dd></div><div><dt>Apartados</dt><dd>{money.format(notebook.reservedCents / 100)}</dd></div></dl>}<p>{"movementCount" in notebook ? `${notebook.movementCount} ${notebook.movementCount === 1 ? "movimiento" : "movimientos"} en el mes` : "Cargando resultados del periodo…"} · {notebook.pendingPayments} {notebook.pendingPayments === 1 ? "pago pendiente" : "pagos pendientes"}</p><button type="button" onClick={() => void chooseNotebook(notebook.id)}>{notebook.id === activeNotebookId ? "Libreta actual" : "Abrir esta libreta"}</button></article>)}</div></>}</section>}
        <div className="notebook-list">
          {notebooks.filter((notebook) => !notebook.archivedAt).map((notebook) => <article className={`notebook-choice ${notebook.id === activeNotebookId ? "active" : ""}`} key={notebook.id}>
            {renamingNotebookId === notebook.id ? <form className="notebook-rename-form" onSubmit={saveNotebookName}><label><span>Nombre de la libreta</span><input value={renamedNotebookName} onChange={(event) => setRenamedNotebookName(event.target.value)} maxLength={60} autoFocus /></label><div><button type="button" onClick={() => { setRenamingNotebookId(null); setRenamedNotebookName(""); }}>Cancelar</button><button type="submit">Guardar</button></div></form> : <><button className="notebook-choice-main" type="button" onClick={() => void chooseNotebook(notebook.id)}><span>{notebook.id === activeNotebookId ? "✓" : "▤"}</span><div><strong>{notebook.name}</strong><small>{notebook.id === activeNotebookId ? "Estás usando esta libreta" : "Toca para cambiar"}</small></div><i>{notebook.id === activeNotebookId ? "Actual" : "›"}</i></button><div className="notebook-choice-actions"><button type="button" onClick={() => startNotebookRename(notebook)}>Renombrar</button><button type="button" disabled={notebooks.filter((item) => !item.archivedAt).length < 2} onClick={() => void archiveNotebook(notebook)}>Archivar</button><button className="delete-notebook" type="button" disabled={notebooks.length < 2} onClick={() => { setDeletingNotebook(notebook); setDeleteNotebookName(""); }}>Eliminar</button></div></>}
          </article>)}
        </div>
        {notebooks.some((notebook) => notebook.archivedAt) && <section className="archived-notebooks"><div><strong>Libretas archivadas</strong><p>No aparecen en el resumen ni en la comparación. Sus datos siguen guardados.</p></div>{notebooks.filter((notebook) => notebook.archivedAt).map((notebook) => <article key={notebook.id}><div><strong>{notebook.name}</strong><small>Archivada · puedes recuperarla cuando quieras</small></div><button type="button" onClick={() => void restoreNotebook(notebook)}>Recuperar</button><button type="button" className="delete-notebook" onClick={() => { setDeletingNotebook(notebook); setDeleteNotebookName(""); }}>Eliminar</button></article>)}</section>}
        <form className="new-notebook-form" onSubmit={createNotebook}><label><span>Nueva libreta</span><input value={newNotebookName} onChange={(event) => setNewNotebookName(event.target.value)} placeholder="Ej. Cuenta familiar o Negocio" maxLength={60} /></label><button className="save-button" type="submit">＋ Crear otra libreta</button></form>
        <div className="required-note">▣ Al crear una nueva libreta comienza con “Dinero disponible” en $0.00. Puedes agregar apartados y personalizarla después.</div>
      </section></div>}

      {deletingNotebook && <div className="modal-backdrop" role="presentation"><section className="entry-sheet delete-notebook-sheet" role="dialog" aria-modal="true" aria-labelledby="delete-notebook-title"><div className="grabber" /><div className="entry-heading"><div><p className="eyebrow">Acción permanente</p><h2 id="delete-notebook-title">Eliminar libreta</h2></div><button onClick={() => { setDeletingNotebook(null); setDeleteNotebookName(""); }} aria-label="Cerrar">×</button></div><p>Eliminarás <strong>“{deletingNotebook.name}”</strong> y todos sus apuntes, apartados, pagos y objetivos de este teléfono.</p><div className="delete-backup-note"><span>☁</span><div><strong>Primero guarda un respaldo</strong><p>Descarga una copia completa antes de borrar, por si después necesitas recuperar algo.</p><button type="button" onClick={downloadBackup}>Descargar respaldo</button></div></div><label><span>Para confirmar, escribe exactamente: <strong>{deletingNotebook.name}</strong></span><input value={deleteNotebookName} onChange={(event) => setDeleteNotebookName(event.target.value)} autoComplete="off" autoFocus /></label><button className="delete-confirm-button" type="button" disabled={deleteNotebookName.trim() !== deletingNotebook.name} onClick={() => void removeNotebook(deletingNotebook)}>Eliminar libreta definitivamente</button><button className="tutorial-skip-button" type="button" onClick={() => { setDeletingNotebook(null); setDeleteNotebookName(""); }}>Cancelar</button></section></div>}

      {securityCenterOpen && <div className="modal-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) setSecurityCenterOpen(false); }}><section className="entry-sheet security-sheet" role="dialog" aria-modal="true" aria-labelledby="security-title"><div className="grabber" /><div className="entry-heading"><div><p className="eyebrow">Tus datos, bajo tu control</p><h2 id="security-title">Protección de datos</h2></div><button onClick={() => setSecurityCenterOpen(false)} aria-label="Cerrar">×</button></div><article className="security-sheet-hero"><span>✓</span><div><strong>Tu información financiera permanece en este teléfono</strong><p>No enviamos montos, saldos, notas, pagos, fotos ni objetivos a la beta.</p></div></article><div className="security-check-list"><article><span>☁</span><div><strong>Respaldo externo</strong><p>{lastBackupAt ? `Último respaldo registrado: ${securityDateLabel(lastBackupAt)}.` : "Aún no registramos un respaldo desde esta instalación."}</p></div><button type="button" onClick={() => void downloadBackup()}>Crear respaldo</button></article><article><span>▰</span><div><strong>Protección del almacenamiento</strong><p>{persistentStorage === "active" ? "Este navegador indicó que protege el almacenamiento local de la app." : persistentStorage === "available" ? "Puedes solicitar que el navegador conserve mejor los datos locales." : "Este navegador no ofrece esta protección adicional; usa respaldos externos."}</p></div>{persistentStorage === "available" && <button type="button" onClick={() => void enablePersistentStorage()}>Activar</button>}</article><article><span>↶</span><div><strong>Copia interna de seguridad</strong><p>{safetyCopy.available ? `Guardada ${securityDateLabel(safetyCopy.createdAt)} antes de ${safetyCopy.reason === "before_restore" ? "una restauración" : safetyCopy.reason === "before_reset" ? "reiniciar la libreta" : "una eliminación"}.` : "Aparece automáticamente antes de restaurar, eliminar o reiniciar."}</p></div>{safetyCopy.available && <button type="button" onClick={() => void recoverSafetyCopy()}>Recuperar</button>}</article></div><p className="security-sheet-note">Importante: una copia interna ayuda ante una acción reciente, pero se pierde si desinstalas la app o borras los datos del navegador. Por eso guarda también un respaldo en Archivos, Drive, OneDrive o iCloud.</p></section></div>}

      {tutorialPromptOpen && <div className="modal-backdrop tutorial-backdrop" role="presentation"><section className="entry-sheet tutorial-prompt-sheet" role="dialog" aria-modal="true" aria-labelledby="tutorial-prompt-title"><div className="tutorial-welcome-mark">?</div><p className="eyebrow">Guía opcional</p><h2 id="tutorial-prompt-title">¿Quieres conocer cada botón?</h2><p>Es un recorrido corto por las funciones principales. No cambiará ningún dato de tu libreta.</p><button className="save-button" onClick={() => startTutorial(0, false, true)}>Mostrarme el tutorial</button><button className="tutorial-skip-button" onClick={() => rememberTutorialChoice("skipped")}>Omitir por ahora</button><small>Podrás abrir cualquier tema después desde Ajustes → Guías y tutoriales.</small></section></div>}

      {guideOpen && <div className="modal-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) setGuideOpen(false); }}><section className="entry-sheet guide-sheet" role="dialog" aria-modal="true" aria-labelledby="guide-title"><div className="grabber" /><div className="entry-heading"><div><p className="eyebrow">Ayuda cuando la necesites</p><h2 id="guide-title">Guías y tutoriales</h2></div><button onClick={() => setGuideOpen(false)} aria-label="Cerrar">×</button></div><article className="tutorial-full-card"><span>✦</span><div><strong>Recorrido completo</strong><p>Repasa las 7 funciones principales, paso a paso.</p></div><button type="button" onClick={() => startTutorial()}>Ver completo</button></article><div className="guide-topic-heading"><strong>Elige solo una función</strong><p>Abre la explicación que te haga falta, sin repetir todo.</p></div><div className="guide-topic-list">{tutorialTopics.map((topic, index) => <button type="button" key={topic.id} onClick={() => startTutorial(index, true)}><span>{topic.icon}</span><div><strong>{topic.label}</strong><p>{topic.title}</p></div><i>›</i></button>)}</div></section></div>}

      {tutorialRun && (() => { const topic = tutorialTopics[tutorialRun.topicIndex]; const isLastTopic = tutorialRun.topicIndex === tutorialTopics.length - 1; return <div className="modal-backdrop tutorial-backdrop" role="presentation"><section className="entry-sheet tutorial-sheet" role="dialog" aria-modal="true" aria-labelledby="tutorial-title"><div className="tutorial-progress" aria-label={`Paso ${tutorialRun.topicIndex + 1} de ${tutorialTopics.length}`}><span>{tutorialRun.singleTopic ? "Guía elegida" : `Paso ${tutorialRun.topicIndex + 1} de ${tutorialTopics.length}`}</span><i><b style={{ width: `${tutorialRun.singleTopic ? 100 : ((tutorialRun.topicIndex + 1) / tutorialTopics.length) * 100}%` }} /></i></div><div className="tutorial-topic-icon">{topic.icon}</div><p className="eyebrow">{topic.label}</p><h2 id="tutorial-title">{topic.title}</h2><p className="tutorial-description">{topic.description}</p><div className="tutorial-tip"><span>✓</span><p>{topic.tip}</p></div><p className="tutorial-screen-note">Te llevamos a la pantalla real de esta función. Puedes usarla cuando termines la guía.</p><div className="tutorial-actions">{!tutorialRun.singleTopic && tutorialRun.topicIndex > 0 && <button type="button" className="tutorial-back-button" onClick={() => moveThroughTutorial(-1)}>Atrás</button>}<button type="button" className="save-button" onClick={() => tutorialRun.singleTopic || isLastTopic ? finishTutorial() : moveThroughTutorial(1)}>{tutorialRun.singleTopic ? "Entendido" : isLastTopic ? tutorialRun.askForFeedback ? "Terminar y comentar" : "Terminar" : "Siguiente"}</button></div><button type="button" className="tutorial-exit-button" onClick={() => setTutorialRun(null)}>Terminar tutorial</button></section></div>; })()}

      {entryOpen && (
        <div className="modal-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) setEntryOpen(false); }}>
          <section className="entry-sheet" role="dialog" aria-modal="true" aria-labelledby="entry-title">
            <div className="grabber" />
            <div className="entry-heading"><div><p className="eyebrow">Nuevo apunte</p><h2 id="entry-title">Registrar movimiento</h2></div><button onClick={() => setEntryOpen(false)} aria-label="Cerrar">×</button></div>
            <form onSubmit={saveMovement}>
              <input type="hidden" name="kind" value={kind} />
              <div className="kind-switch">
                {(["ingreso", "gasto", "transferencia"] as MovementKind[]).map((item) => <button type="button" key={item} className={kind === item ? "active" : ""} onClick={() => { setKind(item); setFormError(""); }}>{item[0].toUpperCase() + item.slice(1)}</button>)}
              </div>
              <label className="amount-field"><span>Monto</span><div><b>$</b><input name="amount" inputMode="decimal" value={amount} onChange={(event) => setAmount(event.target.value.replace(/[^0-9.]/g, ""))} placeholder="0.00" aria-label="Monto" /><button type="button" onClick={() => setCalculatorOpen((value) => !value)} aria-label="Abrir calculadora">▦</button></div></label>
              {calculatorOpen && <Calculator expression={expression} setExpression={setExpression} onUse={useCalculator} />}
              <div className={kind === "transferencia" ? "form-two" : ""}>
                <label><span>{kind === "transferencia" ? "Sale de *" : kind === "ingreso" ? "¿Dónde lo guardamos? *" : "¿De qué apartado sale? *"}</span><select name="source" value={source} onChange={(event) => setSource(event.target.value)}>{pockets.map((pocket) => <option value={pocket.id} key={pocket.id}>{pocket.name} · {money.format(pocket.balance)}</option>)}</select></label>
                {kind === "transferencia" && <label><span>Va para *</span><select name="target" value={target} onChange={(event) => setTarget(event.target.value)}>{pockets.map((pocket) => <option value={pocket.id} key={pocket.id}>{pocket.name}</option>)}</select></label>}
              </div>
              <label><span>{kind === "gasto" ? "¿Para qué se utilizó? *" : "Motivo del movimiento *"}</span><input name="purpose" value={purpose} onChange={(event) => setPurpose(event.target.value)} placeholder={kind === "gasto" ? "Ej. Pago de despensa" : "Ej. Ingreso quincenal"} /></label>
              <label><span>Nota (opcional)</span><textarea name="note" value={note} onChange={(event) => setNote(event.target.value)} placeholder="Agrega algún detalle que quieras recordar" rows={2} /></label>
              <label><span>Fecha y hora del movimiento *</span><input name="occurredAt" type="datetime-local" value={occurredAt} max={localDateTimeValue()} onChange={(event) => setOccurredAt(event.target.value)} /><small className="field-help">Puedes elegir una fecha anterior para pasar apuntes de tu cuaderno.</small></label>
              <div className="required-note">▣ El motivo siempre será obligatorio para retirar o modificar dinero.</div>
              {formError && <p className="form-error">{formError}</p>}
              <button className="save-button" type="submit">Guardar en mi libreta</button>
            </form>
          </section>
        </div>
      )}
      {pocketFormOpen && <div className="modal-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) setPocketFormOpen(false); }}><section className="entry-sheet" role="dialog" aria-modal="true" aria-labelledby="pocket-title"><div className="grabber" /><div className="entry-heading"><div><p className="eyebrow">Organiza tu dinero</p><h2 id="pocket-title">Nuevo apartado</h2></div><button onClick={() => setPocketFormOpen(false)} aria-label="Cerrar">×</button></div><form onSubmit={savePocket}><label><span>Nombre del apartado *</span><input name="name" value={pocketName} onChange={(event) => setPocketName(event.target.value)} placeholder="Ej. Vacaciones" maxLength={45} /></label><div className="form-two"><label><span>Símbolo</span><input name="icon" value={pocketIcon} onChange={(event) => setPocketIcon(event.target.value)} maxLength={4} /></label><label><span>Color</span><select name="color" value={pocketTone} onChange={(event) => setPocketTone(event.target.value as Pocket["tone"])}><option value="violet">Morado</option><option value="rose">Rosa</option><option value="blue">Azul</option><option value="green">Verde</option></select></label></div><div className="required-note">▣ Comienza en $0. Cada ingreso o transferencia quedará anotado con su motivo.</div><button className="save-button" type="submit">Crear apartado</button></form></section></div>}
      {goalFormOpen && <div className="modal-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) { setGoalFormOpen(false); resetGoalForm(); } }}><section className="entry-sheet goal-sheet" role="dialog" aria-modal="true" aria-labelledby="goal-title"><div className="grabber" /><div className="entry-heading"><div><p className="eyebrow">Convierte un sueño en plan</p><h2 id="goal-title">{editingGoalId ? "Editar objetivo" : "Nuevo objetivo"}</h2></div><button onClick={() => { setGoalFormOpen(false); resetGoalForm(); }} aria-label="Cerrar">×</button></div><form onSubmit={saveGoal}>
        <label><span>¿Qué quieres lograr? *</span><input value={goalName} onChange={(event) => setGoalName(event.target.value)} placeholder="Ej. Comprar una laptop" maxLength={70} /></label>
        <label><span>¿Para qué lo quieres? *</span><textarea rows={3} value={goalPurpose} onChange={(event) => setGoalPurpose(event.target.value)} placeholder="Ej. Para trabajar y estudiar desde cualquier lugar" maxLength={240} /></label>
        <fieldset className="goal-term-choice"><legend>Tipo de objetivo *</legend><div>{goalTerms.map((term) => <button type="button" key={term.id} className={goalTerm === term.id ? "active" : ""} onClick={() => setGoalTerm(term.id)}><strong>{term.label}</strong><small>{term.hint}</small></button>)}</div></fieldset>
        <div className="form-two"><label><span>¿Cuánto cuesta? *</span><input inputMode="decimal" value={goalTarget} onChange={(event) => setGoalTarget(event.target.value.replace(/[^0-9.]/g, ""))} placeholder="$ 0.00" /></label><label><span>Fecha para lograrlo *</span><input type="date" value={goalTargetDate} onChange={(event) => setGoalTargetDate(event.target.value)} /></label></div>
        <fieldset className="goal-icon-choice"><legend>Elige un símbolo</legend><div>{goalIcons.map((icon) => <button type="button" key={icon} className={goalIcon === icon ? "active" : ""} onClick={() => setGoalIcon(icon)}>{icon}</button>)}</div></fieldset>
        <label><span>Color</span><select value={goalColor} onChange={(event) => setGoalColor(event.target.value as Pocket["tone"])}><option value="violet">Morado</option><option value="rose">Rosa</option><option value="blue">Azul</option><option value="green">Verde</option></select></label>
        <div className="required-note">◎ El objetivo inicia en $0.00. Después podrás aportar desde Disponible, Ahorro o cualquier apartado.</div>
        <button className="save-button" type="submit">{editingGoalId ? "Guardar cambios" : "Crear mi objetivo"}</button>
        {editingGoalId && <button className="danger-button" type="button" onClick={() => { const goal = goals.find((item) => item.id === editingGoalId); if (goal) void removeGoal(goal); }}>Eliminar objetivo</button>}
      </form></section></div>}
      {goalTransfer && <div className="modal-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) closeGoalTransfer(); }}><section className="entry-sheet goal-transfer-sheet" role="dialog" aria-modal="true" aria-labelledby="goal-transfer-title"><div className="grabber" /><div className="entry-heading"><div><p className="eyebrow">{goalTransfer.mode === "contribution" ? "Avanza hacia tu meta" : "Retirar de un objetivo"}</p><h2 id="goal-transfer-title">{goalTransfer.goal.name}</h2></div><button onClick={closeGoalTransfer} aria-label="Cerrar">×</button></div>
        {goalWithdrawalConfirm ? <div className="goal-withdraw-confirm"><span>◎</span><h3>Estás cada vez más cerca de lograrlo</h3><p>Has reunido <strong>{money.format(goalTransfer.goal.saved)}</strong> para “{goalTransfer.goal.name}”. Cada avance cuenta.</p><div><small>¿Aún quieres retirar?</small><strong>{money.format(Number(goalTransferAmount) || 0)}</strong></div><button type="button" onClick={() => setGoalWithdrawalConfirm(false)}>Seguir con mi objetivo</button><button className="confirm-withdraw" type="button" onClick={(event) => void submitGoalTransfer(event as unknown as FormEvent)}>Sí, retirar el dinero</button></div> : <form onSubmit={submitGoalTransfer}>
          <div className="goal-transfer-balance"><span>{goalTransfer.goal.icon}</span><div><small>Guardado hasta hoy</small><strong>{money.format(goalTransfer.goal.saved)}</strong></div><b>{Math.min(100, Math.round((goalTransfer.goal.saved / goalTransfer.goal.target) * 100))}%</b></div>
          <label className="amount-field"><span>{goalTransfer.mode === "contribution" ? "¿Cuánto quieres aportar? *" : "¿Cuánto quieres retirar? *"}</span><div><b>$</b><input inputMode="decimal" value={goalTransferAmount} onChange={(event) => setGoalTransferAmount(event.target.value.replace(/[^0-9.]/g, ""))} placeholder="0.00" aria-label="Cantidad para el objetivo" /></div></label>
          <label><span>{goalTransfer.mode === "contribution" ? "Sale de *" : "Regresa a *"}</span><select value={goalTransferPocketId} onChange={(event) => setGoalTransferPocketId(event.target.value)}>{pockets.map((pocket) => <option key={pocket.id} value={pocket.id}>{pocket.name} · {money.format(pocket.balance)}</option>)}</select></label>
          <label><span>Nota (opcional)</span><textarea rows={2} value={goalTransferNote} onChange={(event) => setGoalTransferNote(event.target.value)} placeholder={goalTransfer.mode === "contribution" ? "Ej. Aportación de esta quincena" : "Ej. Lo necesito para una urgencia"} maxLength={240} /></label>
          <div className="required-note">{goalTransfer.mode === "contribution" ? "✓ El dinero saldrá del apartado elegido y quedará reservado en este objetivo." : "◎ Antes de retirar te ayudaremos a pensarlo una vez más."}</div>
          <button className="save-button" type="submit">{goalTransfer.mode === "contribution" ? "Guardar aportación" : "Continuar con el retiro"}</button>
        </form>}
      </section></div>}
      {editingPocket && <div className="modal-backdrop" role="presentation"><section className="entry-sheet" role="dialog" aria-modal="true" aria-labelledby="edit-pocket-title"><div className="grabber" /><div className="entry-heading"><div><p className="eyebrow">Organiza tu dinero</p><h2 id="edit-pocket-title">Editar apartado</h2></div><button onClick={() => setEditingPocket(null)} aria-label="Cerrar edición">×</button></div><form onSubmit={savePocketChanges}><label><span>Nombre *</span><input value={editPocketName} onChange={(event) => setEditPocketName(event.target.value)} maxLength={45} /></label><label className="amount-field"><span>Saldo actual *</span><div><b>$</b><input inputMode="decimal" value={editPocketBalance} onChange={(event) => setEditPocketBalance(event.target.value.replace(/[^0-9.]/g, ""))} aria-label="Saldo actual del apartado" /></div><small className="field-help">Corrige aquí una cantidad inicial equivocada. No se registrará como ingreso ni gasto.</small></label><div className="form-two"><label><span>Símbolo</span><input value={editPocketIcon} onChange={(event) => setEditPocketIcon(event.target.value)} maxLength={4} /></label><label><span>Color</span><select value={editPocketTone} onChange={(event) => setEditPocketTone(event.target.value as Pocket["tone"])}><option value="violet">Morado</option><option value="rose">Rosa</option><option value="blue">Azul</option><option value="green">Verde</option></select></label></div><label><span>¿Cómo cuenta este apartado?</span><select value={editPocketRole} onChange={(event) => setEditPocketRole(event.target.value as LocalPocketRole)}><option value="available">Dinero disponible para gastar</option><option value="reserved">Dinero apartado o ahorro</option></select><small className="field-help">Solo un apartado puede representar tu dinero disponible.</small></label><button className="save-button" type="submit">Guardar cambios</button><button className="danger-button" type="button" onClick={removePocket}>Eliminar apartado</button></form></section></div>}
      {editingMovement && <div className="modal-backdrop" role="presentation"><section className="entry-sheet correction-sheet" role="dialog" aria-modal="true" aria-labelledby="correction-title"><div className="grabber" /><div className="entry-heading"><div><p className="eyebrow">Recalcular saldos</p><h2 id="correction-title">Editar movimiento</h2></div><button onClick={() => setEditingMovement(null)} aria-label="Cerrar edición">×</button></div><form onSubmit={saveCorrection}><div className="kind-switch">{(["ingreso", "gasto", "transferencia"] as MovementKind[]).map((item) => <button type="button" key={item} className={editKind === item ? "active" : ""} onClick={() => { setEditKind(item); setEditError(""); }}>{item[0].toUpperCase() + item.slice(1)}</button>)}</div><label className="amount-field"><span>Monto *</span><div><b>$</b><input inputMode="decimal" value={editAmount} onChange={(event) => setEditAmount(event.target.value.replace(/[^0-9.]/g, ""))} aria-label="Monto corregido" /></div></label><div className={editKind === "transferencia" ? "form-two" : ""}><label><span>{editKind === "transferencia" ? "Sale de *" : editKind === "ingreso" ? "¿Dónde se guardó? *" : "¿De qué apartado salió? *"}</span><select value={editSource} onChange={(event) => setEditSource(event.target.value)}>{pockets.map((pocket) => <option value={pocket.id} key={pocket.id}>{pocket.name} · {money.format(pocket.balance)}</option>)}</select></label>{editKind === "transferencia" && <label><span>Va para *</span><select value={editTarget} onChange={(event) => setEditTarget(event.target.value)}>{pockets.map((pocket) => <option value={pocket.id} key={pocket.id}>{pocket.name}</option>)}</select></label>}</div><label><span>¿Para qué fue? *</span><input value={editPurpose} onChange={(event) => setEditPurpose(event.target.value)} /></label><label><span>Nota</span><textarea rows={2} value={editNote} onChange={(event) => setEditNote(event.target.value)} /></label><label><span>Fecha y hora *</span><input type="datetime-local" value={editOccurredAt} max={localDateTimeValue()} onChange={(event) => setEditOccurredAt(event.target.value)} /></label><label><span>¿Por qué lo estás corrigiendo? *</span><textarea rows={2} value={editReason} onChange={(event) => setEditReason(event.target.value)} placeholder="Ej. Escribí una cantidad equivocada" /></label><div className="required-note">▣ Al guardar, la aplicación revierte el movimiento anterior y calcula nuevamente los saldos.</div>{editError && <p className="form-error">{editError}</p>}<button className="save-button" type="submit">Guardar y recalcular</button><button className="danger-button" type="button" onClick={removeMovement}>Eliminar movimiento</button></form></section></div>}
      {installEntryOpen && <InstallChoiceSheet onInstall={() => void installApplication()} onUseWeb={continueInBrowser} />}
      {installHelpOpen && <div className="modal-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) setInstallHelpOpen(false); }}><section className="entry-sheet install-sheet" role="dialog" aria-modal="true" aria-labelledby="install-title"><div className="grabber" /><div className="entry-heading"><div><p className="eyebrow">Instalación guiada</p><h2 id="install-title">Instala Mi Libreta</h2></div><button onClick={() => setInstallHelpOpen(false)} aria-label="Cerrar">×</button></div><div className="install-preview"><img src="/icon-192.png?v=18" alt="Icono de Mi Libreta Financiera" width={78} height={78} /><div><strong>Mi Libreta Financiera</strong><p>Se abrirá en pantalla completa desde el icono de tu teléfono.</p></div></div>{installPlatform === "embedded" ? <ol className="install-steps"><li><b>1</b><span>Abre el menú de este chat y elige <strong>Abrir en navegador</strong>.</span></li><li><b>2</b><span>Ábrela en <strong>Chrome</strong> (Android) o <strong>Safari</strong> (iPhone).</span></li><li><b>3</b><span>Vuelve a tocar Instalar y sigue el aviso del navegador.</span></li></ol> : installPlatform === "ios" ? <ol className="install-steps"><li><b>1</b><span>Abre esta página con <strong>Safari</strong>.</span></li><li><b>2</b><span>Toca <strong>Compartir</strong>.</span></li><li><b>3</b><span>Elige <strong>Agregar a pantalla de inicio</strong> y confirma.</span></li></ol> : installPlatform === "android" ? <ol className="install-steps"><li><b>1</b><span>Abre el menú <strong>⋮</strong> de <strong>Chrome</strong> o Edge.</span></li><li><b>2</b><span>Elige <strong>Instalar aplicación</strong> o <strong>Agregar a pantalla principal</strong>.</span></li><li><b>3</b><span>Confirma y abre el icono nuevo desde tu teléfono.</span></li></ol> : <ol className="install-steps"><li><b>1</b><span>Abre el menú de <strong>Chrome</strong> o Edge.</span></li><li><b>2</b><span>Elige <strong>Instalar Mi Libreta</strong>.</span></li><li><b>3</b><span>Ábrela desde el icono creado.</span></li></ol>}<div className="required-note">▣ Si no aparece la opción, usa Chrome o Safari directamente; los navegadores dentro de redes sociales no pueden instalarla. Haz un respaldo en Ajustes antes de cambiar de teléfono.</div><button className="save-button" onClick={() => setInstallHelpOpen(false)}>Entendido</button></section></div>}
      {feedbackOpen && <div className="modal-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) { setFeedbackOpen(false); setFeedbackContext("general"); } }}><section className="entry-sheet feedback-sheet" role="dialog" aria-modal="true" aria-labelledby="feedback-title"><div className="grabber" /><div className="entry-heading"><div><p className="eyebrow">Comentario anónimo</p><h2 id="feedback-title">{feedbackContext === "tutorial" ? "¿Qué te pareció el tutorial?" : "Ayúdanos a mejorar"}</h2></div><button onClick={() => { setFeedbackOpen(false); setFeedbackContext("general"); }} aria-label="Cerrar">×</button></div><div className="feedback-owner-note"><span>📩</span><p><strong>Tu opinión sí será leída</strong>{feedbackContext === "tutorial" ? "Cuéntanos si fue claro, qué faltó o qué botón debería explicarse mejor." : "La recibirá directamente el dueño y propietario de Mi Libreta Financiera para trabajar en mejoras de la aplicación."}</p></div><form onSubmit={submitFeedback}><fieldset className="rating-field"><legend>{feedbackContext === "tutorial" ? "¿Qué tan claro fue?" : "Facilidad de uso"}</legend><div>{[1,2,3,4,5].map((rating) => <button type="button" key={rating} className={feedbackRating === rating ? "selected" : ""} onClick={() => setFeedbackRating(rating)} aria-label={`${rating} de 5`}>★</button>)}</div><small>{feedbackRating ? `${feedbackRating} de 5` : "Toca una estrella"}</small></fieldset><label><span>{feedbackContext === "tutorial" ? "¿Qué fue útil, confuso o qué agregarías?" : "¿Qué fue confuso o qué agregarías?"}</span><textarea rows={5} maxLength={1200} value={feedbackMessage} onChange={(event) => setFeedbackMessage(event.target.value)} placeholder={feedbackContext === "tutorial" ? "Ej. Me gustaría un ejemplo para registrar mi primer gasto…" : "Ej. Me costó encontrar dónde registrar un pago…"} /></label><div className="required-note">No pedimos tu nombre ni correo. No incluyas cantidades, números de tarjeta ni información personal.</div><button className="save-button" type="submit" disabled={feedbackSaving}>{feedbackSaving ? "Enviando…" : "Enviar comentario anónimo"}</button>{feedbackContext !== "tutorial" && <button className="feedback-hide-button" type="button" onClick={() => changeFeedbackBubble(false)}>Ocultar la burbuja de comentarios</button>}</form></section></div>}
      {toast && <div className="toast" role="status" aria-live="polite">✓ {toast}</div>}
    </main>
  );
}

// Pantalla previa al primer uso. Distingue instalar (recomendado para llevar
// una libreta real) de probar en web sin prometer que un navegador sustituye un
// respaldo cuando se limpian sus datos o se cambia de teléfono.
function InstallChoiceSheet({ onInstall, onUseWeb }: { onInstall: () => void; onUseWeb: () => void }) {
  return <div className="modal-backdrop install-choice-backdrop" role="presentation"><section className="entry-sheet install-choice-sheet" role="dialog" aria-modal="true" aria-labelledby="install-choice-title"><div className="grabber" /><div className="install-choice-hero"><img src="/icon-192.png?v=18" alt="Icono de Mi Libreta Financiera" width={74} height={74} /><span>GRATIS</span></div><p className="eyebrow">Bienvenida a Mi Libreta Financiera</p><h2 id="install-choice-title">Tu dinero, sin complicarte</h2><p className="install-choice-intro">Es una libreta sencilla para registrar ingresos, gastos, apartados, pagos y metas. <strong>No necesitas ser contador</strong>: anota lo que pasa y la app te ayuda a entenderlo.</p><div className="install-choice-local"><span>▣</span><p><strong>Tus finanzas son tuyas</strong>Los movimientos se guardan localmente en este teléfono; no subimos tus montos, notas ni fotos a la beta.</p></div><button className="save-button install-choice-primary" type="button" onClick={onInstall}>Instalar gratis en mi teléfono</button><button className="install-choice-secondary" type="button" onClick={onUseWeb}>Usar en el navegador por ahora</button><p className="install-choice-warning">En web funciona para conocerla, pero los datos quedan en este navegador. Si usas incógnito, borras datos del navegador, cambias de navegador o teléfono, podrías perderlos. Para llevar tus finanzas, instala la app y crea respaldos en Ajustes.</p></section></div>;
}

// Componentes visuales pequeños: reciben datos ya calculados y nunca cambian
// saldos directamente. Así se conserva una sola lógica financiera.
function ProductCredit() {
  return <footer className="creator-signature" aria-label="Créditos de Mi Libreta Financiera">
    <strong>Mi Libreta Financiera · Corporativo Freelancers LAJ</strong>
    <span>Dirección creativa: Anahi Patiño</span>
    <span>Dirección de Marketing: Luis Rosas</span>
    <span>Desarrollador: Josue Villarruel</span>
    <small>Versión beta cerrada · © 2026 · Todos los derechos reservados</small>
  </footer>;
}

function MovementList({ movements, detailed = false, onEdit }: { movements: Movement[]; detailed?: boolean; onEdit?: (movement: Movement) => void }) {
  return <div className="movement-list">{movements.map((movement) => <article className="movement-row" key={movement.id}><span className={`movement-mark ${movement.kind}`}>{movement.kind === "ingreso" ? "↓" : movement.kind === "gasto" ? "↑" : "↔"}</span><div><strong>{movement.purpose}</strong><p>{movement.pocket}{detailed && movement.note ? ` · ${movement.note}` : ""}</p></div><aside><strong className={movement.kind}>{movement.kind === "ingreso" ? "+" : movement.kind === "gasto" ? "−" : ""}{money.format(movement.amount)}</strong><small>{movement.time}</small>{detailed && onEdit && <button className="movement-edit" onClick={() => onEdit(movement)}>Editar</button>}</aside></article>)}</div>;
}

function GoalCard({ goal, movementCount, onContribute, onWithdraw, onEdit }: { goal: Goal; movementCount: number; onContribute: (goal: Goal) => void; onWithdraw: (goal: Goal) => void; onEdit: (goal: Goal) => void }) {
  const progress = Math.min(100, Math.round((goal.saved / goal.target) * 100));
  const remaining = Math.max(0, goal.target - goal.saved);
  const targetDate = new Date(`${goal.targetDate}T12:00:00`);
  const monthsRemaining = Math.max(1, Math.ceil((targetDate.getTime() - appOpenedAt) / (30.44 * 86_400_000)));
  const monthlySuggestion = remaining / monthsRemaining;
  const termLabel: Record<LocalGoalTerm, string> = { corto: "Corto plazo", mediano: "Mediano plazo", largo: "Largo plazo" };
  const dateLabel = new Intl.DateTimeFormat("es-MX", { day: "numeric", month: "short", year: "numeric" }).format(targetDate).replaceAll(" de ", " ");
  return <article className={`goal-card ${goal.color} ${goal.status}`}>
    <div className="goal-card-heading"><span className="goal-card-icon">{goal.icon}</span><div><span className="goal-term-badge">{termLabel[goal.term]}</span><strong>{goal.name}</strong><p>{goal.purpose}</p></div><button type="button" onClick={() => onEdit(goal)}>✎ Editar</button></div>
    {goal.status === "completed" && <div className="goal-completed-note">★ ¡Objetivo cumplido! Lo que parecía lejano ya es tuyo.</div>}
    <div className="goal-progress-label"><span>Progreso</span><strong>{progress}%</strong></div><div className="goal-progress"><i style={{ width: `${progress}%` }} /></div>
    <div className="goal-money"><div><small>Has reunido</small><strong>{money.format(goal.saved)}</strong></div><div><small>Objetivo</small><strong>{money.format(goal.target)}</strong></div><div><small>Te falta</small><strong>{money.format(remaining)}</strong></div></div>
    <div className="goal-plan"><span>Fecha objetivo: <strong>{dateLabel}</strong></span>{remaining > 0 && <span>Sugerencia: <strong>{money.format(monthlySuggestion)} al mes</strong></span>}<small>{movementCount} {movementCount === 1 ? "movimiento" : "movimientos"} en esta meta</small></div>
    <div className="goal-actions"><button type="button" onClick={() => onContribute(goal)}>＋ Aportar</button><button type="button" disabled={goal.saved <= 0} onClick={() => onWithdraw(goal)}>Retirar</button></div>
  </article>;
}

function PaymentCard({ card, onEdit, onStatus, onDelete }: { card: StoredCard; onEdit: (card: StoredCard) => void; onStatus: (card: StoredCard) => void; onDelete: (card: StoredCard) => void }) {
  const category = paymentCategories.find((item) => item.id === card.category) ?? paymentCategories.at(-1)!;
  const due = card.dueDate ? new Date(`${card.dueDate}T12:00:00`) : null;
  const dueLabel = due ? new Intl.DateTimeFormat("es-MX", { day: "2-digit", month: "short", year: "numeric" }).format(due).replaceAll(" de ", " ") : "Sin fecha";
  const priorityLabel: Record<LocalPaymentPriority, string> = { relevante: "Relevante", poco_relevante: "Poco relevante", irrelevante: "Irrelevante" };
  const reminderLabel = card.reminderDays.length ? card.reminderDays.map((day) => `${day} ${day === 1 ? "día" : "días"}`).join(" · ") : "Sin avisos";
  return <article className={`agenda-payment category-${card.category} ${card.status === "paid" ? "paid" : ""}`}>
    <div className="payment-main"><span className="payment-category-icon">{category.icon}</span><div><span className="category-badge">{category.label}</span><strong>{card.alias}</strong><p>{card.provider || "Sin proveedor"}</p></div><button className="payment-edit" type="button" onClick={() => onEdit(card)}>✎ Editar</button></div>
    <div className="payment-details"><div><small>{card.status === "paid" ? "Cantidad registrada" : "Por pagar"}</small><strong>{money.format(card.amount)}</strong></div><div><small>{card.recurrence === "monthly" ? "Próximo pago" : "Fecha límite"}</small><strong>{dueLabel}</strong></div><span className={`priority-badge ${card.priority}`}>{card.status === "paid" ? "Pagado" : priorityLabel[card.priority]}</span></div>
    <p className="payment-frequency">{card.recurrence === "monthly" ? "↻ Se repite cada mes" : "• Pago único de este mes"}</p>
    <p className="payment-reminders">♢ Recordatorios: {reminderLabel}</p>
    <div className="payment-actions"><button type="button" onClick={() => onStatus(card)}>{card.status === "paid" ? "↶ Volver a pendiente" : card.recurrence === "monthly" ? "✓ Pagué este mes" : "✓ Marcar pagado"}</button><button className="delete-payment" type="button" onClick={() => onDelete(card)}>Eliminar</button></div>
  </article>;
}

function SettingsRow({ icon, title, value, onClick }: { icon: string; title: string; value: string; onClick?: () => void }) {
  return <button className="settings-row" onClick={onClick}><span>{icon}</span><div><strong>{title}</strong><p>{value}</p></div><i>›</i></button>;
}

function NavButton({ label, symbol, active, onClick }: { label: string; symbol: string; active: boolean; onClick: () => void }) {
  return <button className={active ? "active" : ""} onClick={onClick}><span>{symbol}</span><small>{label}</small></button>;
}

function Calculator({ expression, setExpression, onUse }: { expression: string; setExpression: (value: string) => void; onUse: () => void }) {
  const keys = ["7", "8", "9", "/", "4", "5", "6", "*", "1", "2", "3", "-", "0", ".", "C", "+"];
  return <div className="calculator"><div className="calculator-display">{expression || "0"}</div><div>{keys.map((key) => <button type="button" key={key} className={/[+\-*/]/.test(key) ? "operator" : ""} onClick={() => key === "C" ? setExpression("") : setExpression(expression + key)}>{key === "*" ? "×" : key === "/" ? "÷" : key}</button>)}</div><button type="button" className="calculator-use" onClick={onUse}>= Usar resultado</button></div>;
}
