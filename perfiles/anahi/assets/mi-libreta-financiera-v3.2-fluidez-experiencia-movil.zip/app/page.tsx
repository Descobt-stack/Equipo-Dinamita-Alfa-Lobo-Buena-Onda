import FinanceNotebook from "./finance-notebook";

export default function Home() {
  return <FinanceNotebook />;
}
