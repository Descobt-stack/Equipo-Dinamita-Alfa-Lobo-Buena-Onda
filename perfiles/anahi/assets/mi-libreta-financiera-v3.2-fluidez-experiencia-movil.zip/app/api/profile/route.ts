// Ruta de la primera capa remota de perfil. Está documentada para la futura
// migración de v2.0, pero la pantalla v14 mantiene su perfil por libreta local.
import { getRequestUser, unauthorized } from "@/lib/request-user";
import { getFinanceRuntimeEnv } from "@/lib/runtime-env";

const themes = new Set(["purple", "blue", "green", "rose", "orange"]);
const frequencies = new Set(["semanal", "quincenal", "mensual", "variable"]);

export async function PATCH(request: Request) {
  const user = await getRequestUser();
  if (!user) return unauthorized();
  const { DB } = getFinanceRuntimeEnv();
  const payload = await request.json() as { notebookTitle?: string; theme?: string; incomeFrequency?: string };
  const current = await DB.prepare("SELECT notebook_title, theme, income_frequency FROM profiles WHERE email = ?")
    .bind(user.email).first<{ notebook_title: string; theme: string; income_frequency: string }>();
  if (!current) return Response.json({ error: "Primero configura tu libreta." }, { status: 404 });
  const title = payload.notebookTitle?.trim().slice(0, 60) || current.notebook_title;
  const requestedTheme = payload.theme ?? "";
  const theme = themes.has(requestedTheme) || /^#[0-9a-fA-F]{6}$/.test(requestedTheme) ? requestedTheme : current.theme;
  const frequency = frequencies.has(payload.incomeFrequency ?? "") ? payload.incomeFrequency! : current.income_frequency;
  await DB.prepare(`UPDATE profiles SET notebook_title = ?, theme = ?, income_frequency = ?, updated_at = CURRENT_TIMESTAMP WHERE email = ?`)
    .bind(title, theme, frequency, user.email).run();
  return Response.json({ ok: true });
}
