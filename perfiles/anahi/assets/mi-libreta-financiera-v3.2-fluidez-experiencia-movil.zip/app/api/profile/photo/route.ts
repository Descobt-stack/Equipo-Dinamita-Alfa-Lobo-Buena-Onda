import { getRequestUser, unauthorized } from "@/lib/request-user";
import { getFinanceRuntimeEnv } from "@/lib/runtime-env";

const acceptedTypes = new Set(["image/jpeg", "image/png", "image/webp"]);

export async function GET() {
  const user = await getRequestUser();
  if (!user) return unauthorized();
  const { DB, BUCKET } = getFinanceRuntimeEnv();
  const profile = await DB.prepare("SELECT profile_photo_key FROM profiles WHERE email = ?")
    .bind(user.email).first<{ profile_photo_key: string | null }>();
  if (!profile?.profile_photo_key) return new Response(null, { status: 404 });
  const object = await BUCKET.get(profile.profile_photo_key);
  if (!object) return new Response(null, { status: 404 });
  const headers = new Headers();
  object.writeHttpMetadata(headers);
  headers.set("Cache-Control", "private, max-age=300");
  return new Response(object.body, { headers });
}

export async function POST(request: Request) {
  const user = await getRequestUser();
  if (!user) return unauthorized();
  const { DB, BUCKET } = getFinanceRuntimeEnv();
  const form = await request.formData();
  const photo = form.get("photo");
  if (!(photo instanceof File)) return Response.json({ error: "Selecciona una foto." }, { status: 400 });
  if (!acceptedTypes.has(photo.type)) return Response.json({ error: "Usa una imagen JPG, PNG o WebP." }, { status: 415 });
  if (photo.size > 5 * 1024 * 1024) return Response.json({ error: "La foto no debe superar 5 MB." }, { status: 413 });

  const previous = await DB.prepare("SELECT profile_photo_key FROM profiles WHERE email = ?")
    .bind(user.email).first<{ profile_photo_key: string | null }>();
  const extension = photo.type === "image/png" ? "png" : photo.type === "image/webp" ? "webp" : "jpg";
  const key = `profile-photos/${crypto.randomUUID()}.${extension}`;
  await BUCKET.put(key, await photo.arrayBuffer(), { httpMetadata: { contentType: photo.type } });
  await DB.prepare("UPDATE profiles SET profile_photo_key = ?, updated_at = CURRENT_TIMESTAMP WHERE email = ?")
    .bind(key, user.email).run();
  if (previous?.profile_photo_key && previous.profile_photo_key !== key) await BUCKET.delete(previous.profile_photo_key);
  return Response.json({ ok: true });
}
