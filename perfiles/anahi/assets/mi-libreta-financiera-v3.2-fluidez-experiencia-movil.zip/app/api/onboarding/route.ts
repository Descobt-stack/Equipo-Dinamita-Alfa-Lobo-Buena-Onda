// Configuración remota de la primera versión. Sus validaciones documentan cómo
// debe protegerse la futura migración, pero v14 inicia localmente por privacidad.
import { amountToCents, getRequestUser, unauthorized } from "@/lib/request-user";
import { getFinanceRuntimeEnv } from "@/lib/runtime-env";

type SetupPocket = { name?: string; balance?: number; color?: string; icon?: string; type?: string };
type HistoryItem = { kind?: string; amount?: number; purpose?: string; note?: string; occurredAt?: string; pocketIndex?: number };

const allowedFrequencies = new Set(["semanal", "quincenal", "mensual", "variable"]);
const allowedModes = new Set(["today", "history"]);
const allowedKinds = new Set(["ingreso", "gasto", "transferencia"]);

export async function POST(request: Request) {
  const user = await getRequestUser();
  if (!user) return unauthorized();
  const { DB } = getFinanceRuntimeEnv();

  const existing = await DB.prepare("SELECT onboarding_completed FROM profiles WHERE email = ?")
    .bind(user.email).first<{ onboarding_completed: number }>();
  if (existing?.onboarding_completed) {
    return Response.json({ error: "La libreta ya fue configurada." }, { status: 409 });
  }

  const payload = await request.json() as {
    notebookTitle?: string;
    incomeFrequency?: string;
    startMode?: string;
    startDate?: string;
    theme?: string;
    pockets?: SetupPocket[];
    history?: HistoryItem[];
  };

  const notebookTitle = payload.notebookTitle?.trim().slice(0, 60) || "Mi libreta personal";
  const incomeFrequency = allowedFrequencies.has(payload.incomeFrequency ?? "") ? payload.incomeFrequency! : "quincenal";
  const startMode = allowedModes.has(payload.startMode ?? "") ? payload.startMode! : "today";
  const startDate = /^\d{4}-\d{2}-\d{2}$/.test(payload.startDate ?? "") ? payload.startDate! : new Date().toISOString().slice(0, 10);
  const theme = (payload.theme ?? "purple").slice(0, 24);
  const setupPockets = Array.isArray(payload.pockets) ? payload.pockets.slice(0, 20) : [];
  if (!setupPockets.length) return Response.json({ error: "Agrega al menos un apartado." }, { status: 400 });

  const pocketRows = setupPockets.map((pocket, index) => ({
    id: crypto.randomUUID(),
    name: pocket.name?.trim().slice(0, 45) || `Apartado ${index + 1}`,
    balanceCents: Math.max(0, Math.round(Number(pocket.balance || 0) * 100)),
    color: (pocket.color ?? "violet").slice(0, 24),
    icon: (pocket.icon ?? "✦").slice(0, 4),
    type: (pocket.type ?? "custom").slice(0, 24),
  }));

  const statements = [
    DB.prepare(`INSERT INTO profiles (
      email, display_name, notebook_title, income_frequency, start_mode, start_date, theme, onboarding_completed, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, 1, CURRENT_TIMESTAMP)
    ON CONFLICT(email) DO UPDATE SET
      display_name = excluded.display_name,
      notebook_title = excluded.notebook_title,
      income_frequency = excluded.income_frequency,
      start_mode = excluded.start_mode,
      start_date = excluded.start_date,
      theme = excluded.theme,
      onboarding_completed = 1,
      updated_at = CURRENT_TIMESTAMP`)
      .bind(user.email, user.displayName, notebookTitle, incomeFrequency, startMode, startDate, theme),
  ];

  for (const pocket of pocketRows) {
    statements.push(DB.prepare(`INSERT INTO pockets (
      id, user_email, name, type, color, icon, balance_cents
    ) VALUES (?, ?, ?, ?, ?, ?, ?)`)
      .bind(pocket.id, user.email, pocket.name, pocket.type, pocket.color, pocket.icon, pocket.balanceCents));
  }

  if (startMode === "history" && Array.isArray(payload.history)) {
    for (const item of payload.history.slice(0, 500)) {
      const cents = amountToCents(item.amount);
      const purpose = item.purpose?.trim().slice(0, 120);
      const pocket = pocketRows[Math.max(0, Math.min(pocketRows.length - 1, Number(item.pocketIndex ?? 0)))];
      if (!cents || !purpose || !allowedKinds.has(item.kind ?? "")) continue;
      const occurredAt = !Number.isNaN(Date.parse(item.occurredAt ?? "")) ? new Date(item.occurredAt!).toISOString() : `${startDate}T12:00:00.000Z`;
      statements.push(DB.prepare(`INSERT INTO transactions (
        id, user_email, kind, amount_cents, source_pocket_id, target_pocket_id, purpose, note, occurred_at, source
      ) VALUES (?, ?, ?, ?, ?, NULL, ?, ?, ?, 'history_import')`)
        .bind(crypto.randomUUID(), user.email, item.kind, cents, pocket.id, purpose, item.note?.trim().slice(0, 500) ?? "", occurredAt));
    }
  }

  await DB.batch(statements);
  return Response.json({ ok: true, pocketCount: pocketRows.length }, { status: 201 });
}
