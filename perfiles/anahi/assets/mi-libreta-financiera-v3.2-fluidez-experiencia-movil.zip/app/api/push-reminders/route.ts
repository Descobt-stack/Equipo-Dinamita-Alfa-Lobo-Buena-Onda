// Agenda remota mínima de avisos: recibe IDs aleatorios y fechas, no el nombre
// ni el monto de los pagos que la persona guarda dentro de su libreta.
import { getFinanceRuntimeEnv } from "@/lib/runtime-env";

type ReminderInput = { id?: string; remindAt?: string };

export async function PUT(request: Request) {
  const payload = await request.json().catch(() => null) as null | { installId?: string; reminders?: ReminderInput[] };
  const installId = payload?.installId ?? "";
  if (!/^[0-9a-f-]{36}$/i.test(installId) || !Array.isArray(payload?.reminders) || payload.reminders.length > 60) {
    return Response.json({ error: "Agenda de recordatorios no válida." }, { status: 400 });
  }
  const reminders = payload.reminders.flatMap((item) => {
    const id = item.id?.trim() ?? "";
    const date = new Date(item.remindAt ?? "");
    if (!/^[0-9a-f-]{36}:\d{4}-\d{2}-\d{2}:(1|3|5)$/i.test(id) || Number.isNaN(date.getTime())) return [];
    const earliest = Date.now() - 7 * 86_400_000;
    const latest = Date.now() + 370 * 86_400_000;
    if (date.getTime() < earliest || date.getTime() > latest) return [];
    return [{ id, remindAt: date.toISOString() }];
  });
  const { DB } = getFinanceRuntimeEnv();
  const statements = [
    DB.prepare("DELETE FROM beta_payment_reminders WHERE install_id = ? AND status IN ('pending', 'sending')").bind(installId),
    ...reminders.map((item) => DB.prepare(`INSERT INTO beta_payment_reminders (
      id, install_id, remind_at, status, updated_at
    ) VALUES (?, ?, ?, 'pending', CURRENT_TIMESTAMP)
    ON CONFLICT(id) DO UPDATE SET
      install_id = excluded.install_id,
      remind_at = excluded.remind_at,
      status = CASE WHEN beta_payment_reminders.sent_at IS NULL THEN 'pending' ELSE beta_payment_reminders.status END,
      updated_at = CURRENT_TIMESTAMP`).bind(item.id, installId, item.remindAt)),
  ];
  await DB.batch(statements);
  return Response.json({ ok: true, scheduled: reminders.length });
}
