// Exportación JSON de la capa remota histórica. No reemplaza el respaldo local
// completo de v14 y no es todavía la exportación mensual PDF de la v2.0.
import { getRequestUser, unauthorized } from "@/lib/request-user";
import { getFinanceRuntimeEnv } from "@/lib/runtime-env";

export async function GET() {
  const user = await getRequestUser();
  if (!user) return unauthorized();
  const { DB } = getFinanceRuntimeEnv();
  const [profile, pocketRows, transactionRows, cardRows, reminderRows] = await Promise.all([
    DB.prepare("SELECT email, display_name, notebook_title, income_frequency, start_mode, start_date, theme, created_at, updated_at FROM profiles WHERE email = ?").bind(user.email).first(),
    DB.prepare("SELECT id, name, type, color, icon, balance_cents, archived, created_at FROM pockets WHERE user_email = ?").bind(user.email).all(),
    DB.prepare("SELECT id, kind, amount_cents, source_pocket_id, target_pocket_id, purpose, note, occurred_at, source, status, change_reason, created_at, updated_at FROM transactions WHERE user_email = ? ORDER BY occurred_at DESC").bind(user.email).all(),
    DB.prepare("SELECT id, alias, amount_due_cents, due_date, status, color, created_at, updated_at FROM cards WHERE user_email = ?").bind(user.email).all(),
    DB.prepare("SELECT id, card_id, title, due_at, remind_days_before, status, created_at FROM reminders WHERE user_email = ? ORDER BY due_at").bind(user.email).all(),
  ]);
  const body = JSON.stringify({ version: 1, exportedAt: new Date().toISOString(), profile, pockets: pocketRows.results, transactions: transactionRows.results, cards: cardRows.results, reminders: reminderRows.results }, null, 2);
  return new Response(body, { headers: { "Content-Type": "application/json; charset=utf-8", "Content-Disposition": `attachment; filename="respaldo-libreta-${new Date().toISOString().slice(0, 10)}.json"`, "Cache-Control": "no-store" } });
}
