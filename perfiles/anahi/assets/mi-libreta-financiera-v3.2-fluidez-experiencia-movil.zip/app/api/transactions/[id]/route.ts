import { getRequestUser, unauthorized } from "@/lib/request-user";
import { getFinanceRuntimeEnv } from "@/lib/runtime-env";

export async function PATCH(request: Request, context: { params: Promise<{ id: string }> }) {
  const user = await getRequestUser();
  if (!user) return unauthorized();
  const { DB } = getFinanceRuntimeEnv();
  const { id } = await context.params;
  const payload = await request.json() as { purpose?: string; note?: string; changeReason?: string };
  const changeReason = payload.changeReason?.trim().slice(0, 180) ?? "";
  const purpose = payload.purpose?.trim().slice(0, 120) ?? "";
  if (!changeReason) return Response.json({ error: "Explica por qué quieres modificar el registro." }, { status: 400 });
  if (!purpose) return Response.json({ error: "El motivo del movimiento no puede quedar vacío." }, { status: 400 });
  const result = await DB.prepare(`UPDATE transactions
    SET purpose = ?, note = ?, change_reason = ?, updated_at = CURRENT_TIMESTAMP
    WHERE id = ? AND user_email = ? AND status = 'active'`)
    .bind(purpose, payload.note?.trim().slice(0, 500) ?? "", changeReason, id, user.email).run();
  if (!result.meta.changes) return Response.json({ error: "No encontramos ese movimiento." }, { status: 404 });
  return Response.json({ ok: true });
}
