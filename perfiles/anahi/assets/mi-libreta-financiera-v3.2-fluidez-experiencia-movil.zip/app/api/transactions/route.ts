// Movimiento remoto histórico. Comprueba propiedad y saldo suficiente antes de
// aplicar cambios; el mismo principio se conserva en la versión local v14.
import { amountToCents, getRequestUser, unauthorized } from "@/lib/request-user";
import { getFinanceRuntimeEnv } from "@/lib/runtime-env";

const allowedKinds = new Set(["ingreso", "gasto", "transferencia"]);

export async function POST(request: Request) {
  const user = await getRequestUser();
  if (!user) return unauthorized();
  const { DB } = getFinanceRuntimeEnv();
  const payload = await request.json() as {
    kind?: string;
    amount?: number;
    sourcePocketId?: string;
    targetPocketId?: string;
    purpose?: string;
    note?: string;
    occurredAt?: string;
  };
  const kind = payload.kind ?? "";
  const amountCents = amountToCents(payload.amount);
  const purpose = payload.purpose?.trim().slice(0, 120) ?? "";
  if (!allowedKinds.has(kind) || !amountCents) return Response.json({ error: "Movimiento o cantidad no válidos." }, { status: 400 });
  if (!purpose) return Response.json({ error: "El motivo es obligatorio." }, { status: 400 });
  if (!payload.sourcePocketId) return Response.json({ error: "Selecciona un apartado." }, { status: 400 });
  if (kind === "transferencia" && (!payload.targetPocketId || payload.targetPocketId === payload.sourcePocketId)) {
    return Response.json({ error: "Selecciona un apartado de destino diferente." }, { status: 400 });
  }

  const source = await DB.prepare("SELECT id, balance_cents FROM pockets WHERE id = ? AND user_email = ? AND archived = 0")
    .bind(payload.sourcePocketId, user.email).first<{ id: string; balance_cents: number }>();
  if (!source) return Response.json({ error: "El apartado de origen no existe." }, { status: 404 });
  if ((kind === "gasto" || kind === "transferencia") && source.balance_cents < amountCents) {
    return Response.json({ error: "El apartado no tiene saldo suficiente." }, { status: 409 });
  }
  if (kind === "transferencia") {
    const target = await DB.prepare("SELECT id FROM pockets WHERE id = ? AND user_email = ? AND archived = 0")
      .bind(payload.targetPocketId, user.email).first();
    if (!target) return Response.json({ error: "El apartado de destino no existe." }, { status: 404 });
  }

  const id = crypto.randomUUID();
  const occurredAt = !Number.isNaN(Date.parse(payload.occurredAt ?? "")) ? new Date(payload.occurredAt!).toISOString() : new Date().toISOString();
  const statements = [];
  if (kind === "ingreso") statements.push(DB.prepare("UPDATE pockets SET balance_cents = balance_cents + ? WHERE id = ? AND user_email = ?").bind(amountCents, source.id, user.email));
  if (kind === "gasto") statements.push(DB.prepare("UPDATE pockets SET balance_cents = balance_cents - ? WHERE id = ? AND user_email = ?").bind(amountCents, source.id, user.email));
  if (kind === "transferencia") {
    statements.push(DB.prepare("UPDATE pockets SET balance_cents = balance_cents - ? WHERE id = ? AND user_email = ?").bind(amountCents, source.id, user.email));
    statements.push(DB.prepare("UPDATE pockets SET balance_cents = balance_cents + ? WHERE id = ? AND user_email = ?").bind(amountCents, payload.targetPocketId, user.email));
  }
  statements.push(DB.prepare(`INSERT INTO transactions (
    id, user_email, kind, amount_cents, source_pocket_id, target_pocket_id, purpose, note, occurred_at
  ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`)
    .bind(id, user.email, kind, amountCents, source.id, kind === "transferencia" ? payload.targetPocketId : null, purpose, payload.note?.trim().slice(0, 500) ?? "", occurredAt));
  await DB.batch(statements);
  return Response.json({ ok: true, id }, { status: 201 });
}
