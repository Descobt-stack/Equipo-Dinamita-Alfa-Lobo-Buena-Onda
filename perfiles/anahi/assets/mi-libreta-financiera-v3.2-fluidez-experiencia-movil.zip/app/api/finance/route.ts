// Lectura remota histórica: exige identidad del servidor y devuelve los datos
// de un solo correo. La v2.0 la sustituirá por una consulta por perfil y libreta.
import { desc, eq } from "drizzle-orm";
import { getDb } from "@/db";
import { cards, pockets, profiles, reminders, transactions } from "@/db/schema";
import { getRequestUser, unauthorized } from "@/lib/request-user";

export async function GET() {
  const user = await getRequestUser();
  if (!user) return unauthorized();
  const db = getDb();
  const profile = await db.select().from(profiles).where(eq(profiles.email, user.email)).get();
  if (!profile?.onboardingCompleted) {
    return Response.json({ setupRequired: true, user: { displayName: user.displayName } });
  }
  const [pocketRows, transactionRows, cardRows, reminderRows] = await Promise.all([
    db.select().from(pockets).where(eq(pockets.userEmail, user.email)),
    db.select().from(transactions).where(eq(transactions.userEmail, user.email)).orderBy(desc(transactions.occurredAt)).limit(500),
    db.select().from(cards).where(eq(cards.userEmail, user.email)),
    db.select().from(reminders).where(eq(reminders.userEmail, user.email)).orderBy(reminders.dueAt),
  ]);
  return Response.json({ setupRequired: false, profile, pockets: pocketRows, transactions: transactionRows, cards: cardRows, reminders: reminderRows });
}
