// Esta ruta comparte únicamente la llave pública VAPID necesaria para activar
// notificaciones; la llave privada permanece exclusivamente en el servidor.
import { getFinanceRuntimeEnv } from "@/lib/runtime-env";

export async function GET() {
  const env = getFinanceRuntimeEnv();
  if (!env.VAPID_SERVER_PUBLIC_KEY) {
    return Response.json({ error: "Recordatorios remotos no configurados." }, { status: 503 });
  }
  return Response.json({ publicKey: env.VAPID_SERVER_PUBLIC_KEY }, {
    headers: { "Cache-Control": "public, max-age=3600" },
  });
}
