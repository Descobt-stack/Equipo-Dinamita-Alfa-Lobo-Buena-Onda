// Registra la suscripción técnica de un navegador para avisos push. No equivale
// a crear una cuenta ni permite acceder a los movimientos financieros.
import { getFinanceRuntimeEnv } from "@/lib/runtime-env";
import { sendReminderPush } from "@/lib/web-push";

type SubscriptionPayload = {
  installId?: string;
  endpoint?: string;
  expirationTime?: number | null;
  keys?: { p256dh?: string; auth?: string };
  timezone?: string;
  sendTest?: boolean;
};

const installIdPattern = /^[0-9a-f-]{36}$/i;

export async function POST(request: Request) {
  const payload = await request.json().catch(() => null) as SubscriptionPayload | null;
  if (!payload || !installIdPattern.test(payload.installId ?? "") || !payload.endpoint?.startsWith("https://") ||
      !payload.keys?.p256dh || !payload.keys.auth) {
    return Response.json({ error: "Suscripción de notificación no válida." }, { status: 400 });
  }
  const { DB, ...runtime } = getFinanceRuntimeEnv();
  const endpoint = payload.endpoint.slice(0, 2000);
  const subscription = { endpoint, p256dh: payload.keys.p256dh.slice(0, 500), auth: payload.keys.auth.slice(0, 500) };
  await DB.prepare(`INSERT INTO beta_push_subscriptions (
      id, install_id, endpoint, p256dh, auth, timezone, active, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, 1, CURRENT_TIMESTAMP)
    ON CONFLICT(endpoint) DO UPDATE SET
      install_id = excluded.install_id,
      p256dh = excluded.p256dh,
      auth = excluded.auth,
      timezone = excluded.timezone,
      active = 1,
      updated_at = CURRENT_TIMESTAMP`)
    .bind(crypto.randomUUID(), payload.installId, endpoint, subscription.p256dh, subscription.auth,
      payload.timezone?.slice(0, 80) || "America/Mexico_City").run();

  let testSent: boolean | null = null;
  if (payload.sendTest) {
    try {
      testSent = (await sendReminderPush({ DB, ...runtime }, subscription, "test")).ok;
    } catch {
      testSent = false;
    }
  }
  return Response.json({ ok: true, testSent }, { status: 201 });
}

export async function DELETE(request: Request) {
  const payload = await request.json().catch(() => null) as { installId?: string; endpoint?: string } | null;
  if (!payload || !installIdPattern.test(payload.installId ?? "") || !payload.endpoint?.startsWith("https://")) {
    return Response.json({ error: "Solicitud no válida." }, { status: 400 });
  }
  const { DB } = getFinanceRuntimeEnv();
  await DB.prepare(`UPDATE beta_push_subscriptions SET active = 0, updated_at = CURRENT_TIMESTAMP
    WHERE install_id = ? AND endpoint = ?`).bind(payload.installId, payload.endpoint.slice(0, 2000)).run();
  return Response.json({ ok: true });
}
