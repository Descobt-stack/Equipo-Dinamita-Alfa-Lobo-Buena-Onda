// Alta de apartados para la primera capa remota. Valida límites y duplicados
// antes de guardar; v14 usa el equivalente local en lib/local-finance.ts.
import { getRequestUser, unauthorized } from "@/lib/request-user";
import { getFinanceRuntimeEnv } from "@/lib/runtime-env";

const allowedColors = new Set(["violet", "rose", "blue", "green"]);

export async function POST(request: Request) {
  const user = await getRequestUser();
  if (!user) return unauthorized();
  const { DB } = getFinanceRuntimeEnv();
  const payload = await request.json() as { name?: string; icon?: string; color?: string };
  const name = payload.name?.trim().slice(0, 45) ?? "";
  const icon = Array.from(payload.icon?.trim() || "✦").slice(0, 2).join("");
  const color = allowedColors.has(payload.color ?? "") ? payload.color! : "violet";
  if (!name) return Response.json({ error: "Escribe un nombre para el apartado." }, { status: 400 });

  const count = await DB.prepare("SELECT COUNT(*) AS total FROM pockets WHERE user_email = ? AND archived = 0")
    .bind(user.email).first<{ total: number }>();
  if ((count?.total ?? 0) >= 50) return Response.json({ error: "Llegaste al límite de 50 apartados." }, { status: 409 });

  const duplicate = await DB.prepare("SELECT id FROM pockets WHERE user_email = ? AND archived = 0 AND lower(name) = lower(?)")
    .bind(user.email, name).first();
  if (duplicate) return Response.json({ error: "Ya tienes un apartado con ese nombre." }, { status: 409 });

  const id = crypto.randomUUID();
  await DB.prepare(`INSERT INTO pockets (
    id, user_email, name, type, color, icon, balance_cents
  ) VALUES (?, ?, ?, 'custom', ?, ?, 0)`)
    .bind(id, user.email, name, color, icon).run();
  return Response.json({ ok: true, id }, { status: 201 });
}
