// Métricas opcionales y minimizadas para detectar uso y errores de la beta.
// allowedEvents es una lista blanca para impedir que se guarde contenido financiero.
import { getFinanceRuntimeEnv } from "@/lib/runtime-env";

const allowedEvents = new Set([
  "app_open",
  "install_prompt",
  "installed",
  "movement_saved",
  "card_saved",
  "backup_downloaded",
  "backup_restored",
  "notification_test",
  "push_subscribed",
  "reminder_schedule_sync",
  "feedback_sent",
  "client_error",
]);

function platformFromUserAgent(value: string) {
  if (/iphone|ipad|ipod/i.test(value)) return "ios";
  if (/android/i.test(value)) return "android";
  return "other";
}

export async function POST(request: Request) {
  const payload = await request.json().catch(() => null) as null | {
    installId?: string;
    eventName?: string;
    durationMs?: number;
    screen?: string;
  };
  if (!payload || !/^[0-9a-f-]{36}$/i.test(payload.installId ?? "") || !allowedEvents.has(payload.eventName ?? "")) {
    return Response.json({ error: "Evento no válido." }, { status: 400 });
  }
  const { DB } = getFinanceRuntimeEnv();
  const installId = payload.installId!;
  const userAgent = request.headers.get("user-agent") ?? "";
  const duration = Number.isFinite(payload.durationMs) ? Math.max(0, Math.min(120_000, Math.round(payload.durationMs!))) : null;
  const screen = payload.screen?.trim().slice(0, 30) || null;
  await DB.batch([
    DB.prepare(`INSERT INTO beta_installations (install_id, platform, app_version, last_seen_at)
      VALUES (?, ?, 'beta-1', CURRENT_TIMESTAMP)
      ON CONFLICT(install_id) DO UPDATE SET platform = excluded.platform, app_version = excluded.app_version, last_seen_at = CURRENT_TIMESTAMP`)
      .bind(installId, platformFromUserAgent(userAgent)),
    DB.prepare("INSERT INTO beta_events (id, install_id, event_name, duration_ms, screen) VALUES (?, ?, ?, ?, ?)")
      .bind(crypto.randomUUID(), installId, payload.eventName, duration, screen),
  ]);
  return Response.json({ ok: true }, { status: 201 });
}
