// Buzón anónimo de beta. Solo acepta una calificación, mensaje y pantalla;
// nunca recibe movimientos, saldos, cuentas, fotografía ni datos bancarios.
import { getFinanceRuntimeEnv } from "@/lib/runtime-env";

export async function POST(request: Request) {
  const payload = await request.json().catch(() => null) as null | {
    installId?: string;
    rating?: number;
    message?: string;
    screen?: string;
  };
  const installId = payload?.installId ?? "";
  const rating = Math.round(Number(payload?.rating ?? 0));
  const message = payload?.message?.trim() ?? "";
  if (!/^[0-9a-f-]{36}$/i.test(installId) || rating < 1 || rating > 5 || message.length > 1200) {
    return Response.json({ error: "Comentario no válido." }, { status: 400 });
  }
  const { DB } = getFinanceRuntimeEnv();
  await DB.prepare("INSERT INTO beta_feedback (id, install_id, rating, message, screen) VALUES (?, ?, ?, ?, ?)")
    .bind(crypto.randomUUID(), installId, rating, message, payload?.screen?.trim().slice(0, 30) || "general").run();
  return Response.json({ ok: true }, { status: 201 });
}
