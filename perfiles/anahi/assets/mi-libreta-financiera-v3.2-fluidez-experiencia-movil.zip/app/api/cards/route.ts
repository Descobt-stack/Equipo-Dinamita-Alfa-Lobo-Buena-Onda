// Agenda remota preliminar. Solo acepta alias y fecha; nunca números de tarjeta,
// CVV o NIP. Será ampliada cuando la v2.0 tenga cuentas verificadas.
import { amountToCents, getRequestUser, unauthorized } from "@/lib/request-user";
import { getFinanceRuntimeEnv } from "@/lib/runtime-env";

export async function POST(request: Request) {
  const user = await getRequestUser();
  if (!user) return unauthorized();
  const { DB } = getFinanceRuntimeEnv();
  const payload = await request.json() as { alias?: string; amountDue?: number; dueDate?: string; color?: string; remindDaysBefore?: number };
  const alias = payload.alias?.trim().slice(0, 45) ?? "";
  if (!alias) return Response.json({ error: "Escribe un nombre para identificar la tarjeta." }, { status: 400 });
  const amountDueCents = payload.amountDue ? amountToCents(payload.amountDue) : 0;
  if (payload.amountDue && !amountDueCents) return Response.json({ error: "Cantidad no válida." }, { status: 400 });
  const dueDate = /^\d{4}-\d{2}-\d{2}$/.test(payload.dueDate ?? "") ? payload.dueDate! : null;
  const id = crypto.randomUUID();
  const statements = [DB.prepare(`INSERT INTO cards (
    id, user_email, alias, amount_due_cents, due_date, status, color
  ) VALUES (?, ?, ?, ?, ?, 'current', ?)`)
    .bind(id, user.email, alias, amountDueCents ?? 0, dueDate, (payload.color ?? "purple").slice(0, 24))];
  if (dueDate) {
    statements.push(DB.prepare(`INSERT INTO reminders (
      id, user_email, card_id, title, due_at, remind_days_before
    ) VALUES (?, ?, ?, ?, ?, ?)`)
      .bind(crypto.randomUUID(), user.email, id, `Pago de ${alias}`, `${dueDate}T09:00:00.000`, Math.max(0, Math.min(30, Number(payload.remindDaysBefore ?? 3)))));
  }
  await DB.batch(statements);
  return Response.json({ ok: true, id }, { status: 201 });
}
