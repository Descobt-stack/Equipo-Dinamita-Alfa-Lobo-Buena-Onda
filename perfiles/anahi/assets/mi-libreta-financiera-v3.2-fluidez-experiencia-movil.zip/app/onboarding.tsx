"use client";

// Tutorial de primer uso v2.0. Explica la libreta en lenguaje simple y permite
// elegir una o varias libretas sin crear una cuenta ni compartir datos todavía.

import { ChangeEvent, FormEvent, useMemo, useState } from "react";
import { requestPersistentStorage, setupLocalNotebook } from "@/lib/local-finance";

type StartMode = "today" | "history";
type UsagePlan = "personal" | "multiple";
type SetupPocket = { name: string; balance: string; color: string; icon: string };
type HistoryRow = { kind: "ingreso" | "gasto"; amount: string; purpose: string; note: string; occurredAt: string; pocketIndex: number };

const today = new Date().toISOString().slice(0, 10);
const defaultPockets: SetupPocket[] = [
  { name: "Dinero disponible", balance: "0", color: "rose", icon: "☀" },
  { name: "Ahorro", balance: "0", color: "violet", icon: "⌂" },
  { name: "Emergencias", balance: "0", color: "blue", icon: "✦" },
];

const guideItems = [
  ["⌂", "Inicio", "Consulta Disponible, Apartados y Total sin confundirlos."],
  ["＋", "Apuntes", "Registra ingresos, gastos o transferencias con su motivo."],
  ["▤", "Pagos", "Organiza fechas de pago y activa recordatorios."],
  ["◎", "Objetivos", "Reserva dinero para una meta y mira tu avance."],
  ["▥", "Reportes", "Revisa el cierre del mes y guarda un respaldo."],
  ["⚙", "Ajustes", "Personaliza, crea libretas y vuelve a esta guía."],
] as const;

export default function Onboarding({ displayName, onComplete }: { displayName?: string; onComplete: () => Promise<void> }) {
  const [step, setStep] = useState(1);
  const [usagePlan, setUsagePlan] = useState<UsagePlan>("personal");
  const [mode, setMode] = useState<StartMode>("today");
  const [notebookNames, setNotebookNames] = useState(["Personal"]);
  const [frequency, setFrequency] = useState("quincenal");
  const [startDate, setStartDate] = useState(today);
  const [theme, setTheme] = useState("purple");
  const [pockets, setPockets] = useState(defaultPockets);
  const [history, setHistory] = useState<HistoryRow[]>([]);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  const totalOpening = useMemo(() => pockets.reduce((sum, pocket) => sum + Math.max(0, Number(pocket.balance || 0)), 0), [pockets]);
  const stepTitles = ["Conoce tu libreta", "¿Cómo la usarás?", "Nombra tus libretas", "Acomoda tu dinero", "Últimos detalles"];

  function updatePocket(index: number, field: keyof SetupPocket, value: string) {
    setPockets((current) => current.map((pocket, pocketIndex) => pocketIndex === index ? { ...pocket, [field]: value } : pocket));
  }

  function addPocket() {
    if (pockets.length >= 10) return;
    setPockets((current) => [...current, { name: `Apartado ${current.length + 1}`, balance: "0", color: "green", icon: "✦" }]);
  }

  function chooseUsagePlan(plan: UsagePlan) {
    setUsagePlan(plan);
    if (plan === "personal") setNotebookNames((current) => [current[0] || "Personal"]);
    if (plan === "multiple") setNotebookNames((current) => current.length > 1 ? current : [current[0] || "Personal", "Casa"]);
  }

  function updateNotebookName(index: number, value: string) {
    setNotebookNames((current) => current.map((name, itemIndex) => itemIndex === index ? value : name));
  }

  function addNotebookName() {
    if (notebookNames.length >= 5) return;
    setNotebookNames((current) => [...current, `Libreta ${current.length + 1}`]);
  }

  function addHistoryRow() {
    setHistory((current) => [...current, { kind: "gasto", amount: "", purpose: "", note: "", occurredAt: `${startDate}T12:00`, pocketIndex: 0 }]);
  }

  function updateHistory(index: number, field: keyof HistoryRow, value: string | number) {
    setHistory((current) => current.map((row, rowIndex) => rowIndex === index ? { ...row, [field]: value } : row));
  }

  function importCsv(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      const text = String(reader.result ?? "");
      const lines = text.split(/\r?\n/).filter(Boolean).slice(1, 501);
      const rows = lines.map((line) => {
        const [date = startDate, kind = "gasto", amount = "", purpose = "", note = "", pocket = "0"] = line.split(",").map((part) => part.trim().replace(/^"|"$/g, ""));
        return { kind: kind.toLowerCase() === "ingreso" ? "ingreso" as const : "gasto" as const, amount, purpose, note, occurredAt: `${date}T12:00`, pocketIndex: Math.max(0, Math.min(pockets.length - 1, Number(pocket) || 0)) };
      }).filter((row) => Number(row.amount) > 0 && row.purpose);
      setHistory((current) => [...current, ...rows]);
      setError(rows.length ? "" : "No encontramos filas válidas. Revisa el formato del archivo.");
    };
    reader.readAsText(file);
    event.target.value = "";
  }

  function goNext() {
    if (step === 3) {
      const names = notebookNames.map((name) => name.trim()).filter(Boolean);
      if (!names.length) return setError("Ponle un nombre a tu primera libreta.");
      if (new Set(names.map((name) => name.toLocaleLowerCase("es-MX"))).size !== names.length) return setError("Cada libreta necesita un nombre distinto.");
    }
    setError("");
    setStep((current) => Math.min(5, current + 1));
  }

  async function finish(event: FormEvent) {
    event.preventDefault();
    const names = Array.from(new Set(notebookNames.map((name) => name.trim()).filter(Boolean))).slice(0, 5);
    if (!names.length) return setError("Ponle un nombre a tu primera libreta.");
    if (!pockets.some((pocket) => pocket.name.trim())) return setError("Agrega al menos un apartado.");
    setSaving(true);
    setError("");
    try {
      await setupLocalNotebook({
        notebookTitle: names[0],
        additionalNotebookNames: usagePlan === "multiple" ? names.slice(1) : [],
        incomeFrequency: frequency,
        startMode: mode,
        startDate,
        theme,
        pockets: pockets.filter((pocket) => pocket.name.trim()).map((pocket) => ({ ...pocket, balance: Number(pocket.balance || 0) })),
        history: mode === "history" ? history.filter((row) => Number(row.amount) > 0 && row.purpose.trim()).map((row) => ({ ...row, amount: Number(row.amount), occurredAt: new Date(row.occurredAt).toISOString() })) : [],
      });
      await requestPersistentStorage().catch(() => false);
      await onComplete();
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "No pudimos guardar la configuración.");
    } finally {
      setSaving(false);
    }
  }

  return (
    <main className={`onboarding-page theme-${theme}`}>
      <div className="onboarding-notebook">
        <div className="onboarding-progress"><i style={{ width: `${step * 20}%` }} /></div>
        <header><p className="eyebrow">Tu nueva libreta</p><h1>{stepTitles[step - 1]}</h1><span>Paso {step} de 5</span></header>
        <form onSubmit={finish}>
          {step === 1 && <section className="onboarding-step">
            <div className="welcome-sketch">$ <span>✓</span></div>
            <h2>Hola{displayName ? `, ${displayName.split(" ")[0]}` : ""}</h2>
            <p>No necesitas saber de finanzas: anota, entiende y decide con calma.</p>
            <div className="onboarding-guide" aria-label="Funciones de Mi Libreta Financiera">{guideItems.map(([icon, title, description]) => <article key={title}><span>{icon}</span><div><strong>{title}</strong><p>{description}</p></div></article>)}</div>
            <p className="guide-reminder">Esta guía seguirá disponible desde Ajustes cuando la necesites.</p>
          </section>}

          {step === 2 && <section className="onboarding-step">
            <h2>¿Cómo quieres organizarte?</h2>
            <p>Esto no crea perfiles ni cuentas. Solo prepara tus libretas en este teléfono.</p>
            <button type="button" className={`mode-choice ${usagePlan === "personal" ? "selected" : ""}`} onClick={() => chooseUsagePlan("personal")}><span>YO</span><div><strong>Solo uso personal</strong><p>Una libreta para tu dinero, apartados, pagos y metas.</p></div><i>✓</i></button>
            <button type="button" className={`mode-choice ${usagePlan === "multiple" ? "selected" : ""}`} onClick={() => chooseUsagePlan("multiple")}><span>▤</span><div><strong>Quiero varias libretas</strong><p>Por ejemplo: Personal, Amor, Casa o Negocio. Sus datos no se mezclan.</p></div><i>✓</i></button>
            <div className="setup-privacy">↗ <strong>¿Compartir con otra persona?</strong> Llegará con perfiles y acceso privado en una fase posterior. Por ahora las libretas siguen siendo locales y separadas.</div>
          </section>}

          {step === 3 && <section className="onboarding-step">
            <h2>Hazlas tuyas</h2>
            <p>La primera se configurará ahora. Las demás empezarán en $0.00 y podrás editarlas después.</p>
            <div className="setup-notebooks">{notebookNames.map((name, index) => <div className="setup-notebook" key={index}><span>{index === 0 ? "★" : "▤"}</span><label><small>{index === 0 ? "Libreta principal" : `Libreta ${index + 1}`}</small><input value={name} onChange={(event) => updateNotebookName(index, event.target.value)} maxLength={60} aria-label={`Nombre de la libreta ${index + 1}`} /></label>{notebookNames.length > 1 && <button type="button" onClick={() => setNotebookNames((current) => current.filter((_, itemIndex) => itemIndex !== index))} aria-label={`Quitar libreta ${name || index + 1}`}>×</button>}</div>)}</div>
            {usagePlan === "multiple" && <><div className="notebook-suggestions"><span>Ideas rápidas:</span>{["Personal", "Amor", "Casa", "Negocio"].map((name) => <button type="button" key={name} onClick={() => { if (notebookNames.some((item) => item.toLocaleLowerCase("es-MX") === name.toLocaleLowerCase("es-MX"))) return; if (notebookNames.length < 5) setNotebookNames((current) => [...current, name]); }}>{name}</button>)}</div><button type="button" className="add-setup-row" onClick={addNotebookName}>＋ Agregar otra libreta</button></>}
          </section>}

          {step === 4 && <section className="onboarding-step">
            <h2>¿Cuánto tienes ahora?</h2><p>Escribe el saldo actual de los apartados de <strong>{notebookNames[0] || "tu libreta principal"}</strong>. No se registra como ingreso nuevo.</p>
            <div className="opening-total"><small>Saldo inicial de esta libreta</small><strong>{new Intl.NumberFormat("es-MX", { style: "currency", currency: "MXN" }).format(totalOpening)}</strong></div>
            <div className="setup-pockets">{pockets.map((pocket, index) => <div className="setup-pocket" key={index}><input className="pocket-name" value={pocket.name} onChange={(event) => updatePocket(index, "name", event.target.value)} aria-label={`Nombre del apartado ${index + 1}`} /><label><span>$</span><input inputMode="decimal" value={pocket.balance} onChange={(event) => updatePocket(index, "balance", event.target.value.replace(/[^0-9.]/g, ""))} aria-label={`Saldo de ${pocket.name}`} /></label>{pockets.length > 1 && <button type="button" onClick={() => setPockets((current) => current.filter((_, pocketIndex) => pocketIndex !== index))} aria-label={`Quitar ${pocket.name}`}>×</button>}</div>)}</div>
            <button type="button" className="add-setup-row" onClick={addPocket}>＋ Agregar otro apartado</button>
          </section>}

          {step === 5 && <section className="onboarding-step">
            <h2>¿Desde dónde comenzamos?</h2>
            <button type="button" className={`mode-choice ${mode === "today" ? "selected" : ""}`} onClick={() => setMode("today")}><span>HOY</span><div><strong>Empezar desde hoy</strong><p>Comienza con los saldos actuales y anota lo nuevo desde ahora.</p></div><i>✓</i></button>
            <button type="button" className={`mode-choice ${mode === "history" ? "selected" : ""}`} onClick={() => setMode("history")}><span>↶</span><div><strong>Pasar apuntes anteriores</strong><p>Registra gastos e ingresos de tu cuaderno con sus fechas originales.</p></div><i>✓</i></button>
            <div className="onboarding-two"><label><span>Recibo dinero</span><select value={frequency} onChange={(event) => setFrequency(event.target.value)}><option value="semanal">Semanalmente</option><option value="quincenal">Quincenalmente</option><option value="mensual">Mensualmente</option><option value="variable">Sin fecha fija</option></select></label><label><span>Fecha de inicio</span><input type="date" value={startDate} onChange={(event) => setStartDate(event.target.value)} /></label></div>
            <fieldset className="theme-field"><legend>Color de mi libreta</legend><div>{["purple","blue","green","rose","orange"].map((color) => <button type="button" key={color} className={`${color} ${theme === color ? "selected" : ""}`} onClick={() => setTheme(color)} aria-label={`Tema ${color}`} />)}</div></fieldset>
            {mode === "history" && <div className="history-import"><div className="history-heading"><div><strong>Apuntes anteriores</strong><p>Puedes agregarlos ahora o continuar después.</p></div><label className="csv-button">Importar CSV<input type="file" accept=".csv,text/csv" onChange={importCsv} /></label></div>
              <div className="history-rows">{history.map((row, index) => <div className="history-row" key={index}><select value={row.kind} onChange={(event) => updateHistory(index, "kind", event.target.value)}><option value="gasto">Gasto</option><option value="ingreso">Ingreso</option></select><input inputMode="decimal" placeholder="$ Monto" value={row.amount} onChange={(event) => updateHistory(index, "amount", event.target.value.replace(/[^0-9.]/g, ""))} /><input placeholder="¿Para qué fue?" value={row.purpose} onChange={(event) => updateHistory(index, "purpose", event.target.value)} /><input type="datetime-local" value={row.occurredAt} onChange={(event) => updateHistory(index, "occurredAt", event.target.value)} /><select value={row.pocketIndex} onChange={(event) => updateHistory(index, "pocketIndex", Number(event.target.value))}>{pockets.map((pocket, pocketIndex) => <option key={pocketIndex} value={pocketIndex}>{pocket.name}</option>)}</select><button type="button" onClick={() => setHistory((current) => current.filter((_, rowIndex) => rowIndex !== index))}>×</button></div>)}</div>
              <button type="button" className="add-setup-row" onClick={addHistoryRow}>＋ Agregar apunte anterior</button>
              <p className="csv-hint">CSV: fecha, tipo, cantidad, motivo, nota, número de apartado.</p>
            </div>}
            <div className="setup-privacy">▣ Tus saldos, movimientos, notas y fotografías se guardan únicamente en este teléfono.</div>
          </section>}

          {error && <p className="form-error">{error}</p>}
          <footer>{step > 1 && <button type="button" className="back-setup" onClick={() => { setError(""); setStep((current) => current - 1); }}>Atrás</button>}{step < 5 ? <button type="button" className="next-setup" onClick={goNext}>{step === 1 ? "Configurar mi libreta" : "Continuar"}</button> : <button type="submit" className="next-setup" disabled={saving}>{saving ? "Preparando…" : usagePlan === "multiple" ? "Crear mis libretas" : "Crear mi libreta"}</button>}</footer>
        </form>
      </div>
    </main>
  );
}
