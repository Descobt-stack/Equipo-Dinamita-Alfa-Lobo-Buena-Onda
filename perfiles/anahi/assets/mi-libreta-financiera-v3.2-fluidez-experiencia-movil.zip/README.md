# Mi Libreta Financiera

Beta móvil, local-first y personalizable para registrar ingresos, gastos,
transferencias, apartados de ahorro, tarjetas identificadas solo por apodo,
recordatorios de pago y reportes diarios/mensuales.

## Lo más importante

- Los saldos, movimientos, notas, nombres de tarjetas y fotografías se guardan
  en IndexedDB **únicamente en el teléfono**.
- El servidor no recibe números de tarjeta, CVV, NIP, cuentas bancarias, montos,
  saldos, notas, fotografías ni apodos de tarjetas.
- Para avisar con la aplicación cerrada, el servidor conserva solo un id
  aleatorio de instalación, la suscripción cifrada del navegador y la fecha del
  aviso genérico.
- Las métricas de la beta son opcionales y están desactivadas de forma
  predeterminada. Los comentarios enviados tampoco incluyen datos financieros.
- El respaldo es un archivo JSON que cada persona puede guardar voluntariamente
  en OneDrive, Google Drive o iCloud.

## Funciones incluidas

- Alta desde hoy o captura de apuntes anteriores.
- Frecuencia de ingreso semanal, quincenal, mensual o variable.
- Apartados personalizables con nombre, icono y color.
- Ingresos, gastos y transferencias con propósito obligatorio.
- Correcciones con motivo obligatorio y registro del cambio.
- Calculadora dentro del formulario de movimientos.
- Resumen del día y cierre del mes: ingresos, egresos y diferencia.
- Tarjetas registradas solo por apodo, cantidad por pagar y fecha límite.
- Semáforo de pagos: verde, amarillo y rojo.
- Instalación PWA en Android y iPhone.
- Web Push con aviso genérico y sin detalles financieros.
- Foto personal y tema de color, guardados localmente.
- Exportación e importación de respaldo local.
- Métricas anónimas opcionales y formulario de comentarios para la beta.

## Tecnología y por qué se eligió

| Parte | Tecnología | Motivo |
| --- | --- | --- |
| Interfaz | React 19 + TypeScript | Componentes rápidos, tipados y fáciles de mantener. |
| Aplicación web | Next/Vinext + Vite | Genera una PWA instalable y un Worker para Cloudflare. |
| Finanzas | IndexedDB | Cada usuario conserva su libreta en su propio teléfono. |
| Datos mínimos de beta | Cloudflare D1 + Drizzle | Guarda métricas, comentarios y agenda genérica de avisos. |
| Recordatorios | Service Worker + Web Push/VAPID | Puede recibir avisos con la PWA cerrada. |
| Archivos | R2 disponible | Reservado para futuras funciones; las fotos personales actuales no se suben. |
| Alojamiento | Sites sobre Cloudflare | HTTPS, despliegue reproducible y recursos de beta de bajo costo. |

## Requisitos para trabajar en una PC

- Node.js 22.13 o posterior.
- npm.
- Linux, WSL 2 o una terminal compatible con `bash`, `flock`, `curl` y GNU
  `timeout` para usar los scripts incluidos tal como están.

En Windows, la ruta más sencilla es instalar WSL 2 con Ubuntu y abrir el
proyecto desde esa terminal.

## Instalación local

```bash
npm ci
npm run dev
```

La terminal mostrará la dirección local. Ábrela en el navegador de la PC. Los
datos de esa prueba se guardarán solo en ese navegador.

## Compilar y comprobar

```bash
npm run lint
npm test
```

`npm test` compila la aplicación, valida que el Worker generado sea desplegable
y ejecuta la prueba automatizada incluida.

Otros comandos útiles:

```bash
npm run build
npm run validate:artifact
npm run db:generate
```

Después de cambiar `db/schema.ts`, ejecuta `npm run db:generate` y revisa el
nuevo archivo SQL dentro de `drizzle/` antes de publicar.

## Variables de entorno

Copia `.env.example` como `.env` solo para desarrollo local. Nunca subas una
clave privada real al repositorio.

- `VAPID_SERVER_PUBLIC_KEY`: clave pública que recibe el navegador.
- `VAPID_SERVER_PRIVATE_KEY`: clave privada; debe almacenarse como secreto.
- `VAPID_SUBJECT`: URL o correo de contacto del responsable del Web Push.
- `REMINDER_CRON_SECRET`: protege la tarea que procesa recordatorios.

En producción estas variables están guardadas en el almacenamiento seguro del
proveedor, fuera del código.

## Recordatorios con la aplicación cerrada

El flujo es:

1. La persona instala la PWA y acepta notificaciones.
2. El teléfono crea una suscripción Web Push cifrada.
3. La aplicación sube solo la suscripción, un id aleatorio y la hora del aviso.
4. El Worker procesa avisos vencidos y envía un texto genérico.
5. El Service Worker muestra la notificación y abre la sección de pagos.

En iPhone/iPad, Web Push requiere agregar primero la aplicación a la pantalla de
inicio. En Android puede instalarse desde el aviso del navegador.

El Worker ya incluye un manejador `scheduled()` y un endpoint protegido para un
Cron externo. Para una entrega estrictamente programada, el entorno de
producción debe asociar un Cron Trigger a ese manejador; mientras tanto también
se hace una revisión oportunista cuando algún usuario abre la beta.

## Estructura principal

```text
app/                 Pantallas y rutas de la API
db/schema.ts         Esquema D1
drizzle/             Migraciones SQL
lib/local-finance.ts Libreta local en IndexedDB
lib/web-push.ts      Cifrado y envío Web Push
public/sw.js         Modo offline y recepción de avisos
worker/index.ts      Worker HTTP y tarea de recordatorios
tests/               Pruebas automatizadas
```

## Seguridad de la beta

- No se solicitan contactos, ubicación, micrófono, cámara continua ni acceso
  bancario.
- La foto se selecciona manualmente y se guarda localmente.
- Los endpoints validan ids, longitudes, fechas y formatos antes de guardar.
- Las notificaciones no muestran cantidad, tarjeta ni propósito del pago.
- Las suscripciones vencidas se desactivan al recibir `404` o `410` del servicio
  Push.
- La beta debe compartirse solo con las personas autorizadas mientras se valida.

## Sitio actual

La versión publicada está en:

https://libreta-financiera.josuepmvf.chatgpt.site
