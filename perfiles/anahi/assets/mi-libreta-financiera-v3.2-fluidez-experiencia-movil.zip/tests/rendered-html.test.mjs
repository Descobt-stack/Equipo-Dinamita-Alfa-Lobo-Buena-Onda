// Pruebas de regresión: verifican que al compilar no desaparezcan los controles
// esenciales entregados en cada fase aunque se reorganice la interfaz.
import assert from "node:assert/strict";
import test from "node:test";
import { readFile } from "node:fs/promises";

const developmentPreviewMeta =
  /<meta(?=[^>]*\bname=["']codex-preview["'])(?=[^>]*\bcontent=["']development["'])[^>]*>/i;

test("renders development preview metadata", async () => {
  const workerUrl = new URL("../dist/server/index.js", import.meta.url);
  workerUrl.searchParams.set("test", `${process.pid}-${Date.now()}`);
  const { default: worker } = await import(workerUrl.href);

  const response = await worker.fetch(
    new Request("http://localhost/", {
      headers: { accept: "text/html" },
    }),
    {
      ASSETS: {
        fetch: async () => new Response("Not found", { status: 404 }),
      },
    },
    {
      waitUntil() {},
      passThroughOnException() {},
    },
  );

  assert.equal(response.status, 200);
  assert.match(
    response.headers.get("content-type") ?? "",
    /^text\/html\b/i,
  );
  assert.match(await response.text(), developmentPreviewMeta);
});

test("includes the phase 2 clarity and feedback controls", async () => {
  const component = await readFile(new URL("../app/finance-notebook.tsx", import.meta.url), "utf8");
  const styles = await readFile(new URL("../app/globals.css", import.meta.url), "utf8");

  assert.match(component, /Disponible[\s\S]*Separado[\s\S]*Total/);
  assert.match(component, /startMovement\("ingreso"\)[\s\S]*startMovement\("gasto"\)[\s\S]*startMovement\("transferencia"\)/);
  assert.match(component, /Enviar comentario anónimo/);
  assert.match(component, /dueño y propietario de Mi Libreta Financiera/);
  assert.match(component, /libreta-feedback-bubble/);
  assert.match(component, /Ocultar la burbuja de comentarios/);
  assert.match(styles, /\.pocket-edit[^}]*background:\s*var\(--purple\)/);
  assert.match(styles, /\.money-map/);
});

test("includes the phase 3 payment agenda controls", async () => {
  const component = await readFile(new URL("../app/finance-notebook.tsx", import.meta.url), "utf8");
  const storage = await readFile(new URL("../lib/local-finance.ts", import.meta.url), "utf8");
  const reminders = await readFile(new URL("../app/api/push-reminders/route.ts", import.meta.url), "utf8");

  assert.match(component, /Agenda de pagos/);
  assert.match(component, /Tarjetas[\s\S]*Luz[\s\S]*Internet[\s\S]*Renta[\s\S]*Préstamo[\s\S]*Entretenimiento/);
  assert.match(component, /5, 3, 1/);
  assert.match(component, /Marcar pagado/);
  assert.match(component, /✎ Editar/);
  assert.match(component, /📩/);
  assert.match(storage, /schemaVersion:\s*6/);
  assert.match(storage, /updateLocalCard/);
  assert.match(storage, /deleteLocalCard/);
  assert.match(reminders, /\(1\|3\|5\)/);
});

test("includes the phase 4 goals and protected withdrawal flow", async () => {
  const component = await readFile(new URL("../app/finance-notebook.tsx", import.meta.url), "utf8");
  const storage = await readFile(new URL("../lib/local-finance.ts", import.meta.url), "utf8");
  const styles = await readFile(new URL("../app/globals.css", import.meta.url), "utf8");

  assert.match(component, /Corto plazo[\s\S]*Mediano plazo[\s\S]*Largo plazo/);
  assert.match(component, /¿Qué quieres lograr\?/);
  assert.match(component, /Estás cada vez más cerca de lograrlo/);
  assert.match(component, /Seguir con mi objetivo/);
  assert.match(component, /Sí, retirar el dinero/);
  assert.match(component, /＋ Aportar/);
  assert.match(storage, /addLocalGoalContribution/);
  assert.match(storage, /withdrawFromLocalGoal/);
  assert.match(storage, /pocket\.balanceCents -= amountCents[\s\S]*goal\.savedCents \+= amountCents/);
  assert.match(storage, /goal\.savedCents -= amountCents[\s\S]*pocket\.balanceCents \+= amountCents/);
  assert.match(styles, /\.goal-progress/);
});

test("includes phase 5 multiple notebooks with separate local data and a full backup", async () => {
  const component = await readFile(new URL("../app/finance-notebook.tsx", import.meta.url), "utf8");
  const storage = await readFile(new URL("../lib/local-finance.ts", import.meta.url), "utf8");
  const styles = await readFile(new URL("../app/globals.css", import.meta.url), "utf8");

  assert.match(component, /Mis libretas/);
  assert.match(component, /Crear otra libreta/);
  assert.match(component, /Renombrar[\s\S]*Eliminar/);
  assert.match(component, /Sus datos permanecen separados/);
  assert.match(component, /Comparación por periodo/);
  assert.match(component, /Compara ingresos, gastos y resultado sin mezclarlos/);
  assert.match(storage, /createLocalNotebook/);
  assert.match(storage, /switchLocalNotebook/);
  assert.match(storage, /renameLocalNotebook/);
  assert.match(storage, /deleteLocalNotebook/);
  assert.match(storage, /backupVersion:\s*2/);
  assert.match(storage, /notebookCollection/);
  assert.match(storage, /notebookSummaries/);
  assert.match(storage, /availableCents[\s\S]*reservedCents[\s\S]*totalTrackedCents/);
  assert.match(styles, /\.notebook-choice/);
  assert.match(styles, /\.notebook-comparison/);
});

test("includes the v2 tutorial and first-use notebook configuration", async () => {
  const onboarding = await readFile(new URL("../app/onboarding.tsx", import.meta.url), "utf8");
  const component = await readFile(new URL("../app/finance-notebook.tsx", import.meta.url), "utf8");
  const storage = await readFile(new URL("../lib/local-finance.ts", import.meta.url), "utf8");
  const styles = await readFile(new URL("../app/globals.css", import.meta.url), "utf8");

  assert.match(onboarding, /Inicio[\s\S]*Apuntes[\s\S]*Pagos[\s\S]*Objetivos[\s\S]*Reportes[\s\S]*Ajustes/);
  assert.match(onboarding, /Solo uso personal[\s\S]*Quiero varias libretas/);
  assert.match(onboarding, /Personal[\s\S]*Amor[\s\S]*Casa[\s\S]*Negocio/);
  assert.match(onboarding, /perfiles y acceso privado en una fase posterior/);
  assert.match(onboarding, /additionalNotebookNames/);
  assert.match(storage, /additionalNotebookNames/);
  assert.match(storage, /Las demás nacen vacías y separadas/);
  assert.match(component, /Guías y tutoriales/);
  assert.match(component, /Guía opcional/);
  assert.match(styles, /\.onboarding-guide/);
  assert.match(styles, /\.app-guide/);
});

test("offers a one-time interactive tutorial to existing users and keeps individual guides", async () => {
  const component = await readFile(new URL("../app/finance-notebook.tsx", import.meta.url), "utf8");
  const styles = await readFile(new URL("../app/globals.css", import.meta.url), "utf8");

  assert.match(component, /TUTORIAL_STATUS_KEY/);
  assert.match(component, /¿Quieres conocer cada botón\?/);
  assert.match(component, /Mostrarme el tutorial[\s\S]*Omitir por ahora/);
  assert.match(component, /Inicio[\s\S]*Apuntes[\s\S]*Botón \+[\s\S]*Pagos[\s\S]*Objetivos[\s\S]*Reporte[\s\S]*Mis libretas[\s\S]*Ajustes/);
  assert.match(component, /Guías y tutoriales/);
  assert.match(component, /Elige solo una función/);
  assert.match(component, /¿Qué te pareció el tutorial\?/);
  assert.match(component, /screen: feedbackContext === "tutorial" \? "tutorial" : tab/);
  assert.match(styles, /\.tutorial-prompt-sheet/);
  assert.match(styles, /\.tutorial-topic-icon/);
});

test("keeps payments safe and explains expense percentages against income", async () => {
  const component = await readFile(new URL("../app/finance-notebook.tsx", import.meta.url), "utf8");
  const styles = await readFile(new URL("../app/globals.css", import.meta.url), "utf8");

  assert.match(component, /const isIOS = isIOSDevice\(\)/);
  assert.match(component, /spendingByIncome/);
  assert.match(component, /De cada \$100 que entraron en el mes elegido/);
  assert.match(component, /Inicio[\s\S]*Apuntes[\s\S]*Pagos[\s\S]*add-button[\s\S]*Objetivos[\s\S]*Reporte[\s\S]*Ajustes/);
  assert.match(styles, /\.spending-analysis/);
  assert.match(styles, /grid-template-columns: repeat\(3, minmax\(0, 1fr\)\) 62px repeat\(3, minmax\(0, 1fr\)\)/);
});

test("lets people keep a one-time payment separate from a monthly recurring payment", async () => {
  const component = await readFile(new URL("../app/finance-notebook.tsx", import.meta.url), "utf8");
  const storage = await readFile(new URL("../lib/local-finance.ts", import.meta.url), "utf8");

  assert.match(component, /Solo este mes[\s\S]*Todos los meses/);
  assert.match(component, /Se repite cada mes/);
  assert.match(storage, /LocalPaymentRecurrence/);
  assert.match(storage, /card\.recurrence === "monthly"/);
  assert.match(storage, /nextMonthLastDay/);
});

test("keeps the product credits professional without placing a JV badge on the add button", async () => {
  const component = await readFile(new URL("../app/finance-notebook.tsx", import.meta.url), "utf8");
  const styles = await readFile(new URL("../app/globals.css", import.meta.url), "utf8");

  assert.match(component, /<ProductCredit \/>/);
  assert.match(component, /Creada por Josue Villarruel/);
  assert.match(component, /Dirección creativa: Josue Villarruel y Anahi Ramirez/);
  assert.match(component, /Versión beta · © 2026 · Todos los derechos reservados/);
  assert.match(styles, /\.creator-signature/);
  assert.doesNotMatch(styles, /\.bottom-nav::before\s*\{\s*content:\s*["']JV["']/);
  assert.match(styles, /\.creator-signature strong[^}]*font-size:\s*8px/);
});

test("compares notebooks by a chosen month without mixing their results", async () => {
  const component = await readFile(new URL("../app/finance-notebook.tsx", import.meta.url), "utf8");
  const storage = await readFile(new URL("../lib/local-finance.ts", import.meta.url), "utf8");
  const styles = await readFile(new URL("../app/globals.css", import.meta.url), "utf8");

  assert.match(component, /Comparación por periodo/);
  assert.match(component, /Ingresos del mes[\s\S]*Gastos del mes[\s\S]*Resultado del mes/);
  assert.match(component, /Aquí solo comparamos resultados; no se suman ni se transfieren montos/);
  assert.match(storage, /loadLocalNotebookComparison/);
  assert.match(storage, /incomeCents[\s\S]*expenseCents[\s\S]*netCents/);
  assert.match(styles, /\.notebook-comparison-period/);
});

test("archives notebooks safely and requires an exact-name confirmation before deletion", async () => {
  const component = await readFile(new URL("../app/finance-notebook.tsx", import.meta.url), "utf8");
  const storage = await readFile(new URL("../lib/local-finance.ts", import.meta.url), "utf8");
  const styles = await readFile(new URL("../app/globals.css", import.meta.url), "utf8");

  assert.match(component, /Archivar[\s\S]*Eliminar/);
  assert.match(component, /Libretas archivadas[\s\S]*Recuperar/);
  assert.match(component, /Primero guarda un respaldo/);
  assert.match(component, /Escribe el nombre exacto de la libreta para eliminarla/);
  assert.match(storage, /archiveLocalNotebook/);
  assert.match(storage, /restoreLocalNotebook/);
  assert.match(storage, /archivedAt/);
  assert.match(storage, /Conserva al menos una libreta activa en este teléfono/);
  assert.match(storage, /records\.filter\(\(record\) => !record\.archivedAt\)[\s\S]*notebookMonthComparison/);
  assert.match(styles, /\.archived-notebooks/);
  assert.match(styles, /\.delete-notebook-sheet/);
});

test("creates a month-specific report with local Excel and PDF exports", async () => {
  const component = await readFile(new URL("../app/finance-notebook.tsx", import.meta.url), "utf8");
  const exporter = await readFile(new URL("../lib/monthly-report-export.ts", import.meta.url), "utf8");
  const styles = await readFile(new URL("../app/globals.css", import.meta.url), "utf8");

  assert.match(component, /reportMonth/);
  assert.match(component, /Elige el mes[\s\S]*resumen y los archivos usarán este periodo/i);
  assert.match(component, /Excel \(\.xlsx\)[\s\S]*PDF/);
  assert.match(component, /downloadMonthlyExcel[\s\S]*downloadMonthlyPdf/);
  assert.match(exporter, /application\/vnd\.openxmlformats-officedocument\.spreadsheetml\.sheet/);
  assert.match(exporter, /application\/pdf/);
  assert.match(exporter, /Nunca mandan los[\s\S]*a un servidor/);
  assert.match(styles, /\.report-month-picker/);
  assert.match(styles, /\.monthly-export-card/);
});

test("explains installation honestly and gives every browser a usable fallback", async () => {
  const component = await readFile(new URL("../app/finance-notebook.tsx", import.meta.url), "utf8");
  const manifest = await readFile(new URL("../public/manifest.webmanifest", import.meta.url), "utf8");
  const serviceWorker = await readFile(new URL("../public/sw.js", import.meta.url), "utf8");

  assert.match(component, /INSTALL_ENTRY_STATUS_KEY/);
  assert.match(component, /No necesitas ser contador/);
  assert.match(component, /Usar en el navegador por ahora/);
  assert.match(component, /cambias de navegador o teléfono, podrías perderlos/);
  assert.match(component, /getInstallPlatform/);
  assert.match(component, /Abrir en navegador[\s\S]*Chrome[\s\S]*Safari/);
  assert.match(component, /beforeinstallprompt[\s\S]*setInstallPrompt/);
  assert.match(manifest, /"display":\s*"standalone"/);
  assert.match(component, /<img src="\/icon-192\.png\?v=18"/);
  assert.match(serviceWorker, /mi-libreta-shell-v8/);
  assert.doesNotMatch(serviceWorker, /mi-libreta-shell-v7/);
});

test("protects local financial data before destructive actions in version 3.0", async () => {
  const component = await readFile(new URL("../app/finance-notebook.tsx", import.meta.url), "utf8");
  const storage = await readFile(new URL("../lib/local-finance.ts", import.meta.url), "utf8");
  const styles = await readFile(new URL("../app/globals.css", import.meta.url), "utf8");

  assert.match(component, /Protección de datos/);
  assert.match(component, /Tu información financiera permanece en este teléfono/);
  assert.match(component, /Copia interna de seguridad/);
  assert.match(component, /restoreLocalSafetyCopy/);
  assert.match(component, /Restaurar reemplazará las libretas/);
  assert.match(storage, /SAFETY_COPY_KEY/);
  assert.match(storage, /before_restore[\s\S]*before_delete[\s\S]*before_reset/);
  assert.match(storage, /getLocalSafetyCopyStatus[\s\S]*restoreLocalSafetyCopy/);
  assert.match(storage, /getPersistentStorageStatus/);
  assert.match(styles, /\.security-sheet/);
  assert.match(styles, /\.security-check-list/);
});

test("keeps version 3.1 responsive with long local histories", async () => {
  const component = await readFile(new URL("../app/finance-notebook.tsx", import.meta.url), "utf8");
  const storage = await readFile(new URL("../lib/local-finance.ts", import.meta.url), "utf8");
  const styles = await readFile(new URL("../app/globals.css", import.meta.url), "utf8");
  const serviceWorker = await readFile(new URL("../public/sw.js", import.meta.url), "utf8");

  assert.match(component, /movementRenderLimit[\s\S]*80/);
  assert.match(component, /Mostrar 80 apuntes más/);
  assert.match(component, /AppErrorBoundary[\s\S]*Recargar mi libreta/);
  assert.match(component, /await import\("@\/lib\/monthly-report-export"\)/);
  assert.match(component, /movementDateFormatter[\s\S]*movementTimeFormatter/);
  assert.match(storage, /needsPersistence[\s\S]*raw\.schemaVersion !== 6/);
  assert.match(styles, /\.movement-load-more/);
  assert.match(styles, /content-visibility:\s*auto/);
  assert.match(serviceWorker, /mi-libreta-shell-v8/);
});
