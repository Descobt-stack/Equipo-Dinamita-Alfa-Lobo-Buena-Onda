// Esquema remoto. Las tablas beta son las usadas por la v14; las tablas
// financieras anteriores son una base para v2.0 y todavía no sustituyen
// IndexedDB como fuente de verdad de las libretas de usuarios actuales.
import { sql } from "drizzle-orm";
import { index, integer, sqliteTable, text, uniqueIndex } from "drizzle-orm/sqlite-core";

// Perfil remoto preliminar: será revisado antes de habilitar cuentas públicas.
export const profiles = sqliteTable("profiles", {
  email: text("email").primaryKey(),
  displayName: text("display_name").notNull(),
  notebookTitle: text("notebook_title").notNull().default("Mi libreta personal"),
  incomeFrequency: text("income_frequency").notNull().default("quincenal"),
  startMode: text("start_mode").notNull().default("today"),
  startDate: text("start_date").notNull(),
  theme: text("theme").notNull().default("purple"),
  profilePhotoKey: text("profile_photo_key"),
  onboardingCompleted: integer("onboarding_completed", { mode: "boolean" }).notNull().default(false),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  updatedAt: text("updated_at").notNull().default(sql`CURRENT_TIMESTAMP`),
});

// Estructuras financieras remotas históricas. En v2.0 deben incorporar una
// relación explícita con cada libreta y controles de propiedad en servidor.
export const pockets = sqliteTable("pockets", {
  id: text("id").primaryKey(),
  userEmail: text("user_email").notNull(),
  name: text("name").notNull(),
  type: text("type").notNull().default("custom"),
  color: text("color").notNull().default("violet"),
  icon: text("icon").notNull().default("✦"),
  balanceCents: integer("balance_cents").notNull().default(0),
  archived: integer("archived", { mode: "boolean" }).notNull().default(false),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
}, (table) => [index("pockets_user_idx").on(table.userEmail)]);

export const transactions = sqliteTable("transactions", {
  id: text("id").primaryKey(),
  userEmail: text("user_email").notNull(),
  kind: text("kind").notNull(),
  amountCents: integer("amount_cents").notNull(),
  sourcePocketId: text("source_pocket_id"),
  targetPocketId: text("target_pocket_id"),
  purpose: text("purpose").notNull(),
  note: text("note").notNull().default(""),
  occurredAt: text("occurred_at").notNull(),
  source: text("source").notNull().default("manual"),
  status: text("status").notNull().default("active"),
  changeReason: text("change_reason"),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  updatedAt: text("updated_at").notNull().default(sql`CURRENT_TIMESTAMP`),
}, (table) => [
  index("transactions_user_date_idx").on(table.userEmail, table.occurredAt),
  index("transactions_source_pocket_idx").on(table.sourcePocketId),
]);

export const cards = sqliteTable("cards", {
  id: text("id").primaryKey(),
  userEmail: text("user_email").notNull(),
  alias: text("alias").notNull(),
  amountDueCents: integer("amount_due_cents").notNull().default(0),
  dueDate: text("due_date"),
  status: text("status").notNull().default("current"),
  color: text("color").notNull().default("purple"),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  updatedAt: text("updated_at").notNull().default(sql`CURRENT_TIMESTAMP`),
}, (table) => [index("cards_user_idx").on(table.userEmail)]);

export const reminders = sqliteTable("reminders", {
  id: text("id").primaryKey(),
  userEmail: text("user_email").notNull(),
  cardId: text("card_id"),
  title: text("title").notNull(),
  dueAt: text("due_at").notNull(),
  remindDaysBefore: integer("remind_days_before").notNull().default(3),
  status: text("status").notNull().default("pending"),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
}, (table) => [index("reminders_user_due_idx").on(table.userEmail, table.dueAt)]);

export const pushSubscriptions = sqliteTable("push_subscriptions", {
  id: text("id").primaryKey(),
  userEmail: text("user_email").notNull(),
  endpoint: text("endpoint").notNull(),
  p256dh: text("p256dh").notNull(),
  auth: text("auth").notNull(),
  userAgent: text("user_agent").notNull().default(""),
  active: integer("active", { mode: "boolean" }).notNull().default(true),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
}, (table) => [index("push_user_idx").on(table.userEmail)]);

// Beta diagnostics are intentionally separated from financial records.
// They use a random installation id and never store balances, amounts, notes,
// card aliases, photographs, email addresses or reminder descriptions.
export const betaInstallations = sqliteTable("beta_installations", {
  installId: text("install_id").primaryKey(),
  platform: text("platform").notNull().default("unknown"),
  appVersion: text("app_version").notNull().default("beta-1"),
  firstSeenAt: text("first_seen_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  lastSeenAt: text("last_seen_at").notNull().default(sql`CURRENT_TIMESTAMP`),
});

export const betaEvents = sqliteTable("beta_events", {
  id: text("id").primaryKey(),
  installId: text("install_id").notNull(),
  eventName: text("event_name").notNull(),
  durationMs: integer("duration_ms"),
  screen: text("screen"),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
}, (table) => [index("beta_events_install_date_idx").on(table.installId, table.createdAt)]);

export const betaFeedback = sqliteTable("beta_feedback", {
  id: text("id").primaryKey(),
  installId: text("install_id").notNull(),
  rating: integer("rating").notNull(),
  message: text("message").notNull().default(""),
  screen: text("screen").notNull().default("general"),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
}, (table) => [index("beta_feedback_install_date_idx").on(table.installId, table.createdAt)]);

// Web Push is the only beta feature that needs a tiny amount of cloud state.
// The endpoint and encryption keys identify a browser installation, never a
// person or a financial account. Reminder payloads remain intentionally generic.
export const betaPushSubscriptions = sqliteTable("beta_push_subscriptions", {
  id: text("id").primaryKey(),
  installId: text("install_id").notNull(),
  endpoint: text("endpoint").notNull(),
  p256dh: text("p256dh").notNull(),
  auth: text("auth").notNull(),
  timezone: text("timezone").notNull().default("America/Mexico_City"),
  active: integer("active", { mode: "boolean" }).notNull().default(true),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  updatedAt: text("updated_at").notNull().default(sql`CURRENT_TIMESTAMP`),
}, (table) => [
  uniqueIndex("beta_push_endpoint_uidx").on(table.endpoint),
  index("beta_push_install_idx").on(table.installId),
]);

export const betaPaymentReminders = sqliteTable("beta_payment_reminders", {
  id: text("id").primaryKey(),
  installId: text("install_id").notNull(),
  remindAt: text("remind_at").notNull(),
  status: text("status").notNull().default("pending"),
  lastAttemptAt: text("last_attempt_at"),
  sentAt: text("sent_at"),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  updatedAt: text("updated_at").notNull().default(sql`CURRENT_TIMESTAMP`),
}, (table) => [
  index("beta_payment_reminders_due_idx").on(table.status, table.remindAt),
  index("beta_payment_reminders_install_idx").on(table.installId),
]);
