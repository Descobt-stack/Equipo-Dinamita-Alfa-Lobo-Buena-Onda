import { drizzle } from "drizzle-orm/d1";
import * as schema from "./schema";
import { getFinanceRuntimeEnv } from "@/lib/runtime-env";

export function getDb() {
  return drizzle(getFinanceRuntimeEnv().DB, { schema });
}
