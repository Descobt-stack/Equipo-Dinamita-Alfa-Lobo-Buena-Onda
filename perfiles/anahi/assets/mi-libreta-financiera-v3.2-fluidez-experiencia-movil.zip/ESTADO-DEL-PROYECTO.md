# Mi Libreta Financiera — estado del proyecto

Actualizado: 11 de agosto de 2026

## Sitio público

- Aplicación: https://libreta-financiera.josuepmvf.chatgpt.site
- Proyecto de Sites: `appgprj_6a71860818148191a006d5017875abf9`
- Modalidad actual: beta pública; los datos financieros permanecen en el dispositivo de cada usuario.

## Plan acordado en 5 fases

### Fase 1 — Correcciones y saldos (implementada en este punto)

- “Disponible para gastar” muestra únicamente la bolsa marcada como dinero disponible.
- El ahorro y los demás apartados aparecen como dinero reservado y ya no inflan el disponible.
- Los apuntes permiten editar tipo, monto, apartado de origen/destino, concepto, nota y fecha.
- Al editar un apunte se revierte su efecto anterior y se recalculan los saldos.
- Los apuntes pueden eliminarse con confirmación y recálculo.
- Los apartados pueden renombrarse, cambiar símbolo/color, corregir su saldo actual y clasificarse como disponible o reservado.
- La corrección del saldo actual permite arreglar una cantidad inicial equivocada sin registrarla como un ingreso o gasto nuevo.
- Un apartado vacío y sin movimientos relacionados puede eliminarse.
- Ajustes incluye “Empezar de cero”, protegido por dos confirmaciones.
- Los datos de versiones anteriores se conservan: la primera bolsa existente se clasifica como disponible y las demás como reservadas.

### Fase 2 — Claridad y reacomodo visual (implementada en este punto)

- La portada separa con claridad disponible, dinero separado y total registrado.
- Se añadieron accesos rápidos para ingreso, gasto y transferencia.
- El botón de editar apartados ahora es más grande, contrastante y fácil de encontrar.
- Hay una burbuja de comentarios junto a Ajustes; cada persona puede ocultarla o volverla a mostrar desde Ajustes.
- El formulario explica que los comentarios son anónimos, serán leídos por el dueño y propietario, y ayudarán a decidir mejoras.
- Se mejoraron etiquetas, jerarquía visual y explicación de los apartados usando las referencias compartidas por los usuarios de la beta.

### Fase 3 — Agenda de pagos (implementada en este punto)

- La sección “Tarjetas y pagos” ahora es una agenda completa de pagos.
- Categorías: tarjetas, luz, internet, renta, préstamo, entretenimiento y otros.
- Cada pago guarda nombre, banco o proveedor, cantidad, fecha límite, prioridad y estado.
- Los pagos pueden editarse, marcarse como pagados o pendientes y eliminarse con confirmación.
- Hay filtros por categoría y orden por importancia, fecha límite o cantidad.
- El resumen muestra pagos pendientes, cantidad total por pagar y vencidos.
- Los recordatorios se eligen por separado para 5, 3 y 1 día antes de la fecha límite.
- Al editar, pagar o eliminar un registro, la agenda remota de avisos se vuelve a sincronizar sin enviar detalles financieros.
- Los pagos guardados en versiones anteriores se migran automáticamente como categoría “Tarjeta” y conservan sus datos.
- El servicio push acepta los tres avisos por pago; la activación real ya fue comprobada en el teléfono de prueba.
- La burbuja de comentarios y el aviso del formulario ahora usan el icono de sobre 📩.

### Fase 4 — Objetivos (implementada en este punto)

- Objetivos de corto, mediano y largo plazo con filtros por tipo.
- Cada objetivo guarda nombre, motivo, costo, fecha, símbolo, color y progreso.
- La portada y el reporte separan el dinero disponible, los apartados y lo reservado en objetivos sin alterar el total real.
- Las aportaciones pueden salir de Disponible, Ahorro o cualquier apartado y reducen ese saldo al mismo tiempo que aumentan el objetivo.
- Los retiros regresan al apartado elegido y nunca se cuentan como un ingreso nuevo.
- Antes de retirar aparece una pausa motivacional: “Estás cada vez más cerca de lograrlo”, con opción de seguir ahorrando o confirmar el retiro.
- Se muestra cuánto se ha reunido, cuánto falta, porcentaje, fecha y una aportación mensual sugerida.
- Al alcanzar la cantidad objetivo se marca automáticamente como cumplido.
- Los objetivos pueden editarse y solo se eliminan después de retirar su saldo.
- Cada aportación o retiro conserva un registro local y se incluye en el respaldo completo.
- Los respaldos de las fases anteriores se migran automáticamente a la versión 5 del almacenamiento local, con varias libretas separadas.

### Fase 5 — Varias libretas (implementada en este punto)

- Crear hasta 12 libretas en cada teléfono, por ejemplo: Personal, Cuenta familiar o Negocio.
- Cambiar de libreta desde el encabezado o desde Ajustes → Mis libretas.
- Renombrar cualquier libreta desde el mismo administrador.
- Eliminar una libreta solo después de dos confirmaciones; siempre se conserva al menos una.
- Los apuntes, apartados, pagos, objetivos y reportes quedan realmente separados por libreta.
- Los datos existentes se migran automáticamente: la libreta que ya tenía cada persona se conserva como su primera libreta.
- El respaldo ahora incluye todas las libretas del teléfono y puede restaurarlas juntas.
- El administrador incluye un comparador local para ver, lado a lado, disponible, apartados, objetivos y total de cada libreta sin mezclar sus datos.

## Versión 2.0

### Fase 1 — Tutorial y configuración inicial (implementada; revisión didáctica v16)

- Al abrir por primera vez, la app explica Inicio, Apuntes, Pagos, Objetivos, Reportes y Ajustes con lenguaje sencillo.
- La guía aclara que “Disponible” es dinero libre para gastar y que ahorro, apartados y objetivos no se deben confundir con un ingreso.
- Cada persona puede elegir “Solo uso personal” o “Quiero varias libretas”.
- La configuración permite nombrar las libretas desde el inicio; sugiere Personal, Amor, Casa y Negocio.
- La primera libreta recibe los saldos iniciales; las adicionales empiezan en $0.00 y con datos realmente separados.
- El tutorial no obliga a crear una cuenta ni a compartir datos. La opción de libreta compartida se deja para perfiles privados en una fase posterior.
- Para usuarios con datos existentes aparece una sola vez la pregunta “¿Quieres conocer cada botón?”, con opciones para iniciar u omitir el recorrido.
- El recorrido guía por Inicio, Apuntes/+, Pagos, Objetivos, Reportes, Mis libretas y Ajustes, cambiando a la pantalla real explicada sin ejecutar ninguna acción financiera.
- Al terminar ofrece un comentario anónimo específico del tutorial. Después, todo queda disponible desde Ajustes → Guías y tutoriales, donde se puede repetir el recorrido o consultar un tema individual.

### Fase 2 — Administración y comparación de libretas (implementada)

- Los créditos globales de Josue Villarruel y Anahi Ramirez quedaron como un pie legal pequeño y discreto; el botón `+` se mantiene limpio.
- Ajustes → Mis libretas conserva crear, cambiar, renombrar y eliminar con las protecciones anteriores.
- Cuando hay dos o más libretas, el comparador permite elegir un mes y revisar por separado ingresos, gastos, resultado del mes, disponible, apartados y objetivos.
- Los resultados se calculan solo en el dispositivo y nunca suman, transfieren ni mezclan dinero entre libretas.

### Fase 3 - Reportes y exportacion mensual (implementada)

- Reporte por mes elegido, independiente del filtro de Apuntes.
- Resumen facil de entender de ingresos, gastos, resultado, disponible actual, apartados, objetivos y mayor gasto del periodo.
- Analisis de porcentajes de gasto sobre ingresos: explica cuantos pesos de cada $100 entrados se usaron en cada concepto.
- Exportacion local de la libreta activa y el mes elegido a Excel `.xlsx` y PDF.
- Excel incluye resumen, movimientos y pagos del mes; el PDF incluye cierre visual, porcentajes y detalle de movimientos.
- Los archivos se generan dentro del navegador del telefono: no se mandan montos ni notas a un servidor.

### Proximas fases v2.0 (orden actualizado)

1. Notas de voz opcionales.
2. Buzon del propietario, rendimiento, correcciones y beta.
3. Perfiles privados, sincronizacion entre dispositivos e invitaciones de evaluadores.
4. Preparacion para Google Play y TestFlight/App Store.

## Protección y recuperación

- La aplicación conserva los datos financieros en IndexedDB del dispositivo.
- El respaldo se puede compartir o descargar como JSON desde Ajustes y Reporte.
- Cada fase debe cerrar con pruebas, publicación, checkpoint de Sites y un ZIP completo del código.

## Versión 3.0

### Punto 1 — Seguridad y protección de datos (implementado)

- Nuevo centro **Ajustes → Protección de datos**, con explicación clara de privacidad, respaldo externo, almacenamiento local y recuperación.
- Antes de restaurar, borrar un movimiento/pago/objetivo/apartado/libreta o reiniciar una libreta, se crea una única copia interna del estado anterior.
- La copia se guarda solo en el teléfono y puede recuperarse desde Ajustes → Protección de datos.
- Restaurar un respaldo ahora pide una confirmación clara y conserva automáticamente el estado previo antes de reemplazar libretas.
- Los respaldos importados conservan el límite de 8 MB y validan cantidades máximas de libretas y registros antes de entrar al almacenamiento local.
- Si el navegador lo permite, la persona puede solicitar almacenamiento persistente para reducir el riesgo de que el sistema limpie datos locales.
- Esta fase no cambia saldos, movimientos, pagos, objetivos, apartados ni el modo en que se separan las libretas.

### Punto 2 — Rendimiento y estabilidad (v3.1, implementado)

- El historial mensual se dibuja inicialmente por partes de 80 apuntes; se pueden mostrar más sin eliminar registros.
- Los cálculos principales de Inicio y Pagos recorren los datos una sola vez en lugar de repetir filtros y ordenamientos.
- Las fechas y horas de movimientos reutilizan formateadores, reduciendo trabajo al abrir historiales grandes.
- PDF y Excel se cargan solo al exportar, para que la interfaz inicial sea más ligera.
- Las libretas que ya usan el formato actual dejan de reescribirse al abrirse sin necesidad.
- Un límite de error visual muestra una recuperación con recarga en vez de una pantalla blanca; no modifica ni envía datos.
- La caché de la PWA se actualiza a `mi-libreta-shell-v8`.

## Validación más reciente

- Lint: aprobado.
- Compilación de producción: aprobada.
- Prueba automatizada del HTML generado: aprobada.
- La Fase 1 fue validada con saldos separados, edición de apartados y saldo inicial, edición completa de movimientos y recálculo de $500 a $200.
- Fase 2: lint, compilación y dos pruebas automatizadas aprobadas.
- Fase 3: lint, compilación de producción y tres pruebas automatizadas aprobadas.
- Fase 4: lint, compilación de producción y cuatro pruebas automatizadas aprobadas.
- Fase 5: lint, compilación, cinco pruebas automatizadas y comprobación interactiva aprobadas. Se creó una segunda libreta, se agregó $250 de prueba y al cambiar a la primera libreta permaneció en $0.00, confirmando que los saldos no se mezclan.
- La revisión interactiva fue bloqueada por la política temporal del navegador de comprobación; el servidor de vista previa estuvo activo y el artefacto de producción fue validado.
- Publicación y checkpoint de la Fase 5: pendientes de este cierre.
- v2.0 Fase 1: compilación de producción y seis pruebas de regresión aprobadas. La vista previa local arrancó correctamente; el navegador de comprobación no pudo conectarse, por lo que la publicación se verificará mediante el estado del despliegue.
- v2.0 Fase 3: lint, compilacion de produccion y 14 pruebas de regresion aprobadas. La vista movil confirmo selector de mes y exportaciones locales de Excel/PDF.
