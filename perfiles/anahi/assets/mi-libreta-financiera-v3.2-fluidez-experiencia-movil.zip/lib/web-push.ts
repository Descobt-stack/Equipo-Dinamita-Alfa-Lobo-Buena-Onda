// Avisos push con contenido deliberadamente genérico: el servidor conoce la
// fecha y el dispositivo, pero no el nombre del pago ni su cantidad.
import { buildPushPayload, type PushSubscription } from "@block65/webcrypto-web-push";
import type { FinanceRuntimeEnv } from "./runtime-env";

export type StoredPushSubscription = {
  endpoint: string;
  p256dh: string;
  auth: string;
};

export type PushDelivery = {
  ok: boolean;
  gone: boolean;
  status: number;
};

export function pushIsConfigured(env: FinanceRuntimeEnv) {
  return Boolean(env.VAPID_SUBJECT && env.VAPID_SERVER_PUBLIC_KEY && env.VAPID_SERVER_PRIVATE_KEY);
}

export async function sendReminderPush(
  env: FinanceRuntimeEnv,
  target: StoredPushSubscription,
  kind: "test" | "payment" = "payment",
): Promise<PushDelivery> {
  if (!pushIsConfigured(env)) throw new Error("Web Push todavía no está configurado.");

  const subscription: PushSubscription = {
    endpoint: target.endpoint,
    expirationTime: null,
    keys: { p256dh: target.p256dh, auth: target.auth },
  };
  const data = kind === "test"
    ? {
        title: "Recordatorios activados",
        body: "Tu libreta ya puede avisarte aunque esté cerrada.",
        tag: "push-ready",
        url: "/?tab=tarjetas",
      }
    : {
        title: "Recordatorio de pago",
        body: "Tienes un pago próximo. Abre tu libreta para revisar los detalles.",
        tag: "payment-reminder",
        url: "/?tab=tarjetas",
      };
  const payload = await buildPushPayload({
    data: JSON.stringify(data),
    options: { ttl: 86_400, urgency: "high", topic: data.tag },
  }, subscription, {
    subject: env.VAPID_SUBJECT!,
    publicKey: env.VAPID_SERVER_PUBLIC_KEY!,
    privateKey: env.VAPID_SERVER_PRIVATE_KEY!,
  });
  const response = await fetch(target.endpoint, payload);
  return { ok: response.ok, gone: response.status === 404 || response.status === 410, status: response.status };
}

type DueReminderRow = StoredPushSubscription & {
  reminder_id: string;
  subscription_id: string;
};

export async function dispatchDueReminders(env: FinanceRuntimeEnv, limit = 100) {
  if (!pushIsConfigured(env)) return { checked: 0, sent: 0, removed: 0, failed: 0, configured: false };
  const now = new Date().toISOString();
  const rows = await env.DB.prepare(`SELECT
      r.id AS reminder_id,
      s.id AS subscription_id,
      s.endpoint,
      s.p256dh,
      s.auth
    FROM beta_payment_reminders r
    INNER JOIN beta_push_subscriptions s ON s.install_id = r.install_id AND s.active = 1
    WHERE r.status = 'pending' AND r.remind_at <= ?
    ORDER BY r.remind_at ASC
    LIMIT ?`).bind(now, Math.max(1, Math.min(250, limit))).all<DueReminderRow>();

  let sent = 0;
  let removed = 0;
  let failed = 0;
  for (const row of rows.results) {
    const claim = await env.DB.prepare(`UPDATE beta_payment_reminders
      SET status = 'sending', last_attempt_at = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP
      WHERE id = ? AND status = 'pending'`).bind(row.reminder_id).run();
    if (!claim.meta.changes) continue;
    try {
      const delivery = await sendReminderPush(env, row);
      if (delivery.ok) {
        sent += 1;
        await env.DB.prepare(`UPDATE beta_payment_reminders
          SET status = 'sent', sent_at = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP WHERE id = ?`)
          .bind(row.reminder_id).run();
      } else if (delivery.gone) {
        removed += 1;
        await env.DB.batch([
          env.DB.prepare("UPDATE beta_push_subscriptions SET active = 0, updated_at = CURRENT_TIMESTAMP WHERE id = ?").bind(row.subscription_id),
          env.DB.prepare("UPDATE beta_payment_reminders SET status = 'cancelled', updated_at = CURRENT_TIMESTAMP WHERE id = ?").bind(row.reminder_id),
        ]);
      } else {
        failed += 1;
        await env.DB.prepare("UPDATE beta_payment_reminders SET status = 'pending', updated_at = CURRENT_TIMESTAMP WHERE id = ?")
          .bind(row.reminder_id).run();
      }
    } catch {
      failed += 1;
      await env.DB.prepare("UPDATE beta_payment_reminders SET status = 'pending', updated_at = CURRENT_TIMESTAMP WHERE id = ?")
        .bind(row.reminder_id).run();
    }
  }
  return { checked: rows.results.length, sent, removed, failed, configured: true };
}
