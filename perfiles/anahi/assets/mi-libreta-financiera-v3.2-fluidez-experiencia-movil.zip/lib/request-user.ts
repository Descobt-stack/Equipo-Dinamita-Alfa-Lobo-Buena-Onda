// Guardia del servidor para las rutas remotas antiguas. Nunca confía en un
// correo enviado desde el navegador: la identidad debe venir de la plataforma.
import { getChatGPTUser } from "@/app/chatgpt-auth";

export type RequestUser = { email: string; displayName: string };

export async function getRequestUser(): Promise<RequestUser | null> {
  const user = await getChatGPTUser();
  if (user) return { email: user.email.toLowerCase(), displayName: user.displayName };

  // The agent preview has no forwarded identity. Production stays closed.
  if (process.env.NODE_ENV !== "production") {
    return { email: "beta.local@preview", displayName: "Usuario beta" };
  }
  return null;
}

export function unauthorized() {
  return Response.json({ error: "Debes iniciar sesión para acceder a esta libreta." }, { status: 401 });
}

export function amountToCents(value: unknown): number | null {
  const amount = typeof value === "number" ? value : Number(value);
  if (!Number.isFinite(amount) || amount <= 0 || amount > 999_999_999) return null;
  return Math.round(amount * 100);
}
