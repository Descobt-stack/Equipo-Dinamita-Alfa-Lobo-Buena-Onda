// Fuente de verdad de v14: todos los datos financieros se guardan en IndexedDB
// de este dispositivo. Cada exportación trabaja en centavos para evitar errores
// de redondeo y cada cambio devuelve un snapshot completo y coherente.
export type LocalMovementKind = "ingreso" | "gasto" | "transferencia";
export type LocalPocketRole = "available" | "reserved";
export type LocalPaymentCategory = "tarjeta" | "luz" | "internet" | "renta" | "prestamo" | "entretenimiento" | "otro";
export type LocalPaymentPriority = "relevante" | "poco_relevante" | "irrelevante";
// Un pago puede ser algo que termina este mes o una suscripción/servicio que
// vuelve cada mes. Guardarlo explícitamente evita asumir que todo se repite.
export type LocalPaymentRecurrence = "once" | "monthly";
export type LocalGoalTerm = "corto" | "mediano" | "largo";

export type LocalPocket = {
  id: string;
  name: string;
  balanceCents: number;
  icon: string;
  color: "violet" | "rose" | "blue" | "green";
  role: LocalPocketRole;
  createdAt: string;
};

export type LocalTransaction = {
  id: string;
  kind: LocalMovementKind;
  amountCents: number;
  sourcePocketId: string | null;
  targetPocketId: string | null;
  purpose: string;
  note: string;
  occurredAt: string;
  source: "manual" | "history_import";
  changeReason: string | null;
  correctedAt: string | null;
  createdAt: string;
};

export type LocalCard = {
  id: string;
  alias: string;
  category: LocalPaymentCategory;
  provider: string;
  amountDueCents: number;
  dueDate: string | null;
  remindDaysBefore: number[];
  priority: LocalPaymentPriority;
  recurrence: LocalPaymentRecurrence;
  status: "current" | "paid";
  color: string;
  createdAt: string;
  updatedAt: string;
};

export type LocalGoal = {
  id: string;
  name: string;
  purpose: string;
  term: LocalGoalTerm;
  targetCents: number;
  savedCents: number;
  targetDate: string;
  icon: string;
  color: LocalPocket["color"];
  status: "active" | "completed";
  createdAt: string;
  updatedAt: string;
};

export type LocalGoalMovement = {
  id: string;
  goalId: string;
  pocketId: string;
  kind: "contribution" | "withdrawal";
  amountCents: number;
  note: string;
  occurredAt: string;
};

export type LocalProfile = {
  displayName: string;
  notebookTitle: string;
  incomeFrequency: string;
  startMode: "today" | "history";
  startDate: string;
  theme: string;
  photoDataUrl: string | null;
};

type LocalNotebook = {
  schemaVersion: 6;
  installId: string;
  setupCompleted: boolean;
  profile: LocalProfile;
  pockets: LocalPocket[];
  transactions: LocalTransaction[];
  cards: LocalCard[];
  goals: LocalGoal[];
  goalMovements: LocalGoalMovement[];
  analyticsConsent: boolean;
  createdAt: string;
  updatedAt: string;
  notebookCollection?: LocalNotebookCollection;
};

type LocalNotebookData = Pick<LocalNotebook,
  "installId" | "setupCompleted" | "profile" | "pockets" | "transactions" | "cards" | "goals" | "goalMovements" | "analyticsConsent"
>;

export type LocalNotebookInfo = {
  id: string;
  name: string;
  createdAt: string;
  updatedAt: string;
  // Archivar permite ocultar una libreta sin perder su información. Se mantiene
  // dentro del respaldo y puede recuperarse cuando la persona lo necesite.
  archivedAt: string | null;
};

export type LocalNotebookSummary = LocalNotebookInfo & {
  availableCents: number;
  reservedCents: number;
  goalSavedCents: number;
  totalTrackedCents: number;
  pendingPayments: number;
  activeGoals: number;
};

// Esta vista solo lee los movimientos de cada libreta para compararlos en un
// mes elegido. No combina ni mueve dinero: cada resultado conserva su libreta.
export type LocalNotebookMonthComparison = {
  monthKey: string;
  availableMonths: string[];
  notebooks: Array<LocalNotebookSummary & {
    incomeCents: number;
    expenseCents: number;
    netCents: number;
    movementCount: number;
  }>;
};

type LocalNotebookRecord = LocalNotebookInfo & { data: LocalNotebookData };

type LocalNotebookCollection = {
  schemaVersion: 1;
  activeNotebookId: string;
  notebooks: LocalNotebookRecord[];
};

export type LocalNotebookSnapshot = LocalNotebookData & {
  notebookId: string;
  notebooks: LocalNotebookInfo[];
  notebookSummaries: LocalNotebookSummary[];
};

export type LocalSetupPayload = {
  notebookTitle: string;
  // La primera libreta se configura con los saldos que captura la persona.
  // Las demás nacen vacías y separadas para evitar repartir o duplicar dinero.
  additionalNotebookNames?: string[];
  incomeFrequency: string;
  startMode: "today" | "history";
  startDate: string;
  theme: string;
  pockets: Array<{ name: string; balance: number; color: string; icon: string; role?: LocalPocketRole }>;
  history: Array<{
    kind: "ingreso" | "gasto";
    amount: number;
    purpose: string;
    note: string;
    occurredAt: string;
    pocketIndex: number;
  }>;
};

// IndexedDB contiene un único estado raíz. Dentro de él, notebookCollection
// separa las libretas para que cambiar de una no mezcle sus registros con otra.
const DATABASE_NAME = "mi-libreta-financiera";
const DATABASE_VERSION = 1;
const STORE_NAME = "notebook";
const STATE_KEY = "primary";
// Una copia interna protege el estado anterior a una restauración o eliminación
// reciente. Permanece únicamente en este teléfono y no sustituye el respaldo
// JSON que la persona debe guardar fuera de la aplicación.
const SAFETY_COPY_KEY = "last-safety-copy";

type SafetyCopyReason = "before_restore" | "before_delete" | "before_reset";

type LocalSafetyCopy = {
  version: 1;
  createdAt: string;
  reason: SafetyCopyReason;
  state: LocalNotebook;
};

export type LocalSafetyCopyStatus = {
  available: boolean;
  createdAt: string | null;
  reason: SafetyCopyReason | null;
};

// UUID aleatorio compatible con navegadores modernos y con una alternativa
// para equipos que todavía no exponen crypto.randomUUID.
function newId() {
  if (typeof crypto.randomUUID === "function") return crypto.randomUUID();
  const bytes = crypto.getRandomValues(new Uint8Array(16));
  bytes[6] = (bytes[6] & 0x0f) | 0x40;
  bytes[8] = (bytes[8] & 0x3f) | 0x80;
  const hex = Array.from(bytes, (value) => value.toString(16).padStart(2, "0")).join("");
  return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`;
}

function defaultNotebook(): LocalNotebook {
  const now = new Date().toISOString();
  return {
    schemaVersion: 6,
    installId: newId(),
    setupCompleted: false,
    profile: {
      displayName: "",
      notebookTitle: "Mi libreta personal",
      incomeFrequency: "quincenal",
      startMode: "today",
      startDate: now.slice(0, 10),
      theme: "purple",
      photoDataUrl: null,
    },
    pockets: [],
    transactions: [],
    cards: [],
    goals: [],
    goalMovements: [],
    analyticsConsent: false,
    createdAt: now,
    updatedAt: now,
  };
}

function notebookDataFromState(state: LocalNotebook): LocalNotebookData {
  return structuredClone({
    installId: state.installId,
    setupCompleted: state.setupCompleted,
    profile: state.profile,
    pockets: state.pockets,
    transactions: state.transactions,
    cards: state.cards,
    goals: state.goals,
    goalMovements: state.goalMovements,
    analyticsConsent: state.analyticsConsent,
  });
}

function applyNotebookData(state: LocalNotebook, data: LocalNotebookData) {
  state.installId = data.installId;
  state.setupCompleted = data.setupCompleted;
  state.profile = structuredClone(data.profile);
  state.pockets = structuredClone(data.pockets);
  state.transactions = structuredClone(data.transactions);
  state.cards = structuredClone(data.cards);
  state.goals = structuredClone(data.goals);
  state.goalMovements = structuredClone(data.goalMovements);
  state.analyticsConsent = data.analyticsConsent;
}

function cleanNotebookName(value: string | undefined, fallback = "Mi libreta") {
  return (value ?? "").trim().slice(0, 60) || fallback;
}

function activeNotebookRecord(state: LocalNotebook) {
  const collection = state.notebookCollection;
  if (!collection) throw new Error("No pudimos organizar tus libretas locales.");
  const record = collection.notebooks.find((item) => item.id === collection.activeNotebookId);
  if (!record) throw new Error("No pudimos encontrar la libreta seleccionada.");
  return record;
}

function syncActiveNotebook(state: LocalNotebook) {
  const record = activeNotebookRecord(state);
  record.name = cleanNotebookName(state.profile.notebookTitle, record.name);
  record.data = notebookDataFromState(state);
  record.updatedAt = new Date().toISOString();
}

function notebookInfos(state: LocalNotebook): LocalNotebookInfo[] {
  return state.notebookCollection?.notebooks.map(({ id, name, createdAt, updatedAt, archivedAt }) => ({ id, name, createdAt, updatedAt, archivedAt: archivedAt ?? null })) ?? [];
}

function notebookSummary(record: LocalNotebookRecord): LocalNotebookSummary {
  const pockets = Array.isArray(record.data.pockets) ? record.data.pockets : [];
  const goals = Array.isArray(record.data.goals) ? record.data.goals : [];
  const cards = Array.isArray(record.data.cards) ? record.data.cards : [];
  const availableCents = pockets
    .filter((pocket) => pocket.role === "available")
    .reduce((sum, pocket) => sum + Math.max(0, Number(pocket.balanceCents) || 0), 0);
  const reservedCents = pockets
    .filter((pocket) => pocket.role !== "available")
    .reduce((sum, pocket) => sum + Math.max(0, Number(pocket.balanceCents) || 0), 0);
  const goalSavedCents = goals.reduce((sum, goal) => sum + Math.max(0, Number(goal.savedCents) || 0), 0);

  return {
    id: record.id,
    name: record.name,
    createdAt: record.createdAt,
    updatedAt: record.updatedAt,
    archivedAt: record.archivedAt ?? null,
    availableCents,
    reservedCents,
    goalSavedCents,
    totalTrackedCents: availableCents + reservedCents + goalSavedCents,
    pendingPayments: cards.filter((card) => card.status !== "paid").length,
    activeGoals: goals.filter((goal) => goal.status !== "completed").length,
  };
}

function notebookSummaries(state: LocalNotebook): LocalNotebookSummary[] {
  return state.notebookCollection?.notebooks.filter((record) => !record.archivedAt).map(notebookSummary) ?? [];
}

function monthKeyFromDate(value: string) {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "";
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}`;
}

function currentMonthKey() {
  return monthKeyFromDate(new Date().toISOString());
}

function notebookMonthComparison(record: LocalNotebookRecord, monthKey: string) {
  const transactions = Array.isArray(record.data.transactions) ? record.data.transactions : [];
  const movements = transactions.filter((movement) => monthKeyFromDate(movement.occurredAt) === monthKey);
  const incomeCents = movements
    .filter((movement) => movement.kind === "ingreso")
    .reduce((sum, movement) => sum + Math.max(0, Number(movement.amountCents) || 0), 0);
  const expenseCents = movements
    .filter((movement) => movement.kind === "gasto")
    .reduce((sum, movement) => sum + Math.max(0, Number(movement.amountCents) || 0), 0);
  return {
    ...notebookSummary(record),
    incomeCents,
    expenseCents,
    netCents: incomeCents - expenseCents,
    movementCount: movements.length,
  };
}

function createBlankNotebook(name: string): LocalNotebook {
  const fresh = defaultNotebook();
  const now = new Date().toISOString();
  fresh.setupCompleted = true;
  fresh.profile.notebookTitle = cleanNotebookName(name, "Nueva libreta");
  fresh.pockets = [{
    id: newId(),
    name: "Dinero disponible",
    balanceCents: 0,
    icon: "☀",
    color: "green",
    role: "available",
    createdAt: now,
  }];
  return fresh;
}

// Puerta de migración: admite datos de versiones anteriores y les añade los
// campos nuevos sin eliminar apuntes, pagos, metas ni libretas existentes.
function normalizeNotebook(stored: LocalNotebook | undefined): LocalNotebook {
  if (!stored) return normalizeNotebook(defaultNotebook());
  const state = stored as LocalNotebook;
  const rawCollection = state.notebookCollection;
  if (rawCollection?.schemaVersion === 1 && Array.isArray(rawCollection.notebooks) && rawCollection.notebooks.length) {
    const records = rawCollection.notebooks.filter((item) => item && typeof item.id === "string" && item.data && item.data.profile).map((item) => ({
      id: item.id,
      name: cleanNotebookName(item.name, cleanNotebookName(item.data.profile.notebookTitle)),
      createdAt: item.createdAt || new Date().toISOString(),
      updatedAt: item.updatedAt || item.createdAt || new Date().toISOString(),
      archivedAt: typeof item.archivedAt === "string" ? item.archivedAt : null,
      data: item.data,
    }));
    if (records.length) {
      const activeNotebookId = records.some((item) => item.id === rawCollection.activeNotebookId) ? rawCollection.activeNotebookId : records[0].id;
      state.notebookCollection = { schemaVersion: 1, activeNotebookId, notebooks: records };
      applyNotebookData(state, records.find((item) => item.id === activeNotebookId)!.data);
    } else {
      delete state.notebookCollection;
    }
  } else {
    delete state.notebookCollection;
  }
  state.schemaVersion = 6;
  state.pockets = (Array.isArray(state.pockets) ? state.pockets : []).map((pocket, index) => ({
    ...pocket,
    role: pocket.role === "available" || pocket.role === "reserved"
      ? pocket.role
      : index === 0 ? "available" : "reserved",
  }));
  if (state.pockets.length && !state.pockets.some((pocket) => pocket.role === "available")) {
    state.pockets[0].role = "available";
  }
  state.cards = (Array.isArray(state.cards) ? state.cards : []).map((card) => {
    const legacy = card as LocalCard & { remindDaysBefore?: number | number[]; category?: string; provider?: string; priority?: string; recurrence?: string; updatedAt?: string };
    const reminderValues = Array.isArray(legacy.remindDaysBefore)
      ? legacy.remindDaysBefore
      : typeof legacy.remindDaysBefore === "number" ? [legacy.remindDaysBefore] : [5, 3, 1];
    const category = (["tarjeta", "luz", "internet", "renta", "prestamo", "entretenimiento", "otro"] as string[]).includes(legacy.category ?? "")
      ? legacy.category as LocalPaymentCategory
      : "tarjeta";
    const priority = (["relevante", "poco_relevante", "irrelevante"] as string[]).includes(legacy.priority ?? "")
      ? legacy.priority as LocalPaymentPriority
      : "relevante";
    return {
      ...card,
      category,
      provider: (legacy.provider ?? "").slice(0, 60),
      remindDaysBefore: Array.from(new Set(reminderValues.map(Number).filter((day) => [1, 3, 5].includes(day)))).sort((a, b) => b - a),
      priority,
      // Los pagos existentes eran pagos de una sola ocasión; así la mejora no
      // convierte por accidente una deuda antigua en una suscripción mensual.
      recurrence: legacy.recurrence === "monthly" ? "monthly" : "once",
      updatedAt: legacy.updatedAt ?? card.createdAt,
    };
  });
  state.goals = (Array.isArray(state.goals) ? state.goals : []).map((goal) => ({
    ...goal,
    purpose: (goal.purpose ?? "").slice(0, 240),
    term: (["corto", "mediano", "largo"] as string[]).includes(goal.term) ? goal.term : "mediano",
    targetCents: Math.max(1, Math.round(Number(goal.targetCents) || 0)),
    savedCents: Math.max(0, Math.round(Number(goal.savedCents) || 0)),
    targetDate: /^\d{4}-\d{2}-\d{2}$/.test(goal.targetDate ?? "") ? goal.targetDate : new Date().toISOString().slice(0, 10),
    icon: (goal.icon || "◎").slice(0, 4),
    color: (["violet", "rose", "blue", "green"] as string[]).includes(goal.color) ? goal.color : "violet",
    status: Number(goal.savedCents) >= Number(goal.targetCents) ? "completed" : "active",
    updatedAt: goal.updatedAt ?? goal.createdAt ?? new Date().toISOString(),
  })) as LocalGoal[];
  const goalIds = new Set(state.goals.map((goal) => goal.id));
  const pocketIds = new Set(state.pockets.map((pocket) => pocket.id));
  state.goalMovements = (Array.isArray(state.goalMovements) ? state.goalMovements : []).filter((movement) => (
    goalIds.has(movement.goalId) && pocketIds.has(movement.pocketId) && movement.amountCents > 0
  ));
  if (!state.notebookCollection) {
    const id = newId();
    const now = new Date().toISOString();
    state.notebookCollection = {
      schemaVersion: 1,
      activeNotebookId: id,
      notebooks: [{
        id,
        name: cleanNotebookName(state.profile?.notebookTitle),
        createdAt: state.createdAt || now,
        updatedAt: state.updatedAt || now,
        archivedAt: null,
        data: notebookDataFromState(state),
      }],
    };
  } else {
    syncActiveNotebook(state);
  }
  return state;
}

// Operaciones de almacenamiento: leer, modificar y confirmar ocurren dentro
// de una transacción para que nunca quede un saldo cambiado a medias.
function openDatabase(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DATABASE_NAME, DATABASE_VERSION);
    request.onupgradeneeded = () => {
      const database = request.result;
      if (!database.objectStoreNames.contains(STORE_NAME)) database.createObjectStore(STORE_NAME);
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error ?? new Error("No se pudo abrir el almacenamiento local."));
  });
}

function readState(database: IDBDatabase, mode: IDBTransactionMode): Promise<{ state: LocalNotebook; transaction: IDBTransaction; store: IDBObjectStore; needsPersistence: boolean }> {
  const transaction = database.transaction(STORE_NAME, mode);
  const store = transaction.objectStore(STORE_NAME);
  return new Promise((resolve, reject) => {
    const request = store.get(STATE_KEY);
    request.onsuccess = () => {
      const raw = request.result as LocalNotebook | undefined;
      // Una libreta que ya está en el formato actual no necesita reescribirse
      // cada vez que se abre. Reducir esa escritura evita trabajo extra y cuida
      // la batería, especialmente con historiales largos.
      const needsPersistence = !raw || raw.schemaVersion !== 6 || raw.notebookCollection?.schemaVersion !== 1;
      resolve({ state: normalizeNotebook(raw), transaction, store, needsPersistence });
    };
    request.onerror = () => reject(request.error ?? new Error("No se pudo leer la libreta local."));
  });
}

function finishTransaction(transaction: IDBTransaction): Promise<void> {
  return new Promise((resolve, reject) => {
    transaction.oncomplete = () => resolve();
    transaction.onerror = () => reject(transaction.error ?? new Error("No se pudo guardar la libreta local."));
    transaction.onabort = () => reject(transaction.error ?? new Error("El guardado local fue cancelado."));
  });
}

function publicSnapshot(state: LocalNotebook): LocalNotebookSnapshot {
  return structuredClone({
    ...notebookDataFromState(state),
    notebookId: state.notebookCollection?.activeNotebookId ?? "",
    notebooks: notebookInfos(state),
    notebookSummaries: notebookSummaries(state),
  });
}

// Todas las mutaciones públicas pasan por aquí. Sincroniza la libreta activa,
// actualiza fecha, guarda el estado y devuelve una copia segura para la UI.
async function mutateState(
  change: (state: LocalNotebook) => void,
  options?: { safetyCopyReason?: SafetyCopyReason },
): Promise<LocalNotebookSnapshot> {
  const database = await openDatabase();
  try {
    const { state, transaction, store } = await readState(database, "readwrite");
    if (options?.safetyCopyReason) {
      // La copia y el cambio principal viajan en la misma transacción: si algo
      // falla, IndexedDB cancela ambos y nunca deja la libreta a medias.
      syncActiveNotebook(state);
      const copy: LocalSafetyCopy = {
        version: 1,
        createdAt: new Date().toISOString(),
        reason: options.safetyCopyReason,
        state: structuredClone(state),
      };
      store.put(copy, SAFETY_COPY_KEY);
    }
    change(state);
    syncActiveNotebook(state);
    state.updatedAt = new Date().toISOString();
    store.put(state, STATE_KEY);
    await finishTransaction(transaction);
    return publicSnapshot(state);
  } finally {
    database.close();
  }
}

// Carga inicial y persistencia inmediata de la migración si una beta anterior
// todavía no tenía roles de apartado, metas o colección de varias libretas.
export async function loadLocalNotebook(): Promise<LocalNotebookSnapshot> {
  const database = await openDatabase();
  try {
    const { state, transaction, store, needsPersistence } = await readState(database, "readwrite");
    // Las versiones antiguas se migran una sola vez. Las actuales solo leen el
    // estado, lo que acelera cada inicio sin cambiar la protección local.
    if (needsPersistence) store.put(state, STATE_KEY);
    await finishTransaction(transaction);
    return publicSnapshot(state);
  } finally {
    database.close();
  }
}

// Comparación local de varias libretas. Solo se abre al pedirla desde Ajustes;
// por eso no añade sincronización, cuentas ni datos remotos a esta fase.
export async function loadLocalNotebookComparison(requestedMonth?: string): Promise<LocalNotebookMonthComparison> {
  const database = await openDatabase();
  try {
    const { state, transaction } = await readState(database, "readonly");
    const records = state.notebookCollection?.notebooks ?? [];
    const availableMonths = Array.from(new Set([
      currentMonthKey(),
      ...records.flatMap((record) => (record.data.transactions ?? []).map((movement) => monthKeyFromDate(movement.occurredAt)).filter(Boolean)),
    ])).sort().reverse().slice(0, 12);
    const monthKey = availableMonths.includes(requestedMonth ?? "") ? requestedMonth! : availableMonths[0] ?? currentMonthKey();
    await finishTransaction(transaction);
    return structuredClone({
      monthKey,
      availableMonths,
      notebooks: records.filter((record) => !record.archivedAt).map((record) => notebookMonthComparison(record, monthKey)),
    });
  } finally {
    database.close();
  }
}

// Administración de libretas. El límite de 12 cuida el rendimiento del teléfono
// y los nombres duplicados se bloquean para no confundir los respaldos.
export async function createLocalNotebook(name: string): Promise<LocalNotebookSnapshot> {
  return mutateState((state) => {
    const collection = state.notebookCollection;
    if (!collection) throw new Error("No pudimos preparar tus libretas.");
    const cleanName = cleanNotebookName(name, "Nueva libreta");
    if (collection.notebooks.length >= 12) throw new Error("Por ahora puedes tener hasta 12 libretas en este teléfono.");
    if (collection.notebooks.some((item) => item.name.localeCompare(cleanName, "es", { sensitivity: "accent" }) === 0)) {
      throw new Error("Ya tienes una libreta con ese nombre.");
    }
    syncActiveNotebook(state);
    const fresh = createBlankNotebook(cleanName);
    const now = new Date().toISOString();
    const id = newId();
    collection.notebooks.push({ id, name: cleanName, createdAt: now, updatedAt: now, archivedAt: null, data: notebookDataFromState(fresh) });
    collection.activeNotebookId = id;
    applyNotebookData(state, fresh);
  });
}

export async function switchLocalNotebook(id: string): Promise<LocalNotebookSnapshot> {
  return mutateState((state) => {
    const collection = state.notebookCollection;
    const target = collection?.notebooks.find((item) => item.id === id);
    if (!collection || !target) throw new Error("Esa libreta ya no existe en este teléfono.");
    if (target.archivedAt) throw new Error("Primero recupera esta libreta para volver a usarla.");
    if (collection.activeNotebookId === id) return;
    syncActiveNotebook(state);
    collection.activeNotebookId = id;
    applyNotebookData(state, target.data);
  });
}

export async function renameLocalNotebook(id: string, name: string): Promise<LocalNotebookSnapshot> {
  return mutateState((state) => {
    const collection = state.notebookCollection;
    const notebook = collection?.notebooks.find((item) => item.id === id);
    const cleanName = cleanNotebookName(name);
    if (!collection || !notebook) throw new Error("Esa libreta ya no existe en este teléfono.");
    if (collection.notebooks.some((item) => item.id !== id && item.name.localeCompare(cleanName, "es", { sensitivity: "accent" }) === 0)) {
      throw new Error("Ya tienes una libreta con ese nombre.");
    }
    notebook.name = cleanName;
    notebook.updatedAt = new Date().toISOString();
    notebook.data.profile.notebookTitle = cleanName;
    if (collection.activeNotebookId === id) state.profile.notebookTitle = cleanName;
  });
}

// Archivar es reversible: no borra movimientos, pagos, objetivos ni apartados.
// La libreta se excluye del selector rápido y de la comparación hasta restaurarla.
export async function archiveLocalNotebook(id: string): Promise<LocalNotebookSnapshot> {
  return mutateState((state) => {
    const collection = state.notebookCollection;
    const notebook = collection?.notebooks.find((item) => item.id === id);
    if (!collection || !notebook) throw new Error("Esa libreta ya no existe en este teléfono.");
    if (notebook.archivedAt) return;
    const activeNotebooks = collection.notebooks.filter((item) => !item.archivedAt);
    if (activeNotebooks.length < 2) throw new Error("Conserva al menos una libreta activa en este teléfono.");
    syncActiveNotebook(state);
    notebook.archivedAt = new Date().toISOString();
    notebook.updatedAt = new Date().toISOString();
    if (collection.activeNotebookId === id) {
      const next = collection.notebooks.find((item) => !item.archivedAt);
      if (!next) throw new Error("Conserva al menos una libreta activa en este teléfono.");
      collection.activeNotebookId = next.id;
      applyNotebookData(state, next.data);
    }
  });
}

export async function restoreLocalNotebook(id: string): Promise<LocalNotebookSnapshot> {
  return mutateState((state) => {
    const collection = state.notebookCollection;
    const notebook = collection?.notebooks.find((item) => item.id === id);
    if (!collection || !notebook) throw new Error("Esa libreta ya no existe en este teléfono.");
    if (!notebook.archivedAt) return;
    notebook.archivedAt = null;
    notebook.updatedAt = new Date().toISOString();
  });
}

export async function deleteLocalNotebook(id: string): Promise<LocalNotebookSnapshot> {
  return mutateState((state) => {
    const collection = state.notebookCollection;
    const notebook = collection?.notebooks.find((item) => item.id === id);
    if (!collection || !notebook) throw new Error("Esa libreta ya no existe en este teléfono.");
    if (collection.notebooks.length < 2) throw new Error("Conserva al menos una libreta en este teléfono.");
    if (!notebook.archivedAt && collection.notebooks.filter((item) => !item.archivedAt).length < 2) {
      throw new Error("Conserva al menos una libreta activa en este teléfono.");
    }
    syncActiveNotebook(state);
    collection.notebooks = collection.notebooks.filter((item) => item.id !== id);
    if (collection.activeNotebookId === id) {
      const next = collection.notebooks[0];
      collection.activeNotebookId = next.id;
      applyNotebookData(state, next.data);
    }
  }, { safetyCopyReason: "before_delete" });
}

// Configuración inicial: crea los apartados de la primera libreta y, si aplica,
// importa un historial sin alterar el saldo que la persona indicó al empezar.
export async function setupLocalNotebook(payload: LocalSetupPayload): Promise<LocalNotebookSnapshot> {
  return mutateState((state) => {
    if (state.setupCompleted) throw new Error("La libreta ya fue configurada en este teléfono.");
    const now = new Date().toISOString();
    const pockets = payload.pockets.slice(0, 20).filter((item) => item.name.trim()).map((item, index) => ({
      id: newId(),
      name: item.name.trim().slice(0, 45) || `Apartado ${index + 1}`,
      balanceCents: Math.max(0, Math.round(Number(item.balance || 0) * 100)),
      icon: (item.icon || "✦").slice(0, 4),
      color: (["violet", "rose", "blue", "green"].includes(item.color) ? item.color : "violet") as LocalPocket["color"],
      role: item.role === "available" || item.role === "reserved" ? item.role : index === 0 ? "available" : "reserved",
      createdAt: now,
    }));
    if (!pockets.length) throw new Error("Agrega al menos un apartado.");
    state.profile = {
      ...state.profile,
      notebookTitle: payload.notebookTitle.trim().slice(0, 60) || "Mi libreta personal",
      incomeFrequency: payload.incomeFrequency,
      startMode: payload.startMode,
      startDate: payload.startDate,
      theme: payload.theme.slice(0, 24),
    };
    state.pockets = pockets;
    state.transactions = payload.startMode === "history" ? payload.history.slice(0, 500).flatMap((item) => {
      const pocket = pockets[Math.max(0, Math.min(pockets.length - 1, Number(item.pocketIndex || 0)))];
      const cents = Math.max(0, Math.round(Number(item.amount || 0) * 100));
      if (!pocket || !cents || !item.purpose.trim()) return [];
      return [{
        id: newId(),
        kind: item.kind,
        amountCents: cents,
        sourcePocketId: pocket.id,
        targetPocketId: null,
        purpose: item.purpose.trim().slice(0, 120),
        note: item.note.trim().slice(0, 500),
        occurredAt: new Date(item.occurredAt).toISOString(),
        source: "history_import" as const,
        changeReason: null,
        correctedAt: null,
        createdAt: now,
      }];
    }) : [];
    state.cards = [];
    state.goals = [];
    state.goalMovements = [];
    state.setupCompleted = true;

    // Desde v2.0 el primer inicio puede preparar varias libretas. La primera
    // conserva exactamente los saldos que la persona indicó; las adicionales
    // empiezan en cero y tienen su propia colección de datos desde el inicio.
    const activeId = state.notebookCollection?.activeNotebookId ?? newId();
    const primaryName = cleanNotebookName(state.profile.notebookTitle, "Mi libreta personal");
    const nowData = notebookDataFromState(state);
    const additionalNames = Array.from(new Set((payload.additionalNotebookNames ?? [])
      .map((name) => cleanNotebookName(name, ""))
      .filter((name) => name && name.localeCompare(primaryName, "es", { sensitivity: "accent" }) !== 0)))
      .slice(0, 4);
    const records: LocalNotebookRecord[] = [{
      id: activeId,
      name: primaryName,
      createdAt: state.createdAt || now,
      updatedAt: now,
      data: nowData,
    }];
    for (const name of additionalNames) {
      const fresh = createBlankNotebook(name);
      records.push({ id: newId(), name, createdAt: now, updatedAt: now, archivedAt: null, data: notebookDataFromState(fresh) });
    }
    state.notebookCollection = { schemaVersion: 1, activeNotebookId: activeId, notebooks: records };
  });
}

// Movimientos: cada ingreso, gasto o transferencia valida los apartados antes
// de afectar saldo. Una transferencia conserva el total porque mueve el mismo
// importe de origen a destino.
export async function addLocalTransaction(input: {
  kind: LocalMovementKind;
  amount: number;
  sourcePocketId: string;
  targetPocketId: string | null;
  purpose: string;
  note: string;
  occurredAt: string;
}): Promise<LocalNotebookSnapshot> {
  return mutateState((state) => {
    const cents = Math.round(input.amount * 100);
    const purpose = input.purpose.trim();
    if (!state.setupCompleted || !cents || cents < 1) throw new Error("Escribe una cantidad mayor a cero.");
    if (!purpose) throw new Error("Es obligatorio indicar para qué es el movimiento.");
    const source = state.pockets.find((pocket) => pocket.id === input.sourcePocketId);
    if (!source) throw new Error("El apartado seleccionado ya no existe.");
    const target = input.kind === "transferencia" ? state.pockets.find((pocket) => pocket.id === input.targetPocketId) : null;
    if (input.kind === "transferencia" && (!target || target.id === source.id)) throw new Error("Elige apartados diferentes para la transferencia.");
    if ((input.kind === "gasto" || input.kind === "transferencia") && source.balanceCents < cents) throw new Error("Ese apartado no tiene saldo suficiente.");
    if (input.kind === "ingreso") source.balanceCents += cents;
    if (input.kind === "gasto") source.balanceCents -= cents;
    if (input.kind === "transferencia" && target) {
      source.balanceCents -= cents;
      target.balanceCents += cents;
    }
    const now = new Date().toISOString();
    state.transactions.unshift({
      id: newId(),
      kind: input.kind,
      amountCents: cents,
      sourcePocketId: source.id,
      targetPocketId: target?.id ?? null,
      purpose: purpose.slice(0, 120),
      note: input.note.trim().slice(0, 500),
      occurredAt: new Date(input.occurredAt).toISOString(),
      source: "manual",
      changeReason: null,
      correctedAt: null,
      createdAt: now,
    });
  });
}

export async function updateLocalProfile(changes: Partial<Pick<LocalProfile, "notebookTitle" | "incomeFrequency" | "theme">>): Promise<LocalNotebookSnapshot> {
  return mutateState((state) => {
    if (changes.notebookTitle !== undefined) state.profile.notebookTitle = changes.notebookTitle.trim().slice(0, 60) || "Mi libreta";
    if (changes.incomeFrequency !== undefined) state.profile.incomeFrequency = changes.incomeFrequency.slice(0, 24);
    if (changes.theme !== undefined) state.profile.theme = changes.theme.slice(0, 24);
  });
}

export async function setLocalPhoto(photoDataUrl: string): Promise<LocalNotebookSnapshot> {
  if (!photoDataUrl.startsWith("data:image/") || photoDataUrl.length > 1_800_000) throw new Error("La fotografía es demasiado grande.");
  return mutateState((state) => { state.profile.photoDataUrl = photoDataUrl; });
}

type LocalCardInput = {
  alias: string;
  category: LocalPaymentCategory;
  provider: string;
  amountDue: number;
  dueDate: string | null;
  remindDaysBefore: number[];
  priority: LocalPaymentPriority;
  recurrence: LocalPaymentRecurrence;
};

function normalizedCardInput(input: LocalCardInput) {
  const alias = input.alias.trim();
  const amountDueCents = Math.round(Number(input.amountDue) * 100);
  if (!alias) throw new Error("Ponle un nombre al pago.");
  if (!Number.isFinite(amountDueCents) || amountDueCents < 1) throw new Error("Escribe una cantidad por pagar mayor a cero.");
  if (!input.dueDate || !/^\d{4}-\d{2}-\d{2}$/.test(input.dueDate)) throw new Error("Elige una fecha límite válida.");
  const categories: LocalPaymentCategory[] = ["tarjeta", "luz", "internet", "renta", "prestamo", "entretenimiento", "otro"];
  const priorities: LocalPaymentPriority[] = ["relevante", "poco_relevante", "irrelevante"];
  return {
    alias: alias.slice(0, 60),
    category: categories.includes(input.category) ? input.category : "otro" as LocalPaymentCategory,
    provider: input.provider.trim().slice(0, 60),
    amountDueCents,
    dueDate: input.dueDate,
    remindDaysBefore: Array.from(new Set(input.remindDaysBefore.map(Number).filter((day) => [1, 3, 5].includes(day)))).sort((a, b) => b - a),
    priority: priorities.includes(input.priority) ? input.priority : "poco_relevante" as LocalPaymentPriority,
    recurrence: input.recurrence === "monthly" ? "monthly" as LocalPaymentRecurrence : "once" as LocalPaymentRecurrence,
  };
}

// Agenda de pagos: información de organización, no datos de tarjeta sensibles.
// Por eso se guarda alias/proveedor y nunca número, CVV o NIP.
export async function addLocalCard(input: LocalCardInput): Promise<LocalNotebookSnapshot> {
  return mutateState((state) => {
    if (state.cards.length >= 100) throw new Error("Alcanzaste el límite de pagos de esta beta.");
    const normalized = normalizedCardInput(input);
    const now = new Date().toISOString();
    state.cards.push({
      id: newId(),
      ...normalized,
      status: "current",
      color: "purple",
      createdAt: now,
      updatedAt: now,
    });
  });
}

export async function updateLocalCard(id: string, input: LocalCardInput): Promise<LocalNotebookSnapshot> {
  return mutateState((state) => {
    const card = state.cards.find((item) => item.id === id);
    if (!card) throw new Error("Ese pago ya no existe.");
    Object.assign(card, normalizedCardInput(input), { updatedAt: new Date().toISOString() });
  });
}

export async function setLocalCardStatus(id: string, status: "current" | "paid"): Promise<LocalNotebookSnapshot> {
  return mutateState((state) => {
    const card = state.cards.find((item) => item.id === id);
    if (!card) throw new Error("Ese pago ya no existe.");
    // Al confirmar un pago mensual no lo duplicamos: avanzamos la misma agenda
    // un mes. Un pago único, en cambio, queda marcado como realizado.
    if (status === "paid" && card.recurrence === "monthly" && card.dueDate) {
      const [year, month, day] = card.dueDate.split("-").map(Number);
      // Febrero y los meses cortos usan su último día (31 ene → 28/29 feb),
      // en vez de saltar por accidente hasta marzo.
      const nextMonthLastDay = new Date(year, month + 1, 0).getDate();
      const nextDue = new Date(year, month, Math.min(day, nextMonthLastDay));
      card.dueDate = `${nextDue.getFullYear()}-${String(nextDue.getMonth() + 1).padStart(2, "0")}-${String(nextDue.getDate()).padStart(2, "0")}`;
      card.status = "current";
    } else {
      card.status = status;
    }
    card.updatedAt = new Date().toISOString();
  });
}

export async function deleteLocalCard(id: string): Promise<LocalNotebookSnapshot> {
  return mutateState((state) => {
    const index = state.cards.findIndex((item) => item.id === id);
    if (index < 0) throw new Error("Ese pago ya no existe.");
    state.cards.splice(index, 1);
  }, { safetyCopyReason: "before_delete" });
}

type LocalGoalInput = {
  name: string;
  purpose: string;
  term: LocalGoalTerm;
  target: number;
  targetDate: string;
  icon: string;
  color: LocalPocket["color"];
};

function normalizedGoalInput(input: LocalGoalInput) {
  const name = input.name.trim();
  const purpose = input.purpose.trim();
  const targetCents = Math.round(Number(input.target) * 100);
  if (!name) throw new Error("Ponle un nombre a tu objetivo.");
  if (!purpose) throw new Error("Escribe para qué quieres lograr este objetivo.");
  if (!Number.isFinite(targetCents) || targetCents < 1) throw new Error("Escribe cuánto cuesta tu objetivo.");
  if (!/^\d{4}-\d{2}-\d{2}$/.test(input.targetDate)) throw new Error("Elige una fecha para cumplir tu objetivo.");
  const terms: LocalGoalTerm[] = ["corto", "mediano", "largo"];
  const colors: LocalPocket["color"][] = ["violet", "rose", "blue", "green"];
  return {
    name: name.slice(0, 70),
    purpose: purpose.slice(0, 240),
    term: terms.includes(input.term) ? input.term : "mediano" as LocalGoalTerm,
    targetCents,
    targetDate: input.targetDate,
    icon: (input.icon || "◎").slice(0, 4),
    color: colors.includes(input.color) ? input.color : "violet" as LocalPocket["color"],
  };
}

// Objetivos: son dinero realmente reservado. Sus aportaciones y retiros cambian
// un apartado al mismo tiempo para que el total general siga siendo correcto.
export async function addLocalGoal(input: LocalGoalInput): Promise<LocalNotebookSnapshot> {
  return mutateState((state) => {
    if (state.goals.length >= 30) throw new Error("Alcanzaste el límite de objetivos de esta beta.");
    const now = new Date().toISOString();
    state.goals.push({
      id: newId(),
      ...normalizedGoalInput(input),
      savedCents: 0,
      status: "active",
      createdAt: now,
      updatedAt: now,
    });
  });
}

export async function updateLocalGoal(id: string, input: LocalGoalInput): Promise<LocalNotebookSnapshot> {
  return mutateState((state) => {
    const goal = state.goals.find((item) => item.id === id);
    if (!goal) throw new Error("Ese objetivo ya no existe.");
    Object.assign(goal, normalizedGoalInput(input));
    goal.status = goal.savedCents >= goal.targetCents ? "completed" : "active";
    goal.updatedAt = new Date().toISOString();
  });
}

export async function addLocalGoalContribution(input: { goalId: string; pocketId: string; amount: number; note: string }): Promise<LocalNotebookSnapshot> {
  return mutateState((state) => {
    const goal = state.goals.find((item) => item.id === input.goalId);
    const pocket = state.pockets.find((item) => item.id === input.pocketId);
    const amountCents = Math.round(Number(input.amount) * 100);
    if (!goal) throw new Error("Ese objetivo ya no existe.");
    if (!pocket) throw new Error("El apartado seleccionado ya no existe.");
    if (!Number.isFinite(amountCents) || amountCents < 1) throw new Error("Escribe una aportación mayor a cero.");
    if (pocket.balanceCents < amountCents) throw new Error("Ese apartado no tiene dinero suficiente.");
    pocket.balanceCents -= amountCents;
    goal.savedCents += amountCents;
    goal.status = goal.savedCents >= goal.targetCents ? "completed" : "active";
    goal.updatedAt = new Date().toISOString();
    state.goalMovements.push({
      id: newId(), goalId: goal.id, pocketId: pocket.id, kind: "contribution", amountCents,
      note: input.note.trim().slice(0, 240), occurredAt: new Date().toISOString(),
    });
  });
}

export async function withdrawFromLocalGoal(input: { goalId: string; pocketId: string; amount: number; note: string }): Promise<LocalNotebookSnapshot> {
  return mutateState((state) => {
    const goal = state.goals.find((item) => item.id === input.goalId);
    const pocket = state.pockets.find((item) => item.id === input.pocketId);
    const amountCents = Math.round(Number(input.amount) * 100);
    if (!goal) throw new Error("Ese objetivo ya no existe.");
    if (!pocket) throw new Error("El apartado seleccionado ya no existe.");
    if (!Number.isFinite(amountCents) || amountCents < 1) throw new Error("Escribe una cantidad mayor a cero.");
    if (goal.savedCents < amountCents) throw new Error("Tu objetivo no tiene esa cantidad disponible.");
    goal.savedCents -= amountCents;
    pocket.balanceCents += amountCents;
    goal.status = goal.savedCents >= goal.targetCents ? "completed" : "active";
    goal.updatedAt = new Date().toISOString();
    state.goalMovements.push({
      id: newId(), goalId: goal.id, pocketId: pocket.id, kind: "withdrawal", amountCents,
      note: input.note.trim().slice(0, 240), occurredAt: new Date().toISOString(),
    });
  });
}

export async function deleteLocalGoal(id: string): Promise<LocalNotebookSnapshot> {
  return mutateState((state) => {
    const goal = state.goals.find((item) => item.id === id);
    if (!goal) throw new Error("Ese objetivo ya no existe.");
    if (goal.savedCents > 0) throw new Error("Retira primero el dinero del objetivo antes de eliminarlo.");
    state.goals = state.goals.filter((item) => item.id !== id);
    state.goalMovements = state.goalMovements.filter((movement) => movement.goalId !== id);
  }, { safetyCopyReason: "before_delete" });
}

export async function addLocalPocket(input: { name: string; icon: string; color: LocalPocket["color"] }): Promise<LocalNotebookSnapshot> {
  return mutateState((state) => {
    const name = input.name.trim();
    if (!name) throw new Error("Ponle un nombre al apartado.");
    if (state.pockets.length >= 30) throw new Error("Alcanzaste el límite de apartados de esta beta.");
    state.pockets.push({
      id: newId(),
      name: name.slice(0, 45),
      balanceCents: 0,
      icon: (input.icon || "✦").slice(0, 4),
      color: input.color,
      role: state.pockets.some((pocket) => pocket.role === "available") ? "reserved" : "available",
      createdAt: new Date().toISOString(),
    });
  });
}

// Al editar o borrar un movimiento primero se revierte su efecto anterior y
// luego se aplica el nuevo. Esta es la razón de que las correcciones no creen
// ingresos o gastos falsos para compensar un error.
function applyTransactionEffect(state: LocalNotebook, movement: Pick<LocalTransaction, "kind" | "amountCents" | "sourcePocketId" | "targetPocketId">, direction: 1 | -1) {
  const source = state.pockets.find((pocket) => pocket.id === movement.sourcePocketId);
  if (!source) throw new Error("El apartado de origen de ese movimiento ya no existe.");
  const cents = movement.amountCents * direction;
  if (movement.kind === "ingreso") source.balanceCents += cents;
  if (movement.kind === "gasto") source.balanceCents -= cents;
  if (movement.kind === "transferencia") {
    const target = state.pockets.find((pocket) => pocket.id === movement.targetPocketId);
    if (!target) throw new Error("El apartado de destino de ese movimiento ya no existe.");
    source.balanceCents -= cents;
    target.balanceCents += cents;
  }
}

export async function updateLocalTransaction(input: {
  id: string;
  kind: LocalMovementKind;
  amount: number;
  sourcePocketId: string;
  targetPocketId: string | null;
  purpose: string;
  note: string;
  occurredAt: string;
  changeReason: string;
}): Promise<LocalNotebookSnapshot> {
  return mutateState((state) => {
    const movement = state.transactions.find((item) => item.id === input.id);
    if (!movement) throw new Error("Ese movimiento ya no existe.");
    const cents = Math.round(Number(input.amount) * 100);
    if (!cents || cents < 1) throw new Error("Escribe una cantidad mayor a cero.");
    if (!input.purpose.trim()) throw new Error("El motivo del movimiento es obligatorio.");
    if (!input.changeReason.trim()) throw new Error("Explica por qué haces la corrección.");
    const source = state.pockets.find((pocket) => pocket.id === input.sourcePocketId);
    if (!source) throw new Error("El apartado seleccionado ya no existe.");
    const target = input.kind === "transferencia" ? state.pockets.find((pocket) => pocket.id === input.targetPocketId) : null;
    if (input.kind === "transferencia" && (!target || target.id === source.id)) throw new Error("Elige apartados diferentes para la transferencia.");

    applyTransactionEffect(state, movement, -1);
    if ((input.kind === "gasto" || input.kind === "transferencia") && source.balanceCents < cents) {
      applyTransactionEffect(state, movement, 1);
      throw new Error("El apartado elegido no tiene saldo suficiente para esa corrección.");
    }
    const corrected = {
      kind: input.kind,
      amountCents: cents,
      sourcePocketId: source.id,
      targetPocketId: target?.id ?? null,
    };
    applyTransactionEffect(state, corrected, 1);
    movement.kind = corrected.kind;
    movement.amountCents = corrected.amountCents;
    movement.sourcePocketId = corrected.sourcePocketId;
    movement.targetPocketId = corrected.targetPocketId;
    movement.purpose = input.purpose.trim().slice(0, 120);
    movement.note = input.note.trim().slice(0, 500);
    movement.occurredAt = new Date(input.occurredAt).toISOString();
    movement.changeReason = input.changeReason.trim().slice(0, 300);
    movement.correctedAt = new Date().toISOString();
  });
}

export async function deleteLocalTransaction(id: string): Promise<LocalNotebookSnapshot> {
  return mutateState((state) => {
    const index = state.transactions.findIndex((item) => item.id === id);
    if (index < 0) throw new Error("Ese movimiento ya no existe.");
    applyTransactionEffect(state, state.transactions[index], -1);
    state.transactions.splice(index, 1);
  }, { safetyCopyReason: "before_delete" });
}

// Corrección de apartado: permite arreglar el saldo inicial sin inventar un
// movimiento. Siempre debe permanecer al menos un apartado disponible.
export async function updateLocalPocket(input: { id: string; name: string; icon: string; color: LocalPocket["color"]; role: LocalPocketRole; balance: number }): Promise<LocalNotebookSnapshot> {
  return mutateState((state) => {
    const pocket = state.pockets.find((item) => item.id === input.id);
    if (!pocket) throw new Error("Ese apartado ya no existe.");
    if (!input.name.trim()) throw new Error("Ponle un nombre al apartado.");
    const balanceCents = Math.round(Number(input.balance) * 100);
    if (!Number.isFinite(balanceCents) || balanceCents < 0) throw new Error("El saldo actual no puede ser negativo.");
    if (input.role === "reserved" && pocket.role === "available" && !state.pockets.some((item) => item.id !== pocket.id && item.role === "available")) {
      throw new Error("Elige primero otro apartado como dinero disponible.");
    }
    if (input.role === "available") {
      for (const item of state.pockets) item.role = item.id === pocket.id ? "available" : "reserved";
    } else {
      pocket.role = "reserved";
    }
    pocket.name = input.name.trim().slice(0, 45);
    pocket.icon = (input.icon || "✦").slice(0, 4);
    pocket.color = input.color;
    pocket.balanceCents = balanceCents;
  });
}

export async function deleteLocalPocket(id: string): Promise<LocalNotebookSnapshot> {
  return mutateState((state) => {
    const pocket = state.pockets.find((item) => item.id === id);
    if (!pocket) throw new Error("Ese apartado ya no existe.");
    if (pocket.balanceCents !== 0) throw new Error("Mueve primero el saldo de este apartado antes de eliminarlo.");
    if (state.transactions.some((item) => item.sourcePocketId === id || item.targetPocketId === id)) {
      throw new Error("Elimina primero los movimientos relacionados con este apartado.");
    }
    if (pocket.role === "available" && !state.pockets.some((item) => item.id !== id && item.role === "available")) {
      throw new Error("La libreta necesita un apartado marcado como dinero disponible.");
    }
    state.pockets = state.pockets.filter((item) => item.id !== id);
  }, { safetyCopyReason: "before_delete" });
}

export async function resetLocalNotebook(): Promise<LocalNotebookSnapshot> {
  return mutateState((state) => {
    const name = activeNotebookRecord(state).name;
    const fresh = defaultNotebook();
    fresh.profile.notebookTitle = name;
    fresh.profile.displayName = state.profile.displayName;
    applyNotebookData(state, fresh);
  }, { safetyCopyReason: "before_reset" });
}

export async function setAnalyticsConsent(consent: boolean): Promise<LocalNotebookSnapshot> {
  return mutateState((state) => { state.analyticsConsent = consent; });
}

export async function requestPersistentStorage(): Promise<boolean> {
  if (!navigator.storage?.persist) return false;
  return navigator.storage.persist();
}

export async function getPersistentStorageStatus(): Promise<"active" | "available" | "unsupported"> {
  if (!navigator.storage?.persisted) return "unsupported";
  return await navigator.storage.persisted() ? "active" : "available";
}

// Esta copia es una red de seguridad local: permite volver al estado anterior
// a la última acción delicada. Si se desinstala la app o se borran sus datos,
// la copia también desaparece; por eso el respaldo JSON externo sigue siendo
// la protección principal para cambiar de teléfono o reinstalar.
export async function getLocalSafetyCopyStatus(): Promise<LocalSafetyCopyStatus> {
  const database = await openDatabase();
  try {
    const transaction = database.transaction(STORE_NAME, "readonly");
    const store = transaction.objectStore(STORE_NAME);
    const copy = await new Promise<LocalSafetyCopy | undefined>((resolve, reject) => {
      const request = store.get(SAFETY_COPY_KEY);
      request.onsuccess = () => resolve(request.result as LocalSafetyCopy | undefined);
      request.onerror = () => reject(request.error ?? new Error("No se pudo revisar la copia de seguridad."));
    });
    await finishTransaction(transaction);
    return {
      available: Boolean(copy?.state && copy.version === 1),
      createdAt: typeof copy?.createdAt === "string" ? copy.createdAt : null,
      reason: copy?.reason === "before_restore" || copy?.reason === "before_delete" || copy?.reason === "before_reset" ? copy.reason : null,
    };
  } finally {
    database.close();
  }
}

export async function restoreLocalSafetyCopy(): Promise<LocalNotebookSnapshot> {
  const database = await openDatabase();
  try {
    const transaction = database.transaction(STORE_NAME, "readwrite");
    const store = transaction.objectStore(STORE_NAME);
    const copy = await new Promise<LocalSafetyCopy | undefined>((resolve, reject) => {
      const request = store.get(SAFETY_COPY_KEY);
      request.onsuccess = () => resolve(request.result as LocalSafetyCopy | undefined);
      request.onerror = () => reject(request.error ?? new Error("No se pudo leer la copia de seguridad."));
    });
    if (!copy?.state || copy.version !== 1) throw new Error("No hay una copia de seguridad interna disponible.");
    const restored = normalizeNotebook(structuredClone(copy.state));
    restored.updatedAt = new Date().toISOString();
    store.put(restored, STATE_KEY);
    await finishTransaction(transaction);
    return publicSnapshot(restored);
  } finally {
    database.close();
  }
}

export type LocalBackupResult = "shared" | "downloaded" | "cancelled";

function safeNotebookData(data: LocalNotebookData) {
  return {
    ...structuredClone(data),
    installId: undefined,
    analyticsConsent: undefined,
  };
}

// El respaldo v2 incluye todas las libretas pero excluye installId y permiso de
// métricas: así no copia identificadores técnicos ni consentimiento a otro teléfono.
function backupFileFromState(state: LocalNotebook): File {
  syncActiveNotebook(state);
  const contents = JSON.stringify({
    backupVersion: 2,
    exportedAt: new Date().toISOString(),
    activeNotebookId: state.notebookCollection?.activeNotebookId,
    notebooks: state.notebookCollection?.notebooks.map(({ id, name, createdAt, updatedAt, archivedAt, data }) => ({
      id,
      name,
      createdAt,
      updatedAt,
      archivedAt: archivedAt ?? null,
      notebook: safeNotebookData(data),
    })) ?? [],
  }, null, 2);
  return new File(
    [contents],
    `respaldo-mi-libreta-${new Date().toISOString().slice(0, 10)}.json`,
    { type: "application/json" },
  );
}

export async function createLocalBackupFile(): Promise<File> {
  const database = await openDatabase();
  try {
    const { state, transaction, store } = await readState(database, "readwrite");
    const file = backupFileFromState(state);
    store.put(state, STATE_KEY);
    await finishTransaction(transaction);
    return file;
  } finally {
    database.close();
  }
}

export async function saveLocalBackup(file: File): Promise<LocalBackupResult> {
  const shareNavigator = navigator as Navigator & {
    canShare?: (data: ShareData) => boolean;
    share?: (data: ShareData) => Promise<void>;
  };

  if (shareNavigator.share && shareNavigator.canShare?.({ files: [file] })) {
    try {
      // Keep this as the first asynchronous browser action so iOS preserves
      // the user activation required to open its native share sheet.
      await shareNavigator.share({
        files: [file],
        title: "Respaldo de Mi Libreta Financiera",
        text: "Guarda esta copia en Archivos, Drive, OneDrive o iCloud.",
      });
      return "shared";
    } catch (caught) {
      if (caught instanceof DOMException && caught.name === "AbortError") return "cancelled";
      // Some installed browsers advertise file sharing but fail at runtime.
      // Continue with the regular download instead of losing the backup.
    }
  }

  const url = URL.createObjectURL(file);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = file.name;
  anchor.rel = "noopener";
  anchor.style.display = "none";
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 30_000);
  return "downloaded";
}

// Restauración defensiva: limita tamaño, cantidad de registros y formatos antes
// de reemplazar el estado local. También acepta respaldos antiguos de una libreta.
export async function importLocalBackup(file: File): Promise<LocalNotebookSnapshot> {
  if (file.size > 8_000_000) throw new Error("El respaldo es demasiado grande.");
  const parsed = JSON.parse(await file.text()) as {
    backupVersion?: number;
    activeNotebookId?: string;
    notebook?: Partial<LocalNotebook>;
    notebooks?: Array<{ id?: string; name?: string; createdAt?: string; updatedAt?: string; archivedAt?: string | null; notebook?: Partial<LocalNotebook> }>;
  };
  if (parsed.backupVersion === 2 && Array.isArray(parsed.notebooks)) {
    const candidates = parsed.notebooks.slice(0, 12).filter((item) => (
      item.notebook?.profile
      && Array.isArray(item.notebook.pockets) && item.notebook.pockets.length <= 30
      && Array.isArray(item.notebook.transactions) && item.notebook.transactions.length <= 5_000
      && Array.isArray(item.notebook.cards) && item.notebook.cards.length <= 100
      && (!item.notebook.goals || (Array.isArray(item.notebook.goals) && item.notebook.goals.length <= 30))
      && (!item.notebook.goalMovements || (Array.isArray(item.notebook.goalMovements) && item.notebook.goalMovements.length <= 5_000))
    ));
    if (!candidates.length) throw new Error("El respaldo no contiene libretas válidas.");
    return mutateState((state) => {
      const importedAt = new Date().toISOString();
      const records = candidates.map((item, index) => {
        const temporary = defaultNotebook();
        Object.assign(temporary, item.notebook, { notebookCollection: undefined });
        const clean = normalizeNotebook(temporary);
        const id = typeof item.id === "string" && item.id ? item.id : newId();
        return {
          id,
          name: cleanNotebookName(item.name, clean.profile.notebookTitle || `Libreta ${index + 1}`),
          createdAt: item.createdAt || importedAt,
          updatedAt: item.updatedAt || importedAt,
          archivedAt: typeof item.archivedAt === "string" ? item.archivedAt : null,
          data: notebookDataFromState(clean),
        };
      });
      const unique = new Set<string>();
      for (const record of records) {
        if (unique.has(record.id)) record.id = newId();
        unique.add(record.id);
      }
      const activeNotebookId = records.some((item) => item.id === parsed.activeNotebookId) ? parsed.activeNotebookId! : records[0].id;
      state.notebookCollection = { schemaVersion: 1, activeNotebookId, notebooks: records };
      applyNotebookData(state, records.find((item) => item.id === activeNotebookId)!.data);
    }, { safetyCopyReason: "before_restore" });
  }
  const incoming = parsed.notebook;
  if (parsed.backupVersion !== 1 || !incoming?.profile || !Array.isArray(incoming.pockets) || !Array.isArray(incoming.transactions) || !Array.isArray(incoming.cards)) {
    throw new Error("El archivo no es un respaldo válido de Mi Libreta Financiera.");
  }
  return mutateState((state) => {
    state.setupCompleted = true;
    state.schemaVersion = 6;
    state.profile = incoming.profile as LocalProfile;
    state.pockets = incoming.pockets!.slice(0, 30).map((pocket, index) => ({
      ...pocket,
      role: pocket.role === "available" || pocket.role === "reserved" ? pocket.role : index === 0 ? "available" : "reserved",
    })) as LocalPocket[];
    state.transactions = incoming.transactions!.slice(0, 5000) as LocalTransaction[];
    state.cards = incoming.cards!.slice(0, 100) as LocalCard[];
    state.goals = (Array.isArray(incoming.goals) ? incoming.goals : []).slice(0, 30) as LocalGoal[];
    state.goalMovements = (Array.isArray(incoming.goalMovements) ? incoming.goalMovements : []).slice(0, 5000) as LocalGoalMovement[];
    const normalized = normalizeNotebook(state);
    state.cards = normalized.cards;
    state.goals = normalized.goals;
    state.goalMovements = normalized.goalMovements;
  }, { safetyCopyReason: "before_restore" });
}
