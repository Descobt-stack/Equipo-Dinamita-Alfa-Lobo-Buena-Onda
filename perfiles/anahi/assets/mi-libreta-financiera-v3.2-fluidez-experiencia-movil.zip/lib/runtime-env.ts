// Centraliza los servicios del entorno. Las claves privadas solo se consumen
// en el servidor; ningún componente del navegador puede leerlas.
export type FinanceRuntimeEnv = {
  DB: D1Database;
  BUCKET: R2Bucket;
  VAPID_SUBJECT?: string;
  VAPID_SERVER_PUBLIC_KEY?: string;
  VAPID_SERVER_PRIVATE_KEY?: string;
  REMINDER_CRON_SECRET?: string;
};

const runtimeKey = "__financeRuntimeEnv";

export function setFinanceRuntimeEnv(env: FinanceRuntimeEnv) {
  (globalThis as typeof globalThis & Record<string, FinanceRuntimeEnv>)[runtimeKey] = env;
}

export function getFinanceRuntimeEnv(): FinanceRuntimeEnv {
  const runtime = (globalThis as typeof globalThis & Record<string, FinanceRuntimeEnv | undefined>)[runtimeKey];
  if (!runtime?.DB) throw new Error("La base de datos todavía no está disponible.");
  return runtime;
}
