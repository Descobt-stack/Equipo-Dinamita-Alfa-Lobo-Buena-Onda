// Exportaciones mensuales que se crean dentro del navegador. Nunca mandan los
// movimientos a un servidor: el archivo se arma con la libreta del teléfono.

export type MonthlyReportExport = {
  notebookName: string;
  monthLabel: string;
  monthKey: string;
  generatedAt: string;
  income: number;
  expense: number;
  net: number;
  available: number;
  reserved: number;
  goalSaved: number;
  spending: Array<{ name: string; amount: number; percent: number }>;
  movements: Array<{ date: string; kind: "Ingreso" | "Gasto" | "Transferencia"; purpose: string; note: string; pocket: string; amount: number }>;
  payments: Array<{ name: string; provider: string; dueDate: string; amount: number; recurrence: string; status: string }>;
};

const money = new Intl.NumberFormat("es-MX", { style: "currency", currency: "MXN", minimumFractionDigits: 2 });
const encoder = new TextEncoder();

function cleanFilePart(value: string) {
  return value.normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-zA-Z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 45) || "libreta";
}

function safeText(value: string) {
  return value.normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[–—]/g, "-").replace(/[“”]/g, '"').replace(/[‘’]/g, "'");
}

function xml(value: string) {
  return value.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/\"/g, "&quot;").replace(/'/g, "&apos;");
}

function columnName(index: number) {
  let result = "";
  let current = index;
  while (current >= 0) {
    result = String.fromCharCode((current % 26) + 65) + result;
    current = Math.floor(current / 26) - 1;
  }
  return result;
}

function crc32(bytes: Uint8Array) {
  let crc = 0xffffffff;
  for (const byte of bytes) {
    crc ^= byte;
    for (let bit = 0; bit < 8; bit += 1) crc = (crc >>> 1) ^ (0xedb88320 & -(crc & 1));
  }
  return (crc ^ 0xffffffff) >>> 0;
}

function u16(value: number) {
  const out = new Uint8Array(2);
  new DataView(out.buffer).setUint16(0, value, true);
  return out;
}

function u32(value: number) {
  const out = new Uint8Array(4);
  new DataView(out.buffer).setUint32(0, value >>> 0, true);
  return out;
}

function joinBytes(parts: Uint8Array[]) {
  const size = parts.reduce((sum, part) => sum + part.length, 0);
  const joined = new Uint8Array(size);
  let offset = 0;
  for (const part of parts) { joined.set(part, offset); offset += part.length; }
  return joined;
}

// ZIP sin compresion: suficiente para reportes mensuales y compatible con
// Excel, sin depender de una libreria externa ni de conexion a internet.
function zip(files: Array<{ name: string; content: string }>) {
  const locals: Uint8Array[] = [];
  const central: Uint8Array[] = [];
  let offset = 0;
  for (const file of files) {
    const name = encoder.encode(file.name);
    const data = encoder.encode(file.content);
    const checksum = crc32(data);
    const local = joinBytes([u32(0x04034b50), u16(20), u16(0x0800), u16(0), u16(0), u16(0), u32(checksum), u32(data.length), u32(data.length), u16(name.length), u16(0), name, data]);
    locals.push(local);
    central.push(joinBytes([u32(0x02014b50), u16(20), u16(20), u16(0x0800), u16(0), u16(0), u16(0), u32(checksum), u32(data.length), u32(data.length), u16(name.length), u16(0), u16(0), u16(0), u16(0), u32(0), u32(offset), name]));
    offset += local.length;
  }
  const centralData = joinBytes(central);
  return joinBytes([...locals, centralData, u32(0x06054b50), u16(0), u16(0), u16(files.length), u16(files.length), u32(centralData.length), u32(offset), u16(0)]);
}

type Cell = string | number | null;
type Sheet = { name: string; rows: Cell[][]; widths: number[] };

function sheetXml(sheet: Sheet) {
  const rows = sheet.rows.map((row, rowIndex) => {
    const cells = row.map((value, index) => {
      if (value === null || value === "") return "";
      const ref = `${columnName(index)}${rowIndex + 1}`;
      const isNumber = typeof value === "number";
      const style = rowIndex === 0 ? ' s="1"' : (isNumber ? ' s="2"' : "");
      return isNumber ? `<c r="${ref}"${style}><v>${value}</v></c>` : `<c r="${ref}"${style} t="inlineStr"><is><t>${xml(String(value))}</t></is></c>`;
    }).join("");
    return `<row r="${rowIndex + 1}">${cells}</row>`;
  }).join("");
  const columns = sheet.widths.map((width, index) => `<col min="${index + 1}" max="${index + 1}" width="${width}" customWidth="1"/>`).join("");
  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><cols>${columns}</cols><sheetData>${rows}</sheetData></worksheet>`;
}

function createWorkbook(data: MonthlyReportExport) {
  const summary: Sheet = {
    name: "Resumen mensual",
    widths: [31, 20, 17],
    rows: [
      ["Mi Libreta Financiera", data.notebookName, null],
      ["Cierre mensual", data.monthLabel, null],
      ["Generado", data.generatedAt, null],
      [],
      ["Concepto", "Monto", "Explicacion"],
      ["Ingresos", data.income, "Dinero que entro en el mes"],
      ["Gastos", data.expense, "Dinero que salio en el mes"],
      ["Resultado del mes", data.net, data.net >= 0 ? "Entraste mas de lo que gastaste" : "Gastaste mas de lo que entro"],
      ["Disponible actual", data.available, "No incluye apartados ni objetivos"],
      ["Apartados actuales", data.reserved, "Dinero separado en esta libreta"],
      ["Guardado en objetivos", data.goalSaved, "Estado actual de tus metas"],
      [],
      ["Gasto por concepto", "Monto", "% de ingresos"],
      ...data.spending.map((item) => [item.name, item.amount, `${item.percent.toFixed(1)}%`]),
    ],
  };
  const movements: Sheet = {
    name: "Movimientos",
    widths: [16, 15, 32, 36, 22, 16],
    rows: [["Fecha", "Tipo", "Concepto", "Nota", "Apartado", "Monto"], ...data.movements.map((item) => [item.date, item.kind, item.purpose, item.note, item.pocket, item.amount])],
  };
  const payments: Sheet = {
    name: "Pagos",
    widths: [30, 25, 17, 16, 22, 15],
    rows: [["Pago", "Proveedor", "Fecha limite", "Monto", "Frecuencia", "Estado"], ...data.payments.map((item) => [item.name, item.provider, item.dueDate, item.amount, item.recurrence, item.status])],
  };
  const sheets = [summary, movements, payments];
  const workbookSheets = sheets.map((sheet, index) => `<sheet name="${xml(sheet.name)}" sheetId="${index + 1}" r:id="rId${index + 1}"/>`).join("");
  const relationships = sheets.map((_, index) => `<Relationship Id="rId${index + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet${index + 1}.xml"/>`).join("");
  return zip([
    { name: "[Content_Types].xml", content: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>${sheets.map((_, index) => `<Override PartName="/xl/worksheets/sheet${index + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>`).join("")}</Types>` },
    { name: "_rels/.rels", content: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>` },
    { name: "xl/workbook.xml", content: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>${workbookSheets}</sheets></workbook>` },
    { name: "xl/_rels/workbook.xml.rels", content: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">${relationships}<Relationship Id="rId${sheets.length + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>` },
    { name: "xl/styles.xml", content: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><numFmts count="1"><numFmt numFmtId="164" formatCode="$#,##0.00"/></numFmts><fonts count="2"><font><sz val="11"/><name val="Aptos"/></font><font><b/><color rgb="FFFFFFFF"/><sz val="11"/><name val="Aptos"/></font></fonts><fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FF16454B"/><bgColor indexed="64"/></patternFill></fill></fills><borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="3"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0"/><xf numFmtId="164" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/></cellXfs></styleSheet>` },
    ...sheets.map((sheet, index) => ({ name: `xl/worksheets/sheet${index + 1}.xml`, content: sheetXml(sheet) })),
  ]);
}

function pdfText(value: string) {
  return safeText(value).replace(/[\\()]/g, "\\$&").replace(/[^\x20-\x7E]/g, "?");
}

function pdfLine(text: string, x: number, y: number, size = 10, color = "0.12 0.20 0.22") {
  return `${color} rg\nBT /F1 ${size} Tf ${x} ${y} Td (${pdfText(text)}) Tj ET\n`;
}

function pdfRect(x: number, y: number, width: number, height: number, color: string) {
  return `${color} rg\n${x} ${y} ${width} ${height} re f\n`;
}

function pdfPage(content: string) {
  return `q\n${content}Q\n`;
}

function createPdf(data: MonthlyReportExport) {
  const pages: string[] = [];
  let summary = pdfRect(0, 780, 595, 62, "0.06 0.24 0.27") + pdfLine("MI LIBRETA FINANCIERA", 42, 812, 15, "1 1 1") + pdfLine("Cierre mensual - " + data.monthLabel, 42, 794, 10, "0.80 0.94 0.91");
  summary += pdfLine(data.notebookName, 42, 758, 13, "0.06 0.24 0.27");
  summary += pdfLine("Resumen simple de tus movimientos del mes", 42, 741, 9, "0.38 0.47 0.48");
  const metrics = [["Ingresos", data.income, "0.10 0.48 0.37"], ["Gastos", data.expense, "0.72 0.20 0.26"], ["Resultado", data.net, data.net >= 0 ? "0.10 0.48 0.37" : "0.72 0.20 0.26"]] as const;
  metrics.forEach(([label, value, color], index) => {
    const x = 42 + index * 174;
    summary += pdfRect(x, 662, 155, 57, "0.95 0.98 0.97") + pdfLine(label, x + 10, 699, 9, "0.30 0.42 0.41") + pdfLine(money.format(value), x + 10, 678, 13, color);
  });
  summary += pdfLine("De cada $100 que entraron, asi se repartieron tus gastos:", 42, 629, 11, "0.06 0.24 0.27");
  if (data.spending.length) {
    data.spending.slice(0, 7).forEach((item, index) => {
      const y = 598 - index * 35;
      summary += pdfLine(item.name.slice(0, 31), 42, y + 10, 9) + pdfLine(`${money.format(item.amount)} - ${item.percent.toFixed(1)}%`, 424, y + 10, 9, "0.30 0.42 0.41");
      summary += pdfRect(42, y - 2, 330, 7, "0.88 0.92 0.91") + pdfRect(42, y - 2, Math.max(3, Math.min(330, item.percent * 3.3)), 7, "0.10 0.60 0.56");
    });
  } else {
    summary += pdfLine("Aun no hay gastos con ingresos registrados en este mes.", 42, 594, 10, "0.38 0.47 0.48");
  }
  summary += pdfLine(`Disponible actual: ${money.format(data.available)}   |   Apartados: ${money.format(data.reserved)}   |   Metas: ${money.format(data.goalSaved)}`, 42, 329, 9, "0.30 0.42 0.41");
  summary += pdfLine("Este archivo se genero localmente en tu dispositivo. No se enviaron montos a ningun servidor.", 42, 51, 8, "0.38 0.47 0.48");
  summary += pdfLine("Mi Libreta Financiera - Creada por Josue Villarruel - Version beta 2026", 42, 35, 8, "0.38 0.47 0.48");
  pages.push(pdfPage(summary));

  const perPage = 38;
  const sections = data.movements.length ? data.movements : [{ date: "Sin movimientos", kind: "-", purpose: "No registraste movimientos este mes", note: "", pocket: "", amount: 0 }];
  for (let start = 0; start < sections.length; start += perPage) {
    const chunk = sections.slice(start, start + perPage);
    let content = pdfRect(0, 790, 595, 52, "0.06 0.24 0.27") + pdfLine("MOVIMIENTOS DEL MES", 42, 812, 14, "1 1 1") + pdfLine(data.monthLabel + (sections.length > perPage ? ` - pagina ${Math.floor(start / perPage) + 1}` : ""), 42, 795, 9, "0.80 0.94 0.91");
    content += pdfLine("Fecha", 42, 766, 8, "0.30 0.42 0.41") + pdfLine("Tipo", 128, 766, 8, "0.30 0.42 0.41") + pdfLine("Concepto", 205, 766, 8, "0.30 0.42 0.41") + pdfLine("Monto", 470, 766, 8, "0.30 0.42 0.41");
    chunk.forEach((movement, index) => {
      const y = 744 - index * 18;
      content += pdfLine(movement.date.slice(0, 14), 42, y, 8) + pdfLine(movement.kind, 128, y, 8) + pdfLine(movement.purpose.slice(0, 42), 205, y, 8) + pdfLine(money.format(movement.amount), 470, y, 8, movement.kind === "Gasto" ? "0.72 0.20 0.26" : "0.10 0.48 0.37");
    });
    content += pdfLine("Mi Libreta Financiera - Reporte local del telefono", 42, 35, 8, "0.38 0.47 0.48");
    pages.push(pdfPage(content));
  }

  const objects: string[] = ["", "<< /Type /Catalog /Pages 2 0 R >>", "", "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>"];
  const pageIds: number[] = [];
  pages.forEach((content, index) => {
    const pageId = 4 + index * 2;
    const contentId = pageId + 1;
    pageIds.push(pageId);
    objects[pageId] = `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 3 0 R >> >> /Contents ${contentId} 0 R >>`;
    objects[contentId] = `<< /Length ${encoder.encode(content).length} >>\nstream\n${content}endstream`;
  });
  objects[2] = `<< /Type /Pages /Kids [${pageIds.map((id) => `${id} 0 R`).join(" ")}] /Count ${pageIds.length} >>`;
  let pdf = "%PDF-1.4\n%----\n";
  const offsets: number[] = [0];
  for (let index = 1; index < objects.length; index += 1) {
    offsets[index] = encoder.encode(pdf).length;
    pdf += `${index} 0 obj\n${objects[index]}\nendobj\n`;
  }
  const xref = encoder.encode(pdf).length;
  pdf += `xref\n0 ${objects.length}\n0000000000 65535 f \n`;
  for (let index = 1; index < objects.length; index += 1) pdf += `${String(offsets[index]).padStart(10, "0")} 00000 n \n`;
  return `${pdf}trailer\n<< /Size ${objects.length} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF`;
}

export function createMonthlyExcelBlob(data: MonthlyReportExport) {
  return new Blob([createWorkbook(data)], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
}

export function createMonthlyPdfBlob(data: MonthlyReportExport) {
  return new Blob([createPdf(data)], { type: "application/pdf" });
}

function download(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = filename;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 1_000);
}

export function downloadMonthlyExcel(data: MonthlyReportExport) {
  download(createMonthlyExcelBlob(data), `Mi-Libreta-${cleanFilePart(data.notebookName)}-${data.monthKey}.xlsx`);
}

export function downloadMonthlyPdf(data: MonthlyReportExport) {
  download(createMonthlyPdfBlob(data), `Mi-Libreta-${cleanFilePart(data.notebookName)}-${data.monthKey}.pdf`);
}
